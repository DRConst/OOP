import java.io.Serializable;
/**
 * Classe responsavel pela Aeronave (aviao de carga) e as suas caracteristicas.
 */
public class AeronaveAviaoCarga  extends Aeronave implements Serializable {
    
    /**
     * Construtor da Aeronave Aviao Carga
     */
    public AeronaveAviaoCarga(){
        super();
    }
    
    /**
     * Construtor da Aeronave Aviao Carga mas recebe uma matricula, designacao, numero maximo de passageiros,
     * capacidade maxima e velocidade maxima
     */
    public AeronaveAviaoCarga(String matricula, String designacao, int maxPassageiros, int capacidadeMax, int velocidadeMax){
        super(matricula, designacao, maxPassageiros, capacidadeMax, velocidadeMax);
    } 
    
    /**
     * Construtor da Aeronave Aviao Carga de um objecto
     */
    public AeronaveAviaoCarga(AeronaveAviaoCarga obj){
        super(obj);
    }
    
    /**
     * Compara a Aeronave Aviao Carga com um objecto
     */
    public boolean equals(Object obj){
        if ( obj == this ) return true;
        if ( obj == null ) return false;
        if ( obj.getClass() != this.getClass() ) return false;
        Aeronave a = (AeronaveAviaoCarga) obj;
        return ( ( this.getMat().equals(a.getMat()) ) && ( this.getDes().equals(a.getDes()) ) 
            && ( this.getMPassag() == a.getMPassag() ) && ( this.getMCarga() == a.getMCarga() ) 
            && ( this.getMVel() == a.getMVel() ));
    }
    
    /**
     * Faz copia de uma Aeronave Aviao de Carga
     */
    public AeronaveAviaoCarga clone(){
        return new AeronaveAviaoCarga(this);
    }
    
    /**
     * Passa a Aeronave Aviao Carga para String
     */
    public String toString(){
        return super.toString();
    }
}
