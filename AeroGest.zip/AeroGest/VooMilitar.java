import java.util.GregorianCalendar;
import java.util.ArrayList;
import java.io.Serializable;

/**
 * Classe associada aos voos do tipo militar;
 */
public class VooMilitar extends Voo implements Serializable
{
    private GregorianCalendar   tVoo;                       //Tempo de Voo
    private String              fArmadas;                   //Ramo das Forcas Armadas
    private String              codMissao;                  //Codigo da Missao
    
    /**
     * Construtores
     */
    public VooMilitar(){
        super();
        this.tVoo        = new GregorianCalendar();
        this.fArmadas    = "";
        this.codMissao   = "";
    }
    
    public VooMilitar(String codigo, String entidadeResponsavel, ArrayList<Passageiro> listaPassageiros, ArrayList<Carga> listaCarga, String destino, Estado estado, GregorianCalendar tempoVoo, String ramoForcasArmadas, String codigoMissao, GregorianCalendar horaPartida){
        super(codigo,entidadeResponsavel,listaPassageiros,listaCarga,destino,estado,horaPartida);
        this.tVoo        = tempoVoo;
        this.fArmadas    = ramoForcasArmadas;
        this.codMissao   = codigoMissao;
    }
    
    public VooMilitar(VooMilitar obj){
        super(obj.getCodigo(), obj.getResponsavel(), obj.getPassageiros(), obj.getCarga(), obj.getDestino(), obj.getEstado(), obj.getHoraPartida());
        this.tVoo        = obj.getTVoo();
        this.fArmadas    = obj.getRamoForcasArmadas();
        this.codMissao   = obj.getCodMissao();
    }
    
    /**
     * Retorna o tempo de voo;
     */
    public GregorianCalendar getTVoo()  { return tVoo;      }
    
    /**
     * Retorna o ramo das forcas armadas a que pertence o voo;
     */
    public String getRamoForcasArmadas(){ return fArmadas;  }
    
    /**
     * Retorna o codigo da missao;
     */
    public String getCodMissao()        { return codMissao; }
    
    /**
     * Define o tempo de voo;
     */
    public void setTVoo(GregorianCalendar tempoVoo)  { this.tVoo = (GregorianCalendar) tempoVoo.clone(); }
    
    /**
     * Define o ramo das forcas armadas a que pertence o voo;
     */
    public void setFArmadas(String ramoForcasArmadas){ this.fArmadas = ramoForcasArmadas; }
    
    /**
     * Define o cidgo da missao;
     */
    public void setCodMissao(String codigoMissao)    { this.codMissao = codigoMissao; }
    
    /**
     * Metodo clone();
     */
    public VooMilitar clone(){
        return new VooMilitar(this);
    }
    
    /**
     * Metodo equals();
     */
    public boolean equals(Object obj){
        if ( this == obj ) return true;
        if ( this == null) return false;
        if ( this.getClass() != obj.getClass() ) return false;
        VooMilitar v = (VooMilitar) obj;
        return ( (this.getCodigo().equals(v.getCodigo()) ) &&  ( this.getResponsavel().equals(v.getResponsavel()) ) && ( this.getPassageiros().equals(v.getPassageiros()) ) 
            && (this.getCarga().equals(v.getCarga())) && (this.getDestino().equals(v.getDestino())) && (this.getEstado().equals(v.getEstado())) 
            && (tVoo.equals(v.getTVoo())) && (fArmadas.equals(v.getRamoForcasArmadas())) && (codMissao.equals(v.getCodMissao())) );
    }
    
    /**
     * Metodo toString();
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        s.append(", Tempo de Voo: "); s.append(tVoo);
        s.append(", Ramo das Forcas Armadas: "); s.append(fArmadas);
        s.append(", Codigo da Missao: "); s.append(codMissao);
        return s.toString();
    }
    
}
