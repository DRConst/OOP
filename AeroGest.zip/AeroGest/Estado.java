import java.util.ArrayList;
import java.io.Serializable;
import java.util.GregorianCalendar;
/**
 * Classe responsavel pelos estados e as suas caracteristicas.
 */
public class Estado implements Serializable 
{
    private Estados                 estado;              //Codigo???? 
    private Aeronave                aeronav;            //Aeronave
    private ArrayList<FTripulacao>  trip;               //Lista de Fichas da tripulacao
    private int                     port;               //Numero da Porta
    private ArrayList<Passageiro>   lEmbarque;          //Lista de embarque
    private String                  obs;                //Observacoes
    private GregorianCalendar       tempoTotalCompleta; // ?? Bagagem/Passageiros completa 
    
    /**
     * Construtor por omissao.
     */
    public Estado(){
    }
    
    /**
     * Construtor de um Estado com um estado, uma aeronave, uma lista de tripulacao, porta, lista de embarque, observacoes e tempo total necessario para preencher a bagagem.
     */
    public Estado(Estados estado, Aeronave aeronave, ArrayList<FTripulacao> listaTripulacao, 
        int porta, ArrayList<Passageiro> listaEmbarque, String observacoes){
        this.estado     = estado;
        this.aeronav    = aeronave;
        this.trip       = new ArrayList<FTripulacao>();
        for (FTripulacao tp : listaTripulacao)
            trip.add( tp.clone() );
        this.port       = porta;
        this.lEmbarque  = new ArrayList<Passageiro>();
        if (listaEmbarque != null)
            for (Passageiro p : listaEmbarque)
                lEmbarque.add( p.clone());
        this.obs        = observacoes;
    }
    
    /**
     * Construtor de Carga atravez de outra carga.
     */
    public Estado(Estado obj){
        estado      = obj.getEstado();
        aeronav     = obj.getAeronave();
        trip        = obj.getListaTripulacao();
        port        = obj.getPorta();
        lEmbarque   = obj.getListaEmbarque();
        obs         = obj.getObservacoes();
    }
    
    /**
     * Retorna o estado.
     */
    public Estados getEstado(){ return estado; }
    
    /**
     * Retorna a Aeronave.
     */
    public Aeronave getAeronave(){ return aeronav.clone(); }
    
    /**
     * Retorna a lista de tripulacao.
     */
    public ArrayList<FTripulacao> getListaTripulacao(){
        ArrayList<FTripulacao> copialTripulacao = new ArrayList<FTripulacao>();
        for(FTripulacao f : trip) copialTripulacao.add(f.clone());
        return copialTripulacao;
    }
    
    /**
     * Retorna a porta.
     */
    public int getPorta(){ return port; }
    
    /**
     * Retorna a lista de embarque.
     */
    public ArrayList<Passageiro> getListaEmbarque(){
        ArrayList<Passageiro> copialEmbarque = new ArrayList<Passageiro>();
        for(Passageiro p : lEmbarque) copialEmbarque.add(p.clone());
        return copialEmbarque;
    }
    
    /**
     * Retorna as observacoes.
     */
    public String getObservacoes(){ return obs; }
    
    /**
     * Retorna o tempo total necessario para preencher a bagagem.
     */
    public GregorianCalendar getTempoTotalCompleta(){ return tempoTotalCompleta; }
    
    
    /**
     * Altera o estado.
     */
    public void setEstado(Estados novoEstado)   { this.estado = novoEstado; }
    
    /**
     * Altera a aeronave.
     */
    public void setAeronave(Aeronave aeronave)  { this.aeronav = aeronave; }
    
    /**
     * Altera a porta.
     */
    public void setPorta(int porta)             { this.port = porta; }
    
    /**
     * Altera as observasoes.
     */
    public void setObs(String observacoes)      { this.obs = observacoes; }
    
    /**
     * Altera o tempo necessario para preencher a bagagen.
     */
    public void setTempoTotalCompleta(GregorianCalendar horaInicial) { this.tempoTotalCompleta = (GregorianCalendar) horaInicial.clone(); }
    
    /**
     * Addiciona uma tripulacao ao voo.
     */
    public void addTripulacao(FTripulacao novaFichaTripulacao){
        trip.add(novaFichaTripulacao);
    }
    
    /**
     * Remove um elemento da tripulacao.
     */
    public void remTripulacao(String nome){
        for(FTripulacao ft : trip){
            if(ft.getNome().equals(nome)) trip.remove(ft);
        }
    }
    
    /**
     * Addiciona um passageiro a lista de embarque.
     */
    public void addLEmbarque(Passageiro passageiro){
        lEmbarque.add(passageiro);
    }
    
    /**
     * Remove um passageiro da lista de embarque (por Codigo).
     */
    public void remLEmbarque(String codigo){
        for(Passageiro p : lEmbarque){
            if(p.getCodigo().equals(codigo)) lEmbarque.remove(p);
        }
    }
    
    /**
     * Faz a copia do estado.
     */
    public Estado clone(){ return new Estado(this); }
    
    /**
     * Verifica se um dado objecto e igual ao Estado.
     */
    public boolean equals(Object obj){
        if ( obj == this ) return true;
        if ( obj == null ) return false;
        if ( obj.getClass() != this.getClass() ) return false;
        Estado e = (Estado) obj;
        return ((estado == e.getEstado() ) && (aeronav.equals(e.getAeronave()))  && (trip.equals(e.getListaTripulacao())) && (port == e.getPorta()) && (lEmbarque.equals(e.getListaEmbarque())) &&(obs.equals(e.getObservacoes())));
    }
    
    /**
     * Converte o estado para uma String.
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append("Estado: "); s.append(estado);
        s.append(", Aeronave: "); s.append(aeronav);
        s.append(", Tripulacao: "); s.append(trip);
        s.append(", Porta: "); s.append(port);
        s.append(", Lista de Embarque: "); s.append(lEmbarque);
        s.append(", Observacoes: "); s.append(obs);
        return s.toString();
    }
}
