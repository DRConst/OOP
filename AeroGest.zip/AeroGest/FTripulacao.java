import java.io.Serializable;

/**
 * Classe responsavel pelas tripulacoes de cada voo;
 */
public class FTripulacao implements Serializable
{
    private String      cargo;          //Cargo do tripulante
    private String      name;           //Nome do tripulante
    private String      pais;           //Pais do tripulante
    
    /**
     * Construtor da ficha da tripulacao
     */
    public FTripulacao(){
        cargo   = "";
        name    = "";
        pais    = ""; 
    }
    
    /**
     * Construtor da ficha da tripulacao mas recebe o cargo, um nome e o pais do tripulante
     */
    public FTripulacao(String cargoTrip, String nome, String paisTrip){
        cargo   = cargoTrip;
        name    = nome;
        pais    = paisTrip;
    }
    
    /**
     * Construtor da ficha da tripulacao de um objecto
     */
    public FTripulacao(FTripulacao obj){
        cargo   = obj.getCargo();
        name    = obj.getNome();
        pais    = obj.getPais();
    }
    
    /**
     * Retorna o cargo da ficha do tripulante
     */
    public String getCargo(){ return cargo;}
    
    /**
     * Retorna o nome da ficha do tripulante
     */
    public String getNome() { return name; }
    
    /**
     * Retorna o pais da ficha do tripulante
     */
    public String getPais() { return pais; }
    
    /**
     * Altera o cargo da ficha do tripulante
     */
    public void setCargo(String cargoTrip){ cargo = cargoTrip; }
    
    /**
     * Altera o nome da ficha do tripulante
     */
    public void setNome(String nome) { name  = nome; }
    
    /**
     * Altera o pais da ficha do tripulante
     */
    public void setPais(String paisTrip) { pais  = paisTrip; }
    
    /**
     * Faz a copia da ficha do tripulante
     */
    public FTripulacao clone(){
        return new FTripulacao(this);
    }
    
    /**
     * Compara a ficha do tripulante com um objecto
     */
    public boolean equals(Object obj){
        if (this == obj)    return true;
        if (obj  == null)   return false;
        if (this.getClass() != obj.getClass() ) return false;
        FTripulacao t = (FTripulacao) obj;
        return ( (cargo == t.getCargo()) && (name == t.getNome()) && (pais == t.getPais()) );
    }
    
    
    /**
     * Passa a ficha do tripulante para String
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append("Cargo: "); s.append(cargo);
        s.append(", Nome: "); s.append(name);
        s.append(", Pais: "); s.append(pais);
        return s.toString();
    }
    
}
