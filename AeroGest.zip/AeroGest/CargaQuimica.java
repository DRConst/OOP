import java.util.GregorianCalendar;
import java.io.Serializable;

/**
 * Construtor responsavel pelas cargas do tipo quimica;
 */
public class CargaQuimica extends Carga implements Serializable
{
    private String estado;                  //Estado
    private int grauToxicidade;             //Grau de GrauToxicidade
    
    /**
     * Construtor CargaQuimica por omissao
     */
    public CargaQuimica(){
        super();
        this.estado      = "";
        this.grauToxicidade  = -1;
    }
    
    /**
     * Construtor CargaQuimica que recebe o codigo, peso, descricao, volume, Estado e grau de Toxicidade
     */
    public CargaQuimica(String codigo, double peso, String descricao, double volume, String estado, int grauToxicidade){
        super(codigo,peso,descricao,volume);
        this.estado         = estado;
        this.grauToxicidade = grauToxicidade;
    }
    
    /**
     * Construtor CargaQuimica 
     */
    public CargaQuimica(CargaQuimica obj){
        super(obj.getCodigo(), obj.getPeso(), obj.getDescricao(), obj.getVolume());
        estado          = obj.getEstado();
        grauToxicidade  = obj.getGrauToxicidade();
    }
    
    /**
     * Retorna o estado da Carga Quimica
     */
    public String getEstado() { return estado; }
    
    /**
     * Retorna o Grau de Toxicidade da Carga Quimica
     */
    public int getGrauToxicidade(){ return grauToxicidade; }
    
    /**
     * Altera o Estado da Carga Quimica
     */
    public void setEstado(String estado)  { this.estado = estado;    }
    
    /**
     * Altera o Grau de Toxicidade da Carga Quimica
     */
    public void setGrauToxicidade(int grauToxicidade) { this.grauToxicidade = grauToxicidade;    }
    
    /**
     * Faz uma copia da Carga Quimica
     */
    public CargaQuimica clone(){
        return new CargaQuimica(this);
    }
    
    /**
     * Verifica se um Objecto � igual a Carga Quimica
     */
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (this == null)   return false;
        if (this.getClass() != obj.getClass()) return false;
        CargaQuimica c = (CargaQuimica) obj;
        return ( (getCodigo().equals(c.getCodigo())) && (getPeso() == c.getPeso()) 
            && (getDescricao().equals(c.getDescricao())) && (getTempoCarregamento().equals(c.getTempoCarregamento())) 
            && (estado.equals(c.getEstado())) && (grauToxicidade == c.getGrauToxicidade())
            && (getVolume() == (c.getVolume())));
    }
    
    /**
     * Passa a Carga Quimica para String
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        s.append(", Estado: "); s.append(estado);
        s.append(", GrauToxicidade: "); s.append(grauToxicidade);
        return s.toString();
    }
}
