import java.io.*;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;
import java.util.HashMap;
/**
 * Write a description of class Aerogest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
 public class TEST_AEROGEST implements Serializable{
    
    private static MapaVoos            mapaVoos;
    private static GregorianCalendar   horaActual;       

    /**
    * Inicializa as variaveis.
    */
    public static void init(){
        mapaVoos    = new MapaVoos();
        horaActual  = new GregorianCalendar();
    }
    
    /**
    * Limpa o ecra.
    */
    public static void cls(){
        for( int cont = 1; cont < 100; cont++ )  
            System.out.println();
    }
    
    /**
    * Altera a hora de AeroGest.
    */
    public static void setHoraActual(GregorianCalendar hora){
        horaActual = (GregorianCalendar) hora.clone();
    }
    
    /**
    * 
    */
    public static void main(){
        String op;
        char  opcao;
        init();
        Scanner in = new Scanner(System.in);
        String linha;
        
        //Painel Inicial
        do{
            painelInicial();
            System.out.print("\n\t 1 - Configuracao do Sistema ");
            System.out.print("\n\t 2 - Placard ");
            System.out.print("\n\t 3 - Mapa ");
            System.out.print("\n\t 4 - Voo ");
            System.out.print("\n\t 5 - Editar Estado do Voo ");
            System.out.print("\n\t S - Sair ");
            System.out.print("\n\nOpcao: ");
            linha = in.nextLine();
            if(linha.length() > 0)
                opcao = linha.charAt(0);
            else
                opcao = ' ';
            switch (opcao) {
                case '1' : menuConfigSistema(); break;
                case '2' : placard(); break;
                case '3' : menuMapa(); break;
                case '4' : menuVoo(); break;
                case '5' : editaEstado(); break;
                default: break;
            }
      }while(opcao != 's');
      in.close();
      
    }
    
    
    /**
    * Menu de configuracoes do sistema.
    */
    public static void menuConfigSistema(){
        char opcao;
        Scanner in = new Scanner(System.in);
        String linha;
        
        do{
            painelInicial();
            System.out.print("\n\t 1 - Criar Mapa de Voos ");
            System.out.print("\n\t 2 - Alterar hora do Sistema ");
            System.out.print("\n\t 3 - Guardar Mapa de voos ");
            System.out.print("\n\t 4 - Carregar Mapa de voos ");
            System.out.print("\n\t 5 - Actualiza Estados");
            System.out.print("\n\t S - Sair ");
            System.out.print("\n\nOpcao: ");
            linha = in.nextLine();
            if(linha.length() > 0)
                opcao = linha.charAt(0);
            else
                opcao = ' ';
            switch (opcao) {
                case '1' : criaMapaVoos();          break;
                case '2' : alteraHoraSistema();     break;
                case '3' : guardaMapaVoos();        break;
                case '4' : carregaMapaVoos();       break;
                case '5' : actualizaTodosEstados(); break;
                default: break;
            }
        }while(opcao != 's');
        
        in.close();
    }
    
    
    /**
    * Guarda Mapa de Voos para ObjectStream.
    */
    public static void guardaMapaVoos(){
        Scanner in = new Scanner(System.in);
        String nomeFicheiro;
        ObjectOutputStream oOut;
        
        System.out.print("Qual o nome com que quer guardar o mapa de voos? ");
        nomeFicheiro = in.nextLine();
        
        try{
            oOut = new ObjectOutputStream(new FileOutputStream(nomeFicheiro));
            oOut.writeObject(mapaVoos);
            oOut.flush();
            oOut.close();
        }catch(IOException e){
            e.getMessage();
        }
        
        in.close();
    }
    
    
    /**
    * Carrega Mapa de Voo do ObjectStream
    */
    public static void carregaMapaVoos(){
        ObjectInputStream oIn;
        Scanner in = new Scanner(System.in);
        String nomeFicheiro;
        
        System.out.print("Nome do ficheiro? ");
        nomeFicheiro = in.nextLine();
        
        try{
            oIn = new ObjectInputStream(new FileInputStream(nomeFicheiro));
            mapaVoos = (MapaVoos) oIn.readObject();
            oIn.close();
        }catch(IOException e1 ){
            e1.getMessage();
        }
        catch(ClassNotFoundException e2){
            e2.getMessage();
        }
        
        in.close();
    }
    
    /**
    * Cria um mapa de voos.
    */
    public static void criaMapaVoos(){
        try{
            mapaVoos.remMapa();
            TreeMap<String, Voo> mapa1 = criaTodosVoos();
            mapaVoos.setMapa(mapa1);
            Scanner in = new Scanner(System.in);
            System.out.print("\n\n Mapa acrescentado com sucesso. \n Prima enter para continuar. \n");
            in.nextLine();
            in.close();
        }catch(Exception e){
            Scanner in = new Scanner(System.in);
            System.out.print("\n\n Houve um erro durante a criacao do mapa. \n Prima enter para continuar. \n");
            in.nextLine();
            in.close();
        }
    }
    
    /**
    * Altera a hora do AeroGest.
    */
    public static boolean trataHora(String horas){
        String hora;
        String min;
        if (horas.length() < 1) return true;
        try{ 
            hora = horas.substring(0,2);
            min  = horas.substring(3,5);
            horaActual.set(0,0,0, Integer.parseInt(hora), Integer.parseInt(min),0);
            return true;
        }catch(Exception e){
            System.out.print("\nInseriu uma hora errada. (Ex: 14:40)");
            Scanner in = new Scanner(System.in);
            System.out.print("\n\n Clique em enter para continuar: \n");
            in.nextLine();
            in.close();
            return false;
        }
        
    }
    
    /**
    * Pede a nova hora para o AeroGest.
    */
    public static void alteraHoraSistema(){
        Scanner in = new Scanner(System.in);
        String linha;
        do{
            painelInicial();
            System.out.print("\n\n Caso nao pretenda alterar a hora clique em ENTER");
            System.out.print("\n\n\t Alterar hora do sistema: ");
            linha = in.nextLine();
        }while(!trataHora(linha));
        in.close();
    }
    
    
    /**
    * Menu Mapa
    */
    public static void menuMapa(){
        Scanner in = new Scanner(System.in);
        String linha;
        char opcao;
        
        do{
            painelInicial();
            System.out.print("\n\t 1 - Ver Mapa de Voos ");
            System.out.print("\n\t 2 - Ver voos concluidos ");
            System.out.print("\n\t 3 - Ver estatisticas ");
            System.out.print("\n\t 4 - Diferenca entre Lista de Passageiros e Lista de Embarque ");
            System.out.print("\n\t 5 - Voos do dia (em qualquer Estado) ");
            System.out.print("\n\t S - Sair ");
            System.out.print("\n\nOpcao: ");
            linha = in.nextLine();
            if(linha.length() > 0)
                opcao = linha.charAt(0);
            else
                opcao = ' ';
            switch (opcao){
                case '1' : imprimeMapa(); break;
                case '2' : voosConcluidos(); break;
                case '3' : menuEstatisticas(); break;
                case '4' : difListasVooComercial(); break;
                case '5' : imprimeEstruturaVoos(); break;
                default: break;
            }
        }while(opcao != 's');
      
        in.close();
        
    }
    
    /**
    * Imprime os codigos de voo de todos os estados
    */
    public static void imprimeEstruturaVoos(){
        HashMap<String,ArrayList<Voo>> listaMapasVoo = mapaVoos.getVooPorEstado();
        
        for(ArrayList<Voo> lVoos : listaMapasVoo.values()){
            System.out.print("\n"+listaMapasVoo.get(lVoos) + ": ");
            for(Voo v : lVoos){
                System.out.print(v.getCodigo() +" ,");
            }
        }
        Scanner in = new Scanner(System.in);
        in.nextLine();
        in.close();
    }
    
    /**
    * Diferenca entre os passageiros embarcados e os passageiros previstos para embarcar.
    */
    public static void difListasVooComercial(){
    
        Scanner in = new Scanner(System.in);
        painelInicial();
        
        try{ 
            System.out.print("\nLista dos Voos do tipo comercial. ");
            System.out.print("\n"+ mapaVoos.difPassageirosVoo());
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Imprime o numero de voos que foram concluidos mo dia.
    */
    public static void voosConcluidos(){
        Scanner in = new Scanner(System.in);
        painelInicial();
        
        try{ 
            System.out.print("\nNumero total de voos concluidos: " + mapaVoos.nVoosTerminados());
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Imprime todo o mapa de voo.
    */
    public static void imprimeMapa(){
        TreeMap<String,Voo> mapaDeVoos = mapaVoos.getMapa();
        for(Voo v : mapaDeVoos.values()){
            System.out.print(v.apresentaPlacard());
        }
        Scanner in = new Scanner(System.in);
        System.out.print("\nClique em enter para continuar ");
        in.nextLine();
        in.close();
    }
    
    /**
    * Menu de Estatisticas.
    */
    public static void menuEstatisticas(){
        Scanner in = new Scanner(System.in);
        String linha;
        char opcao;
        
        //Ciclo do Submenu Estatisticas;
        do{
            painelInicial();
            System.out.print("\n\t 1 - Total de passageiros embarcados ");
            System.out.print("\n\t 2 - Total de peso carregado ");
            System.out.print("\n\t 3 - Destinos visitados ");
            System.out.print("\n\t S - Sair ");
            System.out.print("\n\nOpcao: ");
            linha = in.nextLine();
            if(linha.length() > 0)
                opcao = linha.charAt(0);
            else
                opcao = ' ';
            switch (opcao) {
                case '1' : nPassageirosEmbarcados(); break;
                case '2' : totalCargaCarregada(); break;
                case '3' : totalDestinos(); break;
                default: break;
            }
        }while(opcao != 's');
        
        in.close();
    }
    
    /**
    * Edita o estado de um determinado voo introduzido pelo utilizador.
    */
    public static void editaEstado(){
        //Vai chamar objectoVoo() do MapaVoos;
        Scanner in = new Scanner(System.in);
        
        System.out.print("\nInsira o codigo de voo do qual pretende alterar o estado: ");
        
        String codigoVoo = in.nextLine();
        String opcao;
        
        Voo voo = mapaVoos.objectoVoo(codigoVoo);
        
        if ( voo == null ){ 
            System.out.print("\n\tNao existe nenhum voo associado a esse codigo. Prima enter para continuar \n");
            in.nextLine();
            return;
        }
        
        String observacoes = "";
        String novaHora = "";
        GregorianCalendar novaH = new GregorianCalendar();
        
        switch(voo.getEstado().getEstado()){
            case ESPECIFICADO:  GregorianCalendar comecaCarregar = new GregorianCalendar();
                                Estado preparacao1 = voo.getEstadoC();
                                preparacao1.setEstado(Estados.PREPARACAO1);
                                preparacao1.setTempoTotalCompleta(comecaCarregar);
                                System.out.print("\n\t O estado foi actualizado para PREPARACAO1. ");
                                in.nextLine();
                                break;
            case PREPARACAO1:   System.out.print("\n\t Deseja passar para o estado de (1) PREPARACAO2 ou (2) CANCELADO: ");
                                opcao = in.nextLine();
                                if(opcao.charAt(0) == '1'){
                                    Estado preparacao2 = voo.getEstadoC();
                                    preparacao2.setEstado(Estados.PREPARACAO2);
                                    voo.listaEmbarque();
                                    System.out.print("\n\t O estado foi actualizado para PREPARACAO2. ");
                                    in.nextLine();
                                    break;
                                }
                                else{
                                    if(opcao.charAt(0) == '2'){
                                        System.out.print("\n\t Insira o motivo do cancelamento do voo: ");
                                        observacoes = in.nextLine();
                                        Estado cancelado = voo.getEstadoC();
                                        cancelado.setEstado(Estados.CANCELADO);
                                        cancelado.setObs(observacoes);
                                        System.out.print("\n\t O estado foi actualizado para CANCELADO. ");
                                        in.nextLine();
                                        break;
                                    }
                                    else{
                                        System.out.print("\n\t Opcao invalida! ");
                                        in.nextLine();
                                        break;
                                    }
                                }
                                
            case PREPARACAO2:   System.out.print("\n\t Deseja passar para o estado de (1) ATRASO ou (2) PRONTO: ");
                                opcao = in.nextLine();
                                if(opcao.charAt(0) == '1'){
                                    System.out.print("\n\t Insira a nova hora de partida e o motivo do atraso do voo: "); 
                                    observacoes = in.nextLine();
                                    System.out.print("\n\t Insira a nova hora de partida (hh:mm): "); 
                                    novaHora = in.nextLine();
                                    Estado atraso = voo.getEstadoC();
                                    atraso.setEstado(Estados.ATRASO);
                                    atraso.setObs(observacoes);
                                    System.out.print("\n\t O estado foi actualizado para ATRASADO. ");
                                    in.nextLine();
                                    break;
                                }
                                else{
                                    if(opcao.charAt(0) == '2'){
                                        Estado pronto = voo.getEstadoC();
                                        pronto.setEstado(Estados.PRONTO);
                                        System.out.print("\n\t O estado foi actualizado para PRONTO. ");
                                        in.nextLine();
                                        break;
                                    }
                                    else{
                                        System.out.print("\n\t Opcao invalida! ");
                                        in.nextLine();
                                        break;
                                    }
                                }
            case ATRASO:        Estado pronto = voo.getEstadoC();
                                pronto.setEstado(Estados.PRONTO);
                                System.out.print("\n\t O estado foi actualizado para PRONTO. ");
                                break;
            case PRONTO:        System.out.print("\n\t Deseja passar para o estado de (1) NOAR ou (2) CANCELADO: ");
                                opcao = in.nextLine();
                                if(opcao.charAt(0) == '1'){
                                    Estado noar = voo.getEstadoC();
                                    noar.setEstado(Estados.NOAR);
                                    System.out.print("\n\t O estado foi actualizado para NOAR. ");
                                    in.nextLine();
                                    break;
                                }
                                else{
                                    if(in.nextLine().charAt(0) == '2'){
                                        System.out.print("\n\t Insira o motivo do cancelamento do voo: "); 
                                        observacoes = in.nextLine();
                                        Estado cancelado = voo.getEstadoC();
                                        cancelado.setEstado(Estados.CANCELADO);
                                        cancelado.setObs(observacoes);
                                        System.out.print("\n\t O estado foi actualizado para CANCELADO. ");
                                        in.nextLine();
                                        break;
                                    }
                                    else{
                                        System.out.print("\n\t Opcao invalida! ");
                                        in.nextLine();
                                        break;
                                    }
                                }
            case CANCELADO:     System.out.print("\n\t Nao pode alterar o estado dum voo que foi previamente cancelado. ");
                                break;
            case NOAR:          System.out.print("\n\t Nao pode alterar o estado dum voo que ja partiu. ");
                                break;
            default: break;
        }
        
        in.close();
    }
    
    /**
    * Imprime o numero de passageiros embarcados no dia ate ao momento.
    */
    public static void nPassageirosEmbarcados(){
        Scanner in = new Scanner(System.in);
        painelInicial();
        try{ 
            System.out.print("\n Numero total de passageiros ate agora: "+ mapaVoos.totalPassageirosAteHoje(horaActual));
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Imprime a carga carregada no dia ate ao momento.
    */
    public static void totalCargaCarregada(){
        Scanner in = new Scanner(System.in);
        painelInicial();
        try{ 
            System.out.print("\n Numero total de carga ate agora: "+ mapaVoos.totalCargaAteHoje(horaActual));
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Imprime os destinos viajados ate hoje.
    */
    public static void totalDestinos(){
        Scanner in = new Scanner(System.in);
        painelInicial();
        try{ 
            ArrayList<String> d = mapaVoos.destinosAteHoje(horaActual);
            System.out.print("\n\nLista total de destinos:\n");
            for(String s : d){
                System.out.print("\n"+s);
            }
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Menu Voo.
    */
    public static void menuVoo(){
        Scanner in = new Scanner(System.in);
        String linha;
        char opcao;
        
        //Ciclo do Menu Voo;
        do{
            painelInicial();
            System.out.print("\n\t 1 - Cancelar Voo Passageiro");
            System.out.print("\n\t 2 - Tempo restante para conclusao da carga ");
            System.out.print("\n\t 3 - Estado do Voo ");
            System.out.print("\n\t 4 - Voos em determinado Estado ");
            System.out.print("\n\t 5 - Voos de um dado tipo e destino ");
            System.out.print("\n\t S - Sair ");
            System.out.print("\n\nOpcao: ");
            linha = in.nextLine();
            if(linha.length() > 0)
                opcao = linha.charAt(0);
            else
                opcao = ' ';
            switch (opcao) {
                case '1' : /*Cancelar Voo passageiro*/ break;
                case '2' : tempoCarregamentoCarga(); break;
                case '3' : getEstadoVoo(); break;
                case '4' : getListEstadoVoo(); break;
                case '5' : getListTipoDestinoVoo(); break;
                default: break;
            }
        }while(opcao != 's');
        
        in.close();
    }
    
    /**
    * Imprime o tempo necessario para carregar a carga de um dado voo.
    */
    public static void tempoCarregamentoCarga(){
        Scanner in = new Scanner(System.in);
        painelInicial();
        System.out.print("\nCodigo do Voo: ");
        try{ 
            GregorianCalendar tempo = mapaVoos.tempoConcluirCarga(in.nextLine());
            System.out.print("\n\nTempo que demora a carregar: " + tempo.get(GregorianCalendar.HOUR_OF_DAY)+":"+tempo.get(GregorianCalendar.MINUTE)+":"+tempo.get(GregorianCalendar.SECOND));
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Imprime qual o estado de um dado voo.
    */
    public static void getEstadoVoo(){
        Scanner in = new Scanner(System.in);
        painelInicial();
        System.out.print("\nCodigo do Voo: ");
        try{ 
            System.out.print("\n"+mapaVoos.estadoDoVoo(in.nextLine()));
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Imprime os Voos num dado estado.
    */
    public static void getListEstadoVoo(){
        Scanner in = new Scanner(System.in);
        painelInicial();
        System.out.print("\nEstado: ");
        try{ 
            ArrayList<String> lista = mapaVoos.getListaEstado(in.nextLine());
            for(String s : lista) 
                System.out.print("\n"+s);
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Imprime os voos de um dado destino e tipo.
    */
    public static void getListTipoDestinoVoo(){
        Scanner in = new Scanner(System.in);
        painelInicial();
        String tipo;
        String dest;
        try{ 
            System.out.print("\nTipo: ");
            tipo = in.nextLine();
            System.out.print("Destino: ");
            dest = in.nextLine();
            ArrayList<String> lista = mapaVoos.vooTipoDestino(tipo, dest);
            for(String s : lista) 
                System.out.print("\n"+s);
            System.out.print("\n\nPrima enter para continuar \n");
            in.nextLine();
        }catch(Exception e){
            System.out.print("\n\nHouve algum erro durante o processo. Prima enter para continuar \n");
            in.nextLine();
        }
        in.close();
    }
    
    /**
    * Imprime o painel inicial do AeroGest.
    */
    public static void painelInicial(){
        cls();
        System.out.print("\t\t AEROGEST: \n");
        System.out.print("\n");
        System.out.printf("%s %tR", "****** AEROPORTO DE GUALTAR - HORA ACTUAL: ", horaActual);
        System.out.printf(" ********\n");
        
    }
    
    /**
    * Imprime o placard dos voos comerciais.
    */
    public static void placard(){
        TreeSet<Voo> mapaDeVoos = mapaVoos.getMapaHora();
        painelInicial();
        System.out.printf("VOO \t| DESTINO \t| PARTIDA \t| PORTA \t| ESTADO \t| OBS.\n");
        
        for(Voo v : mapaDeVoos){
            if( v.getClass().getName().equals("VooComercial") ){
                System.out.print(v.apresentaPlacard());
            }
        }
        
        Scanner in = new Scanner(System.in);
        System.out.print("\nClique em enter para continuar ");
        in.nextLine();
        in.close();
    }
    
    /**
    * Calcula a diferenca entre a hora actual e recebida por parametro.
    */
    public static int diferenca(GregorianCalendar horaP){
        int hora1Mil;
        int horaMil;
        
        hora1Mil = horaActual.get(GregorianCalendar.SECOND)  + (horaActual.get(GregorianCalendar.MINUTE) * 60 ) + (horaActual.get(GregorianCalendar.HOUR_OF_DAY) * 60 * 60 );
        horaMil  = horaP.get(GregorianCalendar.SECOND)   + (horaP.get(GregorianCalendar.MINUTE)  * 60 ) + (horaP.get(GregorianCalendar.HOUR_OF_DAY)  * 60 * 60 );
        
        return (hora1Mil - horaMil);
    }
    
    /**
    * Actuliza o estado de todos os voos.
    */
    public static void actualizaTodosEstados(){
        TreeSet<Voo> copiaMapa = mapaVoos.getMapaHora();
        int dif;
        int x;
        int y = (120*60);
        Iterator<Voo> it = copiaMapa.iterator();
        Voo voo = null;
        boolean stop = false;
        ArrayList<Passageiro> lista0 = null;
        ArrayList<Passageiro> lista1;
        Random gerador = new Random();
       
        while(it.hasNext() && !stop){
            voo = it.next();
            
            //Verificar se a do tipo comercial para preencher a lista de espera
            if ((voo.getClass().getName().compareToIgnoreCase("VooComercial")) == 0){
                x = gerador.nextInt(3);
                // Se a lista de passageiros tiver menos pessoas que a capacidade maxima
                // preenche lista de espera
                lista0 = voo.getPassageiros();
                lista1 = new ArrayList<Passageiro>();
                if ( lista0.size() == voo.getEstado().getAeronave().getMPassag() ){
                    if ( x > 0) {
                        lista1 = fazListaPassageiros(x, lista0);
                    }
                }
                voo.setListaEspera(lista1);
            }
            
            dif = diferenca(voo.getHoraPartida());
            
            if ( (dif > y) ) {
                x = gerador.nextInt(10);
                if ( x >= 8 ){
                    voo.getEstadoC().setEstado(Estados.CANCELADO);
                    voo.getEstadoC().setObs("Condicoes climatericas");
                    //Cancelado
                }else{
                    voo.getEstadoC().setEstado(Estados.NOAR);
                    //conluido
                }
            }else{
                if ( dif > 0 ){
                    x = gerador.nextInt(10);
                    if ((x % 2) == 0){
                        voo.getEstadoC().setEstado(Estados.ATRASO);
                        voo.getEstadoC().setObs("Problemas tecnicos");
                    }else{
                        voo.getEstadoC().setEstado(Estados.CANCELADO);
                        voo.getEstadoC().setObs("Condicoes climatericas");
                    }
                        //Fazer metodo que da EM VOO ou ATRASADO
                }else{
                    if ( dif > -(60 * 60) ){
                        voo.listaEmbarque();
                        voo.getEstadoC().setEstado(Estados.PREPARACAO2);
                        //PREP 2
                    }else{
                        if ( dif > -(120 * 60 )){
                            voo.tempoCarregamentoListaCarga();
                            voo.getEstadoC().setEstado(Estados.PREPARACAO1);
                            //PREP 1
                        }else{ 
                            stop = true;
                        }
                    }
                }
            }
        }
        Scanner in = new Scanner(System.in);
        System.out.print("\n\nEstados actualizados. Prima enter para continuar.");
        in.nextLine();
        in.close();
    }
    
    public static ArrayList<Passageiro>  fazListaPassageiros(int numElementos, ArrayList<Passageiro> listaA){
        Passageiro[] passageiro = new Passageiro[100];
        
        //Depois temos que ver onde meter isto tudo
        passageiro[0] = new Passageiro("abaye","Humberto Delgado","Portuguesa","960000100");
        passageiro[1] = new Passageiro("abcde","Joao Manzarra","Portuguesa","960000001");
        passageiro[2] = new Passageiro("bbcde","Barbara Guimaraes","Portuguesa","960000002");
        passageiro[3] = new Passageiro("cbcde","Fatmia Lopes","Portuguesa","960000003");
        passageiro[4] = new Passageiro("dbcde","Jorge Gabriel","Portuguesa","960000004");
        passageiro[5] = new Passageiro("ebcde","Tania Oliveira","Portuguesa","960000005");
        passageiro[6] = new Passageiro("fbcde","Julia Pinheiro","Portuguesa","960000006");
        passageiro[7] = new Passageiro("gbcde","Jose Socrates","Portuguesa","960000007");
        passageiro[8] = new Passageiro("hbcde","Paulo Portas","Portuguesa","960000008");
        passageiro[9] = new Passageiro("ibcde","Francisco Louca","Portuguesa","960000009");
        passageiro[10] = new Passageiro("jbcde","Passos Coelho","Portuguesa","960000010");
        passageiro[11] = new Passageiro("kbcde","Pinto da Costa","Portuguesa","960000011");
        passageiro[12] = new Passageiro("lbcde","Paulo Futre","Portuguesa","960000012");
        passageiro[13] = new Passageiro("mbcde","Jose Coelho","Portuguesa","960000013");
        passageiro[14] = new Passageiro("nbcde","Paula Neves","Portuguesa","960000014");
        passageiro[15] = new Passageiro("obcde","Domingos Paciencia","Portuguesa","960000015");
        passageiro[16] = new Passageiro("pbcde","Catarina Furtado","Portuguesa","960000016");
        passageiro[17] = new Passageiro("qbcde","Clara de Sousa","Portuguesa","960000017");
        passageiro[18] = new Passageiro("rbcde","Maria de Medeiros","Portuguesa","960000018");
        passageiro[19] = new Passageiro("sbcde","Joaquim de Almeida","Portuguesa","960000019");
        passageiro[20] = new Passageiro("tbcde","Tony Carreira","Portuguesa","960000020");
        passageiro[21] = new Passageiro("ubcde","Simone de Oliveira","Portuguesa","960000021");
        passageiro[22] = new Passageiro("vbcde","Manuela Guedes","Portuguesa","960000022");
        passageiro[23] = new Passageiro("wbcde","Joao Pinto","Portuguesa","960000023");
        passageiro[24] = new Passageiro("xbcde","Nuno Gomes","Portuguesa","960000024");
        passageiro[25] = new Passageiro("ybcde","Claudia Raia","Brasileira","960000025");
        passageiro[26] = new Passageiro("zbcde","Jorge Jesus","Portuguesa","960000026");
        passageiro[27] = new Passageiro("aacde","Paulo Rangel","Portuguesa","960000027");
        passageiro[28] = new Passageiro("accde","Strauss Khan","Francesa","960000028");
        passageiro[29] = new Passageiro("adcde","Michael Jackson","Norte Americana","960000029");
        passageiro[30] = new Passageiro("aecde","Sadam Hussein","Iraquiana","960000030");
        passageiro[31] = new Passageiro("afcde","Angela Merkel","Alema","960000031");
        passageiro[32] = new Passageiro("agcde","Luciana Abreu","Portuguesa","960000032");
        passageiro[33] = new Passageiro("ahcde","Luis Figo","Portuguesa","960000033");
        passageiro[34] = new Passageiro("aicde","Paulo Bento","Portuguesa","960000034");
        passageiro[35] = new Passageiro("ajcde","Jorge Sampaio","Portuguesa","960000035");
        passageiro[36] = new Passageiro("akcde","Cavaco Silva","Portuguesa","960000036");
        passageiro[37] = new Passageiro("alcde","Cristiano Ronaldo","Portuguesa","960000037");
        passageiro[38] = new Passageiro("amcde","Jose Mourinho","Portuguesa","960000038");
        passageiro[39] = new Passageiro("ancde","Carla Matadinho","Portuguesa","960000039");
        passageiro[40] = new Passageiro("aocde","Vitor Baia","Portuguesa","960000040");
        passageiro[41] = new Passageiro("apcde","Fernanda Serrano","Portuguesa","960000041");
        passageiro[42] = new Passageiro("aqcde","Sofia Alves","Portuguesa","960000042");
        passageiro[43] = new Passageiro("arcde","Diogo Morgado","Portuguesa","960000043");
        passageiro[44] = new Passageiro("ascde","Silvia Alberto","Portuguesa","960000044");
        passageiro[45] = new Passageiro("atcde","Diogo infante","Portuguesa","960000045");
        passageiro[46] = new Passageiro("aucde","Judite de Sousa","Portuguesa","960000046");
        passageiro[47] = new Passageiro("avcde","Santana Lopes","Portuguesa","960000047");
        passageiro[48] = new Passageiro("awcde","Durao Barroso","Portuguesa","960000048");
        passageiro[49] = new Passageiro("axcde","Valentim Loureiro","Portuguesa","960000049");
        passageiro[50] = new Passageiro("aycde","Odete Santos","Portuguesa","960000050");
        passageiro[51] = new Passageiro("azcde","Manuel Alegre","Portuguesa","960000051");
        passageiro[52] = new Passageiro("abade","Rui Rio","Portuguesa","960000052");
        passageiro[53] = new Passageiro("abbde","Fatima Felgueiras","Portuguesa","960000053");
        passageiro[54] = new Passageiro("abdde","Sonia Araujo","Portuguesa","960000054");
        passageiro[55] = new Passageiro("abede","Joao Baiao","Portuguesa","960000055");
        passageiro[56] = new Passageiro("abfde","Teresa Guilherme","Portuguesa","960000056");
        passageiro[57] = new Passageiro("abgde","Catarina Furtado","Portuguesa","960000057");
        passageiro[58] = new Passageiro("abhde","Nuno Graciano","Portuguesa","960000058");
        passageiro[59] = new Passageiro("abide","Rita Ferro Rodrigues","Portuguesa","960000059");
        passageiro[60] = new Passageiro("abjde","Naide Gomes","Portuguesa","960000060");
        passageiro[61] = new Passageiro("abkde","Nelson Evora","Portuguesa","960000061");
        passageiro[62] = new Passageiro("ablde","Ricardo Araujo","Portuguesa","960000062");
        passageiro[63] = new Passageiro("abmde","Fernando Rocha","Portuguesa","960000063");
        passageiro[64] = new Passageiro("abnde","Bruno Nogueira","Portuguesa","960000064");
        passageiro[65] = new Passageiro("abode","Nuno Markl","Portuguesa","960000065");
        passageiro[66] = new Passageiro("abpde","Fernando Alvim","Portuguesa","960000066");
        passageiro[67] = new Passageiro("abqde","Herman Jose","Portuguesa","960000067");
        passageiro[68] = new Passageiro("abrde","Marco Horacio","Portuguesa","960000068");
        passageiro[69] = new Passageiro("absde","Maria Rueff","Portuguesa","960000069");
        passageiro[70] = new Passageiro("abtde","David Fonseca","Portuguesa","960000070");
        passageiro[71] = new Passageiro("abude","Angelico Vieira","Portuguesa","960000071");
        passageiro[72] = new Passageiro("abvde","Joao Pedro pais","Portuguesa","960000072");
        passageiro[73] = new Passageiro("abwde","Julio Magalhaes","Portuguesa","960000073");
        passageiro[74] = new Passageiro("abxde","Joao Carvalho","Portuguesa","960000074");
        passageiro[75] = new Passageiro("abyde","Luis Ribas","Portuguesa","960000075");
        passageiro[76] = new Passageiro("abzde","Diana Chaves","Portuguesa","960000076");
        passageiro[77] = new Passageiro("abaae","Rita Pereira","Portuguesa","960000077");
        passageiro[78] = new Passageiro("ababe","Soraia Chaves","Portuguesa","960000078");
        passageiro[79] = new Passageiro("abace","Alexandra Lencastre","Portuguesa","960000079");
        passageiro[80] = new Passageiro("abaee","Nuria Madruga","Portuguesa","960000080");
        passageiro[81] = new Passageiro("abafe","Joao Moutinho","Portuguesa","960000081");
        passageiro[82] = new Passageiro("abage","Simao Sabrosa","Portuguesa","960000082");
        passageiro[83] = new Passageiro("abahe","Ricardo Quaresma","Portuguesa","960000083");
        passageiro[84] = new Passageiro("abaie","Rui Costa","Portuguesa","960000084");
        passageiro[85] = new Passageiro("abaje","Hugo Almeida","Portuguesa","960000085");
        passageiro[86] = new Passageiro("abake","Fernando Couto","Portuguesa","960000086");
        passageiro[87] = new Passageiro("abale","Pedro Pauleta","Portuguesa","960000087");
        passageiro[88] = new Passageiro("abame","Lobo Antunes","Portuguesa","960000088");
        passageiro[89] = new Passageiro("abane","Fernando Pessoa","Portuguesa","960000089");
        passageiro[90] = new Passageiro("abaoe","Eca de Queiros","Portuguesa","960000090");
        passageiro[91] = new Passageiro("abape","Camilo Castelo Branco","Portuguesa","960000091");
        passageiro[92] = new Passageiro("abaqe","Paulo Coelho","Portuguesa","960000092");
        passageiro[93] = new Passageiro("abare","Florbela Espanca","Portuguesa","960000093");
        passageiro[94] = new Passageiro("abase","Gil Vicente","Portuguesa","960000094");
        passageiro[95] = new Passageiro("abate","Sofia Mello Breyner","Portuguesa","960000095");
        passageiro[96] = new Passageiro("abaue","Luis Vaz Camoes","Portuguesa","960000096");
        passageiro[97] = new Passageiro("abave","Joao Melo","Portuguesa","960000097");
        passageiro[98] = new Passageiro("abawe","Jose Regio","Portuguesa","960000098");
        passageiro[99] = new Passageiro("abaxe","Maria Elisa","Portuguesa","960000099");

        int contador = 0, num;
        ArrayList<Passageiro> lista = new ArrayList<Passageiro>();
        Random gerador = new Random();
        
        if(listaA == null) ;
            listaA = new ArrayList<Passageiro>();
        
        while(contador < numElementos){
            num = gerador.nextInt(100);
            
            if (!lista.contains(passageiro[num]) && !listaA.contains(passageiro[num]) ){
                lista.add((passageiro[num]).clone());
                contador++;
            }
        }

        return lista;

    }
    
    public static ArrayList<Carga>  fazListaCarga(int numElementos){
        
        Carga[] carga;
        carga = new Carga[100];
        
        carga[0] = new CargaNormal("C00", 1.15, "Bagagem", 0.200);
        carga[1] = new CargaNormal("C01",21.0, "Mala", 0.290);
        carga[2] = new CargaNormal("C02",5.1, "Mochila", 0.050);
        carga[3] = new CargaNormal("C03",14.3, "Bagagem", 0.310);
        carga[4] = new CargaNormal("C04",15.5, "Bagagem", 0.200);
        carga[5] = new CargaNormal("C05",8.4, "Bagagem", 0.150);
        carga[6] = new CargaNormal("C06",5.6, "Mochila", 0.090);
        carga[7] = new CargaNormal("C07",6.9, "Bagagem", 0.200);
        carga[8] = new CargaNormal("C08",2.0, "Bolsa", 0.040);
        carga[9] = new CargaNormal("C09",16.2, "Bagagem", 0.143);
        carga[10] = new CargaNormal("C10",13.3, "Bagagem", 0.500);
        carga[11] = new CargaNormal("C11",11.54, "Bagagem", 0.100);
        carga[12] = new CargaNormal("C12",10.15, "Bagagem", 0.205);
        carga[13] = new CargaNormal("C13",6.98, "Bagagem", 0.630);
        carga[14] = new CargaNormal("C14",1.18, "Estojo", 0.009);
        carga[15] = new CargaNormal("C15",0.53, "Bagagem", 0.200);
        carga[16] = new CargaNormal("C16",9.90, "Bagagem", 0.130);
        carga[17] = new CargaNormal("C17",5.67, "Mochila", 0.050);
        carga[18] = new CargaNormal("C18",6.82, "Bagagem", 0.090);
        carga[19] = new CargaNormal("C19",13.91, "Bagagem", 0.120);
    
        carga[20] = new CargaAnimal("C20", 10.45, "Cao", 0.05);
        carga[21] = new CargaAnimal("C21", 5.3, "Gato", 0.05);
        carga[22] = new CargaAnimal("C22", 0.130, "Amster", 0.05);
        carga[23] = new CargaAnimal("C23", 0.080, "Passaros", 0.05);
        carga[24] = new CargaAnimal("C24", 4.0, "Galinhas", 0.05);
        carga[25] = new CargaAnimal("C25", 15.0, "Cao", 0.05);
        carga[26] = new CargaAnimal("C26", 7.7, "Gato",0.05 );
        carga[27] = new CargaAnimal("C27", 5.5, "Gato", 0.05);
        carga[28] = new CargaAnimal("C28", 0.075, "Passaros", 0.05);
        carga[29] = new CargaAnimal("C29", 4.34, "Gato", 0.05);
        carga[30] = new CargaAnimal("C30", 5.0, "Gato", 0.05);
        carga[31] = new CargaAnimal("C31", 0.300, "Passaros", 0.05);
        carga[32] = new CargaAnimal("C32", 7.0, "Passaros", 0.05);
        carga[33] = new CargaAnimal("C33", 0.140, "Passaros", 0.05);
        carga[34] = new CargaAnimal("C34", 0.200, "Amster", 0.05);
        carga[35] = new CargaAnimal("C35", 11.32, "Cao", 0.05);
        carga[36] = new CargaAnimal("C36",3.99, "Gato", 0.05);
        carga[37] = new CargaAnimal("C37", 15.23, "Cao", 0.05);
        carga[38] = new CargaAnimal("C38", 0.300, "Amster", 0.05);
        carga[39] = new CargaAnimal("C39", 8.0, "Gato", 0.05);

        carga[40] = new CargaQuimica("C40", 0.300, "Quimicos",0.01, "liquido", 0);
        carga[41] = new CargaQuimica("C41", 0.250, "PH",0.1, "liquido", 0);
        carga[42] = new CargaQuimica("C42", 0.900, "PH",0.2, "liquido", 0);
        carga[43] = new CargaQuimica("C43", 0.500, "Quimicos",0.23, "liquido", 0);
        carga[44] = new CargaQuimica("C44", 0.983, "Quimicos",0.900, "liquido", 0);
        carga[45] = new CargaQuimica("C45", 0.485, "PH",1.0, "liquido", 0);
        carga[46] = new CargaQuimica("C46", 0.684, "Quimicos",0.87, "liquido", 0);
        carga[47] = new CargaQuimica("C47", 0.768, "Quimicos",0.23, "liquido", 0);
        carga[48] = new CargaQuimica("C48", 0.347, "Quimicos",0.010, "liquido", 0);
        carga[49] = new CargaQuimica("C49", 0.763, "PH",0.0, "liquido", 0);
        carga[50] = new CargaQuimica("C50", 0.586, "PH",0.0, "liquido", 0);
        carga[51] = new CargaQuimica("C51", 0.867, "Quimicos",0.090, "liquido", 0);
        carga[52] = new CargaQuimica("C52", 0.284, "Quimicos",0.45, "liquido", 0);
        carga[53] = new CargaQuimica("C53", 0.199, "Quimicos",0.085, "liquido", 0);
        carga[54] = new CargaQuimica("C54", 0.400, "Quimicos",0.900, "liquido", 0);
        carga[55] = new CargaQuimica("C55", 0.756, "Quimicos",0.86, "liquido", 0);
        carga[56] = new CargaQuimica("C56", 0.574, "Quimicos",0.38, "liquido", 0);
        carga[57] = new CargaQuimica("C57", 0.186, "Quimicos",0.01, "liquido", 0);
        carga[58] = new CargaQuimica("C58", 0.900, "PH",0.09, "liquido", 0);
        carga[59] = new CargaQuimica("C59", 0.857, "Quimicos",0.9, "liquido", 0);

        carga[60] = new CargaAlimentar("C60",1.0,"Fruta",0.239, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[61] = new CargaAlimentar("C61",1.5,"Fruta",0.309, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[62] = new CargaAlimentar("C62",0.4,"Fruta",0.209, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[63] = new CargaAlimentar("C63",0.6,"Fruta",0.219, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[64] = new CargaAlimentar("C64",10.3,"Fruta",0.239, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[65] = new CargaAlimentar("C65",4.4,"Fruta",0.256, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[66] = new CargaAlimentar("C66",1.2,"Carne",0.459, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[67] = new CargaAlimentar("C67",1.6,"Carne",0.159, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[68] = new CargaAlimentar("C68",1.8,"Carne",0.259, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[69] = new CargaAlimentar("C69",1.3,"Carne",0.559, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[70] = new CargaAlimentar("C70",1.9,"Carne",0.469, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[71] = new CargaAlimentar("C71",2.0,"Carne",0.353, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[72] = new CargaAlimentar("C72",0.3,"Peixe",0.559, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[73] = new CargaAlimentar("C73",0.5,"Peixe",0.759, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[74] = new CargaAlimentar("C74",0.4,"Peixe",0.859, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[75] = new CargaAlimentar("C75",0.2,"Peixe",0.459, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[76] = new CargaAlimentar("C76",0.1,"Peixe",0.259, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[77] = new CargaAlimentar("C77",0.3,"Peixe",0.499, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[78] = new CargaAlimentar("C78",0.01,"Peixe",0.680, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        carga[79] = new CargaAlimentar("C79",0.1,"Peixe",0.559, new GregorianCalendar(2011, 06, 01, 0, 0, 0));
        
        carga[80] = new CargaVeiculo("C80",1500, "Carro", 30, "Ligeiro");
        carga[81] = new CargaVeiculo("C81",300, "Mota", 1, "Pesado");
        carga[82] = new CargaVeiculo("C82",1500, "Carro", 30, "Ligeiro");
        carga[83] = new CargaVeiculo("C83",1500, "Carro", 30, "Ligeiro");
        carga[84] = new CargaVeiculo("C84",1500, "Carro", 30, "Ligeiro");
        carga[85] = new CargaVeiculo("C85",5000, "Camiao", 60, "Pesado");
        carga[86] = new CargaVeiculo("C86",1500, "Carro", 30, "Ligeiro");
        carga[87] = new CargaVeiculo("C87",5000, "Carro", 60, "Pesado");
        carga[88] = new CargaVeiculo("C88",1500, "Carro", 30, "Ligeiro");
        carga[89] = new CargaVeiculo("C89",5000, "Carro", 60, "Pesado");
        carga[90] = new CargaVeiculo("C90",1500, "Carro", 30, "Ligeiro");
        carga[91] = new CargaVeiculo("C91",1500, "Carro", 30, "Ligeiro");
        carga[92] = new CargaVeiculo("C92",1500, "Carro", 30, "Ligeiro");
        carga[93] = new CargaVeiculo("C93",1500, "Carro", 30, "Ligeiro");
        carga[94] = new CargaVeiculo("C94",1500, "Carro", 30, "Ligeiro");
        carga[95] = new CargaVeiculo("C95",1500, "Carro", 30, "Ligeiro");
        carga[96] = new CargaVeiculo("C96",1500, "Carro", 30, "Ligeiro");
        carga[97] = new CargaVeiculo("C97",1500, "Carro", 30, "Ligeiro");
        carga[98] = new CargaVeiculo("C98",1500, "Carro", 30, "Ligeiro");
        carga[99] = new CargaVeiculo("C99",5000, "Carro", 60, "Pesado");

        int contador = 0, num;
        ArrayList<Carga> lista = new ArrayList<Carga>();
        Random gerador = new Random();

        while(contador < numElementos){
            num = gerador.nextInt(100);
            if (!lista.contains(carga[num]) ){
                lista.add(carga[num].clone());
                contador++;
            }
        }

        return lista;

    }
    
    public static ArrayList<FTripulacao>  fazListaTripulacao(){
        
        
        FTripulacao[] tripulacaoC;
        tripulacaoC = new FTripulacao[5];
    
        FTripulacao[] tripulacaoCP;
        tripulacaoCP = new FTripulacao[5];

        FTripulacao[] tripulacaoH;
        tripulacaoH = new FTripulacao[10];
        
        tripulacaoC[0] = new FTripulacao("Comandante", "Henrique Gomes", "Portugesa");
        tripulacaoC[1] = new FTripulacao("Comandante", "Luis Chaves", "Portugesa");
        tripulacaoC[2] = new FTripulacao("Comandante", "Nuno Felgueiras", "Francesa");
        tripulacaoC[3] = new FTripulacao("Comandante", "Fatima Furtado", "Espanhola");
        tripulacaoC[4] = new FTripulacao("Comandante", "Jose Evora", "Inglesa");
        
        tripulacaoCP[0] = new FTripulacao("Co-Piloto", "Lobo Gomes", "Portugesa");
        tripulacaoCP[1] = new FTripulacao("Co-Piloto", "Henrique Queiros", "Portugesa");
        tripulacaoCP[2] = new FTripulacao("Co-Piloto", "Pedro Araujo", "Portugesa");
        tripulacaoCP[3] = new FTripulacao("Co-Piloto", "Fernando Baiao", "Portugesa");
        tripulacaoCP[4] = new FTripulacao("Co-Piloto", "Ricardo Moutinho", "Portugesa");
        
        tripulacaoH[0] = new FTripulacao("Hospedeira", "Fatima Coelho", "Portuguesa");
        tripulacaoH[1] = new FTripulacao("Hospedeira", "Andreia Andrade", "Portuguesa");
        tripulacaoH[2] = new FTripulacao("Hospedeira", "Catarina Castelo", "Portuguesa");
        tripulacaoH[3] = new FTripulacao("Hospedeira", "Mariana Melo", "Portuguesa");
        tripulacaoH[4] = new FTripulacao("Hospedeira", "Catarina Santos", "Francesa");
        tripulacaoH[5] = new FTripulacao("Hospedeira", "Simane de Sousa", "Francesa");
        tripulacaoH[6] = new FTripulacao("Hospedeira", "Carla Machado", "Inglesa");
        tripulacaoH[7] = new FTripulacao("Hospedeira", "Rita Oliveira", "Frances");
        tripulacaoH[8] = new FTripulacao("Hospedeira", "Diana Costa", "Frances");
        tripulacaoH[9] = new FTripulacao("Hospedeira", "Ana Silva", "Frances");

        int num;
        ArrayList<FTripulacao> lista = new ArrayList<FTripulacao>();
        Random gerador = new Random();

        num = gerador.nextInt(5);
        lista.add(tripulacaoC[num].clone());
        lista.add(tripulacaoCP[num].clone());
        lista.add(tripulacaoH[num].clone());
        lista.add(tripulacaoH[num+5].clone());

        return lista;

    }
    
    public static TreeMap<String, Voo> criaTodosVoos(){

        GregorianCalendar[] horas = new GregorianCalendar[50];
        
        horas[0] = new GregorianCalendar(0,0,0,1,0);
        horas[1] = new GregorianCalendar(0,0,0,1,30);
        horas[2] = new GregorianCalendar(0,0,0,2,0);
        horas[3] = new GregorianCalendar(0,0,0,2,30);
        horas[4] = new GregorianCalendar(0,0,0,3,0);
        horas[5] = new GregorianCalendar(0,0,0,3,30);
        horas[6] = new GregorianCalendar(0,0,0,4,0);

        horas[7] = new GregorianCalendar(0,0,0,4,30);
        horas[8] = new GregorianCalendar(0,0,0,5,0);
        horas[9] = new GregorianCalendar(0,0,0,5,30);
        horas[10] = new GregorianCalendar(0,0,0,6,0);
        horas[11] = new GregorianCalendar(0,0,0,6,30);
        horas[12] = new GregorianCalendar(0,0,0,7,0);
        horas[13] = new GregorianCalendar(0,0,0,7,30);
        horas[14] = new GregorianCalendar(0,0,0,8,0);

        horas[15] = new GregorianCalendar(0,0,0,8,30);
        horas[16] = new GregorianCalendar(0,0,0,9,0);
        horas[17] = new GregorianCalendar(0,0,0,9,30);
        horas[18] = new GregorianCalendar(0,0,0,10,0);
        horas[19] = new GregorianCalendar(0,0,0,10,30);
        horas[20] = new GregorianCalendar(0,0,0,11,0);
        horas[21] = new GregorianCalendar(0,0,0,11,30);
        horas[22] = new GregorianCalendar(0,0,0,12,0);
        
        horas[23] = new GregorianCalendar(0,0,0,12,30);
        horas[24] = new GregorianCalendar(0,0,0,13,0);
        horas[25] = new GregorianCalendar(0,0,0,13,30);
        horas[26] = new GregorianCalendar(0,0,0,14,0);
        horas[27] = new GregorianCalendar(0,0,0,14,30);
        horas[28] = new GregorianCalendar(0,0,0,15,0);
        horas[29] = new GregorianCalendar(0,0,0,15,30);
        horas[30] = new GregorianCalendar(0,0,0,16,0);

        horas[31] = new GregorianCalendar(0,0,0,16,30);
        horas[32] = new GregorianCalendar(0,0,0,17,0);
        horas[33] = new GregorianCalendar(0,0,0,17,30);
        horas[34] = new GregorianCalendar(0,0,0,18,0);
        horas[35] = new GregorianCalendar(0,0,0,18,30);
        horas[36] = new GregorianCalendar(0,0,0,19,0);
        horas[37] = new GregorianCalendar(0,0,0,19,30);
        horas[38] = new GregorianCalendar(0,0,0,20,0);

        horas[39] = new GregorianCalendar(0,0,0,20,30);
        horas[40] = new GregorianCalendar(0,0,0,21,0);
        horas[41] = new GregorianCalendar(0,0,0,21,30);
        horas[42] = new GregorianCalendar(0,0,0,22,0);
        horas[43] = new GregorianCalendar(0,0,0,22,30);
        horas[44] = new GregorianCalendar(0,0,0,23,0);
        horas[45] = new GregorianCalendar(0,0,0,23,30);
        horas[46] = new GregorianCalendar(0,0,0,0,1);

        horas[47] = new GregorianCalendar(0,0,0,0,30);
        horas[48] = new GregorianCalendar(0,0,0,13,45);
        horas[49] = new GregorianCalendar(0,0,0,15,15);
        
        Aeronave[] aeronaveP;
        aeronaveP = new Aeronave[5];
        
        Aeronave[] aeronaveC;
        aeronaveC = new Aeronave[5];
        
        Aeronave[] aeronaveG;
        aeronaveG = new Aeronave[5];
        
        Aeronave[] aeronaveI;
        aeronaveI = new Aeronave[5];
        
        Aeronave[] aeronaveH;
        aeronaveH = new Aeronave[5];
        
        String[] resp = new String[10];
        resp[0] = "TAP";
        resp[1] = "SATA";
        resp[2] = "ATLANTIC";
        resp[3] = "HiFly";
        resp[4] = "LuzAir";
        resp[5] = "Orbest";
        resp[6] = "White";
        resp[7] = "Iberia";
        resp[8] = "Lufthansa";
        resp[9] = "Luxair";
        
        aeronaveP[0] = new AeronaveAviaoPassageiros("ANP1", "Aviao de Passageiros", 30, 25, 400);
        aeronaveP[1] = new AeronaveAviaoPassageiros("ANP2", "Aviao de Passageiros", 30, 50, 340);
        aeronaveP[2] = new AeronaveAviaoPassageiros("ANP3", "Aviao de Passageiros", 30, 50, 450);
        aeronaveP[3] = new AeronaveAviaoPassageiros("ANP4", "Aviao de Passageiros", 30, 100, 600);
        aeronaveP[4] = new AeronaveAviaoPassageiros("ANP5", "Aviao de Passageiros", 30, 30, 390);
        
        aeronaveC[0] = new AeronaveAviaoCarga("ANC0", "Aviao de Carga0", 30, 30, 300);
        aeronaveC[1] = new AeronaveAviaoCarga("ANC1", "Aviao de Carga1", 30, 400, 280);
        aeronaveC[2] = new AeronaveAviaoCarga("ANC2", "Aviao de Carga2", 30, 250, 450);
        aeronaveC[3] = new AeronaveAviaoCarga("ANC3", "Aviao de Carga3", 30, 300, 400);
        aeronaveC[4] = new AeronaveAviaoCarga("ANC4", "Aviao de Carga4", 30, 300, 440);
        
        aeronaveG[0] = new AeronaveAviaoCombate("FX1", "Aviao de Guerra", 30, 150, 400);
        aeronaveG[1] = new AeronaveAviaoCombate("FX2", "Bombardeiro1", 30, 250, 350);
        aeronaveG[2] = new AeronaveAviaoCombate("FX3", "Aviao Guerra1", 30, 300, 300);
        aeronaveG[3] = new AeronaveAviaoCombate("FX4", "Bombardeiro2", 30, 250, 350);
        aeronaveG[4] = new AeronaveAviaoCombate("FX5", "Aviao Guerra2", 30, 300, 300);
        
        aeronaveI[0] = new AeronaveAviaoIncendios("ANI1", "Helicoptero dos Bombeiros1", 30, 50, 100);
        aeronaveI[1] = new AeronaveAviaoIncendios("ANI2", "Aviao de Incendios1", 30, 250, 200);
        aeronaveI[2] = new AeronaveAviaoIncendios("ANI3", "Aviao de Incendios2", 30, 250, 200);
        aeronaveI[3] = new AeronaveAviaoIncendios("ANI4", "Helicoptero dos Bombeiros2", 30, 50, 100);
        aeronaveI[4] = new AeronaveAviaoIncendios("ANI5", "Aviao de Incendios3", 30, 250, 200);
        
        aeronaveH[0] = new AeronaveHelicoptero("ANH1", "Heli da Cruz Vermelha1", 30, 5, 200);
        aeronaveH[1] = new AeronaveHelicoptero("ANH2", "Helicoptero1", 30, 5, 200);
        aeronaveH[2] = new AeronaveHelicoptero("ANH3", "Heli da Cruz Vermelha2", 30, 5, 200);
        aeronaveH[3] = new AeronaveHelicoptero("ANH4", "Helicoptero2", 30, 5, 200);
        aeronaveH[4] = new AeronaveHelicoptero("ANH5", "Heli da Cruz Vermelha3", 30, 5, 200);
        
        String[] destinos = new String[50];

        destinos[0] = "Porto";
        destinos[1] = "Lisboa";
        destinos[2] = "Faro";
        destinos[3] = "Paris";
        destinos[4] = "Funchal";
        destinos[5] = "Porto Santo";
        destinos[6] = "Madrid";
        destinos[7] = "Barcelona";
        destinos[8] = "Sevilha";
        destinos[9] = "Palma de Maiorca";
        destinos[10] = "Tenerife";
        destinos[11] = "Corsega";
        destinos[12] = "Ilhas Caimao";
        destinos[13] = "Marselha";
        destinos[14] = "Bordeus";
        destinos[15] = "Berlim";
        destinos[16] = "Dublin";
        destinos[17] = "Cidade do Cabo";
        destinos[18] = "Cancun";
        destinos[19] = "Cidade do Mexico";
        destinos[20] = "Miami";
        destinos[21] = "Nova Iorque";
        destinos[22] = "Dallas";
        destinos[23] = "Los Angeles";
        destinos[24] = "Moscovo";
        destinos[25] = "Washington";
        destinos[26] = "Viena";
        destinos[27] = "Bruxelas";
        destinos[28] = "Brasilia";
        destinos[29] = "Pekim";
        destinos[30] = "Copenhaga";
        destinos[31] = "Praga";
        destinos[32] = "Cairo";
        destinos[33] = "San Salvador";
        destinos[34] = "Dili";
        destinos[35] = "Atenas";
        destinos[36] = "Jakarta";
        destinos[37] = "Helsinquia";
        destinos[38] = "Jerusalem";
        destinos[39] = "Tokyo";
        destinos[40] = "Roma";
        destinos[41] = "Luxemburgo";
        destinos[42] = "Monaco";
        destinos[43] = "Varsovia";
        destinos[44] = "Bucarest";
        destinos[45] = "Singapura";
        destinos[46] = "Estocolmo";
        destinos[47] = "Caracas";
        destinos[48] = "Beirute";
        destinos[49] = "Bissau";

        String[] ramosFA = new String[5];
        ramosFA[0] = "Paraquedistas";
        ramosFA[1] = "Marinha";
        ramosFA[2] = "Fuzileiros";
        ramosFA[3] = "Comandos";
        ramosFA[4] = "Forca Aerea";
        
        String[] origem = new String[2];
        
        origem[0] = "Ministerio";
        origem[1] = "Governo";
        
        int contador = 0, num;
        ArrayList<Passageiro> nLista = new ArrayList<Passageiro>();
        Random gerador = new Random();
        TreeMap<String, Voo> mapa = new TreeMap<String, Voo>();
        while(contador < 20){
                mapa.put(Integer.toString(contador), new VooComercial(String.valueOf(contador),
                resp[gerador.nextInt(10)], nLista = fazListaPassageiros(gerador.nextInt(30), new ArrayList<Passageiro>()), fazListaCarga(20),
                destinos[gerador.nextInt(50)],
                new Estado(Estados.ESPECIFICADO,
                aeronaveP[gerador.nextInt(5)],
                fazListaTripulacao(),
                gerador.nextInt(50), null, "" ),
                horas[gerador.nextInt(50)],
                fazListaPassageiros(gerador.nextInt(10), new ArrayList<Passageiro>()) ));
                contador++;
        }
        
        while(contador < 40){
                mapa.put(Integer.toString(contador), new VooGovernamental(Integer.toString(contador),
                resp[gerador.nextInt(10)], nLista = fazListaPassageiros(gerador.nextInt(30), new ArrayList<Passageiro>()), fazListaCarga(20), 
                destinos[gerador.nextInt(50)], 
                new Estado(Estados.ESPECIFICADO, 
                aeronaveP[gerador.nextInt(5)], 
                fazListaTripulacao(),
                gerador.nextInt(50), null, "" ),
                gerador.nextInt(30), //Numero de elementos do estado
                gerador.nextInt(30), //Numero de elementos Jornalistas
                gerador.nextInt(30), //Numero de elementos Convidados
                origem[gerador.nextInt(2)],
                horas[gerador.nextInt(50)] ));
                contador++;
        }
        
        while(contador < 50){
                mapa.put(Integer.toString(contador), new VooMilitar(Integer.toString(contador),
                resp[gerador.nextInt(10)], nLista = fazListaPassageiros(gerador.nextInt(30), new ArrayList<Passageiro>()), fazListaCarga(20), 
                destinos[gerador.nextInt(50)], 
                new Estado(Estados.ESPECIFICADO, 
                aeronaveI[gerador.nextInt(5)], 
                fazListaTripulacao(),
                gerador.nextInt(50), null, "" ),
                horas[gerador.nextInt(50)], // TEMPO DE VOO
                ramosFA[gerador.nextInt(5)], // RAMO DAS FOR�AS ARMADAS
                Integer.toString(gerador.nextInt(1000)),
                horas[gerador.nextInt(50)] ));
                contador++;
        }
        
        while(contador < 60){
                mapa.put(Integer.toString(contador), new VooMilitar(Integer.toString(contador),
                resp[gerador.nextInt(10)], nLista = fazListaPassageiros(gerador.nextInt(30), new ArrayList<Passageiro>()), fazListaCarga(20), 
                destinos[gerador.nextInt(50)], 
                new Estado(Estados.ESPECIFICADO, 
                aeronaveG[gerador.nextInt(5)], 
                fazListaTripulacao(),
                gerador.nextInt(50), null, "" ),
                horas[gerador.nextInt(50)], // TEMPO DE VOO
                ramosFA[gerador.nextInt(5)], // RAMO DAS FOR�AS ARMADAS
                Integer.toString(gerador.nextInt(1000)),
                horas[gerador.nextInt(50)] ));
                contador++;
        }
        
        while(contador < 70){
                mapa.put(Integer.toString(contador), new VooMilitar(Integer.toString(contador),
                resp[gerador.nextInt(10)], nLista = fazListaPassageiros(gerador.nextInt(30), new ArrayList<Passageiro>()), fazListaCarga(20), 
                destinos[gerador.nextInt(50)], 
                new Estado(Estados.ESPECIFICADO, 
                aeronaveC[gerador.nextInt(5)], 
                fazListaTripulacao(),
                gerador.nextInt(50), null, "" ),
                horas[gerador.nextInt(50)], // TEMPO DE VOO
                ramosFA[gerador.nextInt(5)], // RAMO DAS FORCAS ARMADAS
                Integer.toString(gerador.nextInt(1000)),
                horas[gerador.nextInt(50)] ));
                contador++;
        }
        
        while(contador < 80){
                mapa.put(Integer.toString(contador), new VooPrivado(Integer.toString(contador),
                resp[gerador.nextInt(10)], nLista = fazListaPassageiros(gerador.nextInt(30), new ArrayList<Passageiro>()), fazListaCarga(20), 
                destinos[gerador.nextInt(50)], 
                new Estado(Estados.ESPECIFICADO, 
                aeronaveH[gerador.nextInt(5)], 
                fazListaTripulacao(),
                gerador.nextInt(50), null, "" ),
                horas[gerador.nextInt(50)] ));
                contador++;
        }
        
        while(contador < 100){
                mapa.put(Integer.toString(contador), new VooPrivado(Integer.toString(contador),
                resp[gerador.nextInt(10)], nLista = fazListaPassageiros(gerador.nextInt(30), new ArrayList<Passageiro>()), fazListaCarga(20), 
                destinos[gerador.nextInt(50)], 
                new Estado(Estados.ESPECIFICADO, 
                aeronaveH[gerador.nextInt(5)], 
                fazListaTripulacao(),
                gerador.nextInt(50), null, "" ),
                horas[gerador.nextInt(50)] ));
                contador++;
        }
        
        return mapa;
    }
} 
