import java.util.TreeMap;
import java.util.GregorianCalendar;
import java.util.ArrayList;
import java.io.Serializable;
import java.util.Iterator;
import java.util.HashMap;
import java.util.TreeSet;

/**
 * Classe que engloba todo um mapa de voos;
 */
public class MapaVoos implements Serializable
{
    private TreeMap<String, Voo> mapa;
    
    /**
     *Construtores;
     */
    public MapaVoos(){
        mapa = new TreeMap<String, Voo>();
    }
    
    public MapaVoos(TreeMap<String, Voo> mapaV){
        mapa = new TreeMap<String, Voo>(); 
        for(Voo v : mapaV.values()){
            this.mapa.put(v.getCodigo(), v.clone());
        }
    }
    
    public MapaVoos(MapaVoos obj){
        mapa = obj.getMapa();
    }
    
    /**
     * Devolve o mapa de voos;
     */
    public TreeMap<String, Voo> getMapa(){
        TreeMap<String, Voo> copiaMapa = new TreeMap<String, Voo>();
        for(Voo v : mapa.values()){
            copiaMapa.put(v.getCodigo(), v.clone());
        }
        return copiaMapa;
    }
    
    /**
     * Devolve os voos do dia;
     */
    public ArrayList<Voo> getVoosDia(){
        ArrayList<Voo> listaVoo = new ArrayList<Voo>();
        for(Voo v : mapa.values()){
            listaVoo.add(v.clone());
        }
        return listaVoo;
    }
    
    /**
     * Devolve os voos num dado estado;
     */
    public ArrayList<String> getListaEstado(String estado){
        ArrayList<Voo> listaVoo         = getVoosDia();
        ArrayList<String> listaEstados  = new ArrayList<String>();
        
        for (Voo v : listaVoo){
            if ((((v.getEstado()).getEstado()).toString()).compareToIgnoreCase(estado) == 0){
                listaEstados.add(v.getCodigo());
            }
        }
        return listaEstados;
    }
    
    /**
     * Estado actual de um determinado VOO (devolve String);
     */
    public String estadoDoVoo(String codigoVoo){
        Estado estado = null;
        Iterator<Voo> it = mapa.values().iterator();
        boolean encontrado = false;
        Voo voo = null;
        
        while(it.hasNext() && !encontrado){
            voo = it.next();
            if(codigoVoo.equals(voo.getCodigo())){
                estado = voo.getEstado();
                encontrado = true;
            }
        }
        if (estado == null) return "Nao foi encontrado nenhum voo com o codigo pretendido.";
        return estado.getEstado().toString();
    }
    
    /**
     * Objecto VOO dado um codigo de voo;
     */
    public Voo objectoVoo(String codigoVoo){
        Iterator<Voo> it = mapa.values().iterator();
        boolean encontrado = false;
        Voo voo = null;
        
        while(it.hasNext() && !encontrado){
            voo = it.next();
            if(codigoVoo.equals(voo.getCodigo())) encontrado = true;
        }
        
        if ( !encontrado ) return null; 
        
        return voo;
    }
    
    /**
     * Limpa Mapa;
     */
    public void remMapa(){
        this.mapa.clear();
    }
    
    /**
     * Preenche o Mapa de Voos recebendo outro como argumento;
     */
    public void setMapa(TreeMap<String, Voo> mapaV){
        for(Voo v : mapaV.values()){
            this.mapa.put(v.getCodigo(), v.clone());
        }
    }
    
    /**
     * Tempo para a conclusao do carregamento num voo (dado o seu codigo);
     */
    public GregorianCalendar tempoConcluirCarga(String codigoVoo){
        GregorianCalendar tempoConclusao = new GregorianCalendar();
        Iterator<Voo> it = mapa.values().iterator();
        boolean encontrado = false;
        Voo voo = null;

        while(it.hasNext() && !encontrado){
            voo = it.next();
            if(codigoVoo.equals(voo.getCodigo())) {
                tempoConclusao = voo.tempoCarregamentoListaCarga();
                encontrado = true;
            }
        }
        
        return tempoConclusao;
    }
    
    /**
     * Verifica a diferenca (numero de pessoas) entre a lista de passageiros e a lista de embarque;
     */
    public String difPassageirosVoo(){
        int dif = 0, total=0;
        StringBuilder s = new StringBuilder();
        for(Voo v : mapa.values()){
            if( (v.getClass().getName().compareToIgnoreCase("VooComercial")) == 0 ) {
                dif = Math.abs(v.getPassageiros().size() - v.getEstado().getListaEmbarque().size());
                s.append("\n Codigo: "); s.append(v.getCodigo());
                s.append(" \t Lista de Passageiros: "); s.append(v.getPassageiros().size());
                s.append(" \t Lista de Embarque: "); s.append(v.getEstado().getListaEmbarque().size());
                s.append(" \t Diferenca: "); s.append(dif);
                total += dif;
            }
        }
        s.append("\n\n Total das diferencas: " + total);
        return s.toString(); 
    }
    
    /**
     * METODOS ESTATISTICOS
     */
    /**
     * Numero total de passageiros embarcados ate a hora actual, no mapa de voos;
     */
    public int totalPassageirosAteHoje(GregorianCalendar horaActual){
        int total = 0;
        GregorianCalendar agora = (GregorianCalendar) horaActual.clone();
        
        for(Voo v : mapa.values()){
            if(v.getHoraPartida().before(agora) && v.getClass().getName().equals("VooComercial")) 
                total += v.getEstado().getListaEmbarque().size();
        }
        
        return total;
    }
    
    /**
     * Total de carga embarcados ate a hora actual, no mapa de voos;
     */
    public float totalCargaAteHoje(GregorianCalendar horaActual){
        GregorianCalendar agora = (GregorianCalendar) horaActual.clone();
        float total = 0;
        ArrayList<Carga> lstCarga = new ArrayList<Carga>();
        
        for(Voo v : mapa.values()){
            if(v.getHoraPartida().before(agora)){
                lstCarga = v.getCarga();
                for(Carga c : lstCarga) total += c.getPeso();
            }
        }
        
        return total;
    }
    
    /**
     * ArrayList com todos os destinos visitados, no mapa de voos;
     */
    public ArrayList<String> destinosAteHoje(GregorianCalendar horaActual){
        GregorianCalendar agora = (GregorianCalendar) horaActual.clone();
        ArrayList<String> listaDestinos = new ArrayList<String>();
        int total = 0;
        for(Voo v : mapa.values()){
            if(v.getHoraPartida().before(agora)){
                if(!listaDestinos.contains(v.getDestino())) {
                    listaDestinos.add(v.getDestino());
                    total++;
                }
            }
        }
        listaDestinos.add("Total:"+Integer.toString(total));
        return listaDestinos;
    }
    
    /**
     * Numero de voos concluidos (cancelados ou no ar);
     */
    public int nVoosTerminados(){
        int voosProntos = 0;
        for(Voo v : mapa.values()){
            String est = v.getEstado().getEstado().toString();
            if ( est == "Cancelado" || est == "No Ar")
                voosProntos++;
        }
        return voosProntos;
    }
    
    /**
     * ArrayList de voos de um dado tipo e destino dados;
     */
    public ArrayList <String> vooTipoDestino(String tipo, String destino){
        ArrayList<String> lista = new ArrayList<String>();
        for(Voo v : mapa.values()){
            if ((((v.getClass().getName()).toString()).compareToIgnoreCase(tipo) == 0) && (v.getDestino().compareToIgnoreCase(destino)==0)){
                lista.add(v.getCodigo());
            }
        }
        return lista;
    }
    
    /**
     * HashMap a que cada codigo (correspondente a um estado) esta associado um Arraylist de voos nesse mesmo estado;
     */
    public HashMap<String, ArrayList<Voo>> getVooPorEstado(){
        HashMap<String, ArrayList<Voo>> listaVooEstado = new HashMap<String, ArrayList<Voo>>();
        
        ArrayList<Voo> estNoAR          = new ArrayList<Voo>();
        ArrayList<Voo> estCanc          = new ArrayList<Voo>();
        ArrayList<Voo> estPronto        = new ArrayList<Voo>();
        ArrayList<Voo> estPrep1         = new ArrayList<Voo>();
        ArrayList<Voo> estPrep2         = new ArrayList<Voo>();
        ArrayList<Voo> estPrep2Atraso   = new ArrayList<Voo>();
        ArrayList<Voo> estEspecificado  = new ArrayList<Voo>();
        
        for(Voo v : mapa.values()){
            switch (v.getEstado().getEstado()) {
                case ESPECIFICADO   : estEspecificado.add(v.clone()); break;
                case PREPARACAO1    : estPrep1.add(v.clone());  break;
                case PREPARACAO2    : estPrep2.add(v.clone()); break;
                case ATRASO         : estPrep2Atraso.add(v.clone()); break;
                case PRONTO         : estPronto.add(v.clone()); break;
                case CANCELADO      : estCanc.add(v.clone()); break;
                case NOAR           : estNoAR.add(v.clone()); break;
                default: break;
            } 
        }
        
        listaVooEstado.put("Especificado", estEspecificado);
        listaVooEstado.put("Preparacao 1", estPrep1);
        listaVooEstado.put("Preparacao 2", estPrep2);
        listaVooEstado.put("Preparacao 2 - Atrasado", estPrep2Atraso);
        listaVooEstado.put("Pronto", estPronto);
        listaVooEstado.put("No Ar", estNoAR);
        listaVooEstado.put("Cancelado", estCanc);
        
        return listaVooEstado;
    }
    
    /**
     * Imprime o actual mapa de voos;
     */
    public String imprimeMapaVoo(){
        StringBuilder s = new StringBuilder();
        for(Voo v : mapa.values()){
            s.append(v.toString());
        }
        return s.toString();
    }
    
    /**
     * TreeSet com voos ordenados pela hora de partida;
     */
    public TreeSet<Voo> getMapaHora(){
        TreeSet<Voo> copiaMapa = new TreeSet<Voo>(new CompHora());
        for( Voo v : this.mapa.values() ){
            copiaMapa.add(v);
        }
        return copiaMapa;       
    }
    
    /**
     * Adiciona um (objecto) voo ao mapa de voos;
     */
    public void addVoo(Voo obj){
        mapa.put(obj.getCodigo(), obj.clone());
    }
}
