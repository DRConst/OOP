import java.io.Serializable;
/**
 * Classe responsavel pelas Aeronaves e as suas caracteristicas.
 */
public abstract class Aeronave implements Serializable
{
    private String          matricula;          //Matricula Aeronave
    private String          desig;              //Designacao da Aeronave
    private int             maxPassag;          //Capacidade Maxima de Passageiros
    private int             maxCarga;           //Capacidade Maxima de Carga
    private int             maxVel;             //Velocidade Maxima
    
    /**
     * Construtor por omissao.
     */
    public Aeronave(){
        this.matricula   = "";
        this.desig       = "";
        this.maxPassag   = -1;
        this.maxCarga    = -1;
        this.maxVel      = -1;
    }
    
    /**
     * Construtor de uma Aeronave com uma determinada matricula, designacao, capacidade maxima de passageiros, velocidade maxima e capacidade maxima de carga.
     */
    public Aeronave(String matricula, String designacao, int maxPassageiros, int capacidadeMax, int velocidadeMax){
        this.matricula   = matricula;
        this.desig       = designacao;
        this.maxPassag   = maxPassageiros;
        this.maxCarga    = capacidadeMax;
        this.maxVel      = velocidadeMax;
    } 
    
    /**
     * Construtor de Aeronava atraves de uma outra aeronave.
     */
    public Aeronave(Aeronave obj){
        this.matricula   = obj.getMat();
        this.desig       = obj.getDes();
        this.maxPassag   = obj.getMPassag();
        this.maxCarga    = obj.getMCarga();
        this.maxVel      = obj.getMVel();
    }
    
    /**
     * Retorna a matricula da aeronave.
     */
    public String getMat()  { return matricula; }
    
    /**
     * Retorna a designacao da aeronave.
     */
    public String getDes()  { return desig; }
    
    /**
     * Retorna a capacidade maxima de passageiros da aeronave.
     */
    public int getMPassag() { return maxPassag; }
    
    /**
     * Retorna a capacidade maxima de carga da aeronave.
     */
    public int getMCarga()  { return maxCarga; }
    
    /**
     * Retorna a velocidade maxima da aeronave.
     */
    public int getMVel()    { return maxVel; }
    
    /**
     * Altera a matricula da aeronave.
     */
    public void setMar(String novaMatricula)    { matricula = novaMatricula; }
    
    /**
     * Altera a designacao da aeronave.
     */
    public void setDes(String novaDesignacao)   { desig = novaDesignacao; }
    
    /**
     * Altera a capacidade maxima de passageiros da aeronave.
     */
    public void setMPassag(int novaMaxPassag)   { maxPassag = novaMaxPassag; }
    
    /**
     * Altera a capacidade maxima da carga da aeronave.
     */
    public void setMCarga(int novaMaxCarga)     { maxCarga = novaMaxCarga; }
    
    /**
     * Altera a velocidade maxima da aeronave.
     */
    public void setMVel(int novaMaxVel)         { maxVel = novaMaxVel; }
    
    /**
     * Altera a capacidade maxima de passageiros da aeronave.
     */
    public abstract Aeronave clone();
    
    /**
     * Verifica se um dado objecto � igual � aeronave.
     */
    public abstract boolean equals(Object obj);
    
    /**
     * Converte uma aeronave numa String.
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append("Matricula: "); s.append(matricula);
        s.append(", Designacao: "); s.append(desig);
        s.append(", Numero Max. Passageiros: "); s.append(maxPassag);
        s.append(", Capacidade de Carga Maxima: "); s.append(maxCarga);
        s.append(", Velocidade Maxima: "); s.append(maxVel);
        return s.toString();
    }
}

