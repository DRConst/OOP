import java.util.GregorianCalendar;
import java.util.ArrayList;
import java.io.Serializable;

/**
 * Classe responsavel pelos voos e pelas suas caracteristicas;
 */
public abstract class Voo implements Serializable
{
    private String                  codigo;         //Codigo Voo
    private String                  entResponsavel; //Entidade Responsavel
    private ArrayList<Passageiro>   lPassageiros;   //Lista de Passageiros
    private ArrayList<Carga>        lCarga;         //Lista de Carga
    private String                  destino;        //Destino
    private GregorianCalendar       horaPartida;    //Hora de partida
    private Estado                  estado;         //Estado do Voo
    
    /**
     * Construtores
     */
    public Voo(){
        this.codigo          = "";
        this.entResponsavel  = "";
        this.lPassageiros    = new ArrayList<Passageiro>(); //new HashMap<String, Passageiro>();
        this.lCarga          = new ArrayList<Carga>(); //new HashMap<String, Carga>();
        this.destino         = "";
        this.horaPartida     = new GregorianCalendar();  
        this.estado          = new Estado();
    }
    
    public Voo(String codigo, String entResp, ArrayList<Passageiro> lPass, ArrayList<Carga> lCarg, String dest, Estado est, GregorianCalendar horaPart){
        this.codigo          = codigo;
        this.entResponsavel  = entResp;
        this.lPassageiros    = new ArrayList<Passageiro>();
        for(Passageiro p : lPass)
            lPassageiros.add(p.clone());
        this.lCarga          = new ArrayList<Carga>();
        for(Carga c : lCarg)
            lCarga.add(c.clone());
        this.destino         = dest;
        this.estado          = est;
        this.horaPartida     = (GregorianCalendar)horaPart.clone();
    }
    
    public Voo(Voo obj){
        this.codigo          = obj.getCodigo();
        this.entResponsavel  = obj.getResponsavel();
        this.lPassageiros    = obj.getPassageiros();
        this.lCarga          = obj.getCarga();
        this.destino         = obj.getDestino();
        this.estado          = obj.getEstado();
        this.horaPartida     = obj.getHoraPartida();
    }
    
    /**
     * Retorn a hora de partida;
     */
    public GregorianCalendar    getHoraPartida()    { return (GregorianCalendar) horaPartida.clone();}
    
    /**
     * Retorna o codigo de voo;
     */
    public String               getCodigo()         { return codigo; }
    
    /**
     * Retorna a entidade responsavel;
     */
    public String               getResponsavel()    { return entResponsavel; }
    
    /**
     * Retorna o ArrayList com os passageiros do voo;
     */
    public ArrayList<Passageiro> getPassageiros(){
        ArrayList<Passageiro> copialPassag = new ArrayList<Passageiro>();
        for(Passageiro p : lPassageiros) copialPassag.add(p.clone());
        return copialPassag;
    }
    
    /**
     * Retorn o ArrayList com a carga do voo;
     */
    public ArrayList<Carga> getCarga(){
        ArrayList<Carga> copiaLCarga = new ArrayList<Carga>();
        for(Carga c : lCarga) {
            copiaLCarga.add(c.clone());
        }
        return copiaLCarga;
    }
    
    /**
     * Retorna o destino do voo;
     */
    public String getDestino(){ return destino; }
    
    /**
     * Retorna o estado do voo (sem clone());
     */
    public Estado getEstado(){ return estado.clone();}
    
    /**
     * Retorna o estado do voo (com clone());
     */
    public Estado getEstadoC(){ return estado; }
    
    /**
     * Atribui codigo de voo;
     */
    public void setCodigo       (String codigo)               { codigo = codigo; }
    
    /**
     * Atribui a entidade responsavel;
     */
    public void setResponsavel  (String novoEntResponsavel)   { entResponsavel = novoEntResponsavel; }
    
    /**
     * Atribui o destino do voo;
     */
    public void setDestino      (String novoDestino)          { destino = novoDestino; }
    
    /**
     * Define a hora de partida;
     */
    public void setHoraPartida  (GregorianCalendar novaHora)  { horaPartida = novaHora; }
    
    /**
     * Verifica se um dado passageiro se encontra na lista de passageiros; 
     */
    public boolean verificaPassageiro(Passageiro passageiro){
        return lPassageiros.contains(passageiro);
    }
    
    /**
     * Adiciona um (objecto) passageiro a lista de passageiros;
     */
    public void addListaPassageiros(Passageiro passageiro){
        lPassageiros.add(passageiro.clone());    
    }
    
    /**
     * Remove um (objecto) passageiro da lista de passageiros;
     */
    public void remListaPassageiros(Passageiro passageiro){
        lPassageiros.remove(passageiro);
    }
    
    /**
     * Adiciona uma (objecto) carga a lista de carga;
     */
    public void addListaCarga(Carga carga){
        lCarga.add(carga.clone());
    }
    
    /**
     * Remove uma (objecto) carga da lisat de carga;
     */
    public void remListaCarga(Carga carga){
        lCarga.remove(carga);
    }
    
    /**
     * Metodo equals();
     */
    public abstract boolean equals(Object obj);
    
    /**
     * Metodo clone();
     */
    public abstract Voo clone();
    
    /**
     * Apresenta o placard dos voos comerciais;
     */
    public String apresentaPlacard(){
        StringBuilder s = new StringBuilder();
        s.append("\n");     s.append(codigo);
        s.append("\t| ");  s.append(destino);
        s.append("\t| ");  s.append(horaPartida.get(GregorianCalendar.HOUR_OF_DAY)); s.append(":"); s.append(horaPartida.get(GregorianCalendar.MINUTE));
        s.append("\t| ");  s.append(estado.getPorta());
        s.append("\t| ");  s.append(estado.getEstado().toString());
        s.append("\t| ");  s.append(estado.getObservacoes());
        return s.toString();
    }
    
    /**
     * Metodo toString();
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append("Codigo: "); s.append(codigo);
        s.append(", Entidade Responsavel: "); s.append(entResponsavel);
        s.append(", Lista de Passageiros: "); 
        for (Passageiro p : lPassageiros){
            s.append(p.toString());
        }
        s.append(", Lista de Carga: ");
        for (Carga c : lCarga){
            s.append(c.toString());
        }
        s.append(", Destino: "); s.append(destino);
        s.append(", Estado: "); s.append(estado);
        s.append(", Hora de Partida: "); s.append(horaPartida);
        return s.toString();
    };
    
    /**
     * Tempo para o carregamento da lista de carga;
     */
    public GregorianCalendar tempoCarregamentoListaCarga(){
        
        int hora = 0;
        int min  = 0;
        int seg  = 0;
        
        int hora1;
        int min1;
        int seg1;
        
        for(Carga c : lCarga){
            hora += c.calctempoCarregamento().get(GregorianCalendar.HOUR_OF_DAY);
            min  += c.calctempoCarregamento().get(GregorianCalendar.MINUTE);
            seg  += c.calctempoCarregamento().get(GregorianCalendar.SECOND);
        }
        
        seg1    = seg % 60;
        min1    = ( ( ( (seg / 60) % 60 ) + (min % 60 ) ) % 60 );
        hora1   = ( ( (seg / 60) / 60 ) + (min / 60 ) + hora ); 
        
        GregorianCalendar tempoTotal = new GregorianCalendar(0,0,0,hora1,seg1,min1);
        
        return tempoTotal;
    }
    
    /**
     * Cria a lista de embarque a partir da lista de passageiros;
     */
    public void listaEmbarque(){
        for (Passageiro p : lPassageiros){
            estado.addLEmbarque(p);
        }
        
    }
    
    /**
     * Altera lista de espera;
     */
    public void setListaEspera(ArrayList<Passageiro> listaEspera){}
}

