import java.io.Serializable;
/**
 * Classe responsavel pela Aeronave (helicoptero) e as suas caracteristicas.
 */
public class AeronaveHelicoptero extends Aeronave implements Serializable {

    /**
     * Construtor da Aeronave Helicoptero
     */
    public AeronaveHelicoptero(){
        super();
    }
    
    /**
     * Construtor da Aeronave Helicoptero mas recebe uma Matricula, designacao, Numero maximo de passageiros,
     * capacidade maxima de carga e velocidade maxima
     */
    public AeronaveHelicoptero(String matricula, String designacao, int maxPassageiros, int capacidadeMax, int velocidadeMax){
        super(matricula, designacao, maxPassageiros, capacidadeMax, velocidadeMax);
    } 
    
    /**
     * Construtor da Aeronave Helicoptero de um objecto
     */
    public AeronaveHelicoptero(AeronaveHelicoptero obj){
        super(obj);
    }
    
    /**
     * Compara Aeronave Helicoptero com um objecto
     */
    public boolean equals(Object obj){
        if ( obj == this ) return true;
        if ( obj == null ) return false;
        if ( obj.getClass() != this.getClass() ) return false;
        Aeronave a = (AeronaveHelicoptero) obj;
        return ( ( this.getMat().equals(a.getMat()) ) && ( this.getDes().equals(a.getDes()) ) 
            && ( this.getMPassag() == a.getMPassag() ) && ( this.getMCarga() == a.getMCarga() ) 
            && ( this.getMVel() == a.getMVel() ));
    }
    
    /**
     * Faz copia de uma Aeronave Helicoptero
     */
    public AeronaveHelicoptero clone(){
        return new AeronaveHelicoptero(this);
    }
    
    /**
     * Passa Aeronave Helicoptero para String
     */
    public String toString(){
        return super.toString();
    }
}
