import java.io.Serializable;
/**
 * Classe responsavel pela Aeronave (aviao de passageiros) e as suas caracteristicas.
 */
public class AeronaveAviaoPassageiros extends Aeronave implements Serializable {
    /**
     * Construtor da Aeronave Aviao Passageiros
     */
    public AeronaveAviaoPassageiros(){
        super();
    }
    
    /**
     * Construtor da Aeronave Aviao Passageiros mas recebe uma matricula, designacao, numweo maximo de passageiros,
     * capacidade maxima e velocidade maxima
     */
    public AeronaveAviaoPassageiros(String matricula, String designacao, int maxPassageiros, int capacidadeMax, int velocidadeMax){
        super(matricula, designacao, maxPassageiros, capacidadeMax, velocidadeMax);
    } 
    
    /**
     * Construtor da Aeronave Aviao Passageiros de um objecto
     */
    public AeronaveAviaoPassageiros(AeronaveAviaoPassageiros obj){
        super(obj);
    }
    
    /**
     * Compara a Aeronave Aviao Passageiros com um objecto
     */
    public boolean equals(Object obj){
        if ( obj == this ) return true;
        if ( obj == null ) return false;
        if ( obj.getClass() != this.getClass() ) return false;
        Aeronave a = (AeronaveAviaoPassageiros) obj;
        return ( ( this.getMat().equals(a.getMat()) ) && ( this.getDes().equals(a.getDes()) ) 
            && ( this.getMPassag() == a.getMPassag() ) && ( this.getMCarga() == a.getMCarga() ) 
            && ( this.getMVel() == a.getMVel() ));
    }
    
    /**
     * Faz uma copia da Aeronave Aviao Passageiros
     */
    public AeronaveAviaoPassageiros clone(){
        return new AeronaveAviaoPassageiros(this);
    }
    
    /**
     * Passa a Aeronave Aviao Passageiros para String
     */
    public String toString(){
        return super.toString();
    }
}
