import java.io.Serializable;
/**
 * Classe responsavel pela Aeronave (aviao de combate) e as suas caracteristicas.
 */
public class AeronaveAviaoCombate extends Aeronave implements Serializable {
    /**
     * Construtor da Aeronave Aviao Combate
     */
    public AeronaveAviaoCombate(){
        super();
    }
    
    /**
     * Construtor da Aeronave Aviao Combate mas recebe uma matricula, designacao, numero maximo de passeiros,
     * capacidade maxima e velocidade maxima
     */
    public AeronaveAviaoCombate(String matricula, String designacao, int maxPassageiros, int capacidadeMax, int velocidadeMax){
        super(matricula, designacao, maxPassageiros, capacidadeMax, velocidadeMax);
    } 
    
    /**
     * Construtor da Aeronave Aviao Combate de um objecto
     */
    public AeronaveAviaoCombate(AeronaveAviaoCombate obj){
        super(obj);
    }
    
    /**
     * Compara a Aeronave Aviao Combate com um objecto
     */
    public boolean equals(Object obj){
        if ( obj == this ) return true;
        if ( obj == null ) return false;
        if ( obj.getClass() != this.getClass() ) return false;
        Aeronave a = (AeronaveAviaoCombate) obj;
        return ( ( this.getMat().equals(a.getMat()) ) && ( this.getDes().equals(a.getDes()) ) 
            && ( this.getMPassag() == a.getMPassag() ) && ( this.getMCarga() == a.getMCarga() ) 
            && ( this.getMVel() == a.getMVel() ));
    }
    
    /**
     * Faz copia de uma Aeronave Aviao de Combate
     */
    public AeronaveAviaoCombate clone(){
        return new AeronaveAviaoCombate(this);
    }
    
    /**
     * Passa Aeronave Aviao Combate para String
     */
    public String toString(){
        return super.toString();
    }
}
