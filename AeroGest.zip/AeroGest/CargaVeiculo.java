import java.util.GregorianCalendar;
import java.io.Serializable;

/**
 * Class responsavel pelas cargas do tipo veiculo;
 */
public class CargaVeiculo extends Carga implements Serializable {
    private String tipo;            //Tipo de veiculo
    
    /**
     * Construtor CargaVeiculo por omissao
     */
    public CargaVeiculo(){
        super();
        this.tipo    = "";
    }
    
    /**
     * Construtor CargaVeiculo recebendo Codigo, Descricao, Volume e Tipo
     */
    public CargaVeiculo(String codigo, double peso, String descricao, double volume, String tipo){
        super(codigo,peso,descricao,volume);
        this.tipo = tipo;
    }
    
    /**
     * Construtor CargaVeiculo recebendo uma CargaVeiculo
     */
    public CargaVeiculo(CargaVeiculo obj){
        super(obj.getCodigo(), obj.getPeso(), obj.getDescricao(), obj.getVolume());
        this.tipo = obj.getTipo();
    }
    
    /**
     * Recebe tipo da CargaVeiculo
     */
    public String getTipo() { return tipo; }
    
    /**
     * Altera tipo da CargaVeiculo
     */
    public void setTipo(String tipo){ this.tipo = tipo; }
    
    /**
     * Faz copia da CargaVeiculo
     */
    public CargaVeiculo clone(){
        return new CargaVeiculo(this);
    }
    
    /**
     * Verifica se um Objecto � igual a CargaVeiculo
     */
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (this == null)   return false;
        if (this.getClass() != obj.getClass()) return false;
        CargaVeiculo c = (CargaVeiculo) obj;
        return ( (getCodigo().equals(c.getCodigo())) && (getPeso() == c.getPeso()) 
            && (getDescricao().equals(c.getDescricao())) && (getTempoCarregamento().equals(c.getTempoCarregamento())) 
            && (tipo.equals(c.getTipo())) && (getVolume() == c.getVolume()));
    }
    
    /**
     * Passa CargaVeiculo a String
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        s.append(", Tipo: "); s.append(tipo);
        return s.toString();
    }
}
