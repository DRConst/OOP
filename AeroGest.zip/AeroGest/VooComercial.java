import java.util.ArrayList;
import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.Iterator;

/**
 * Classe responsavel pelos voos do tipo comercial;
 */
public class VooComercial extends Voo implements Serializable
{
    private ArrayList<Passageiro> listaEspera;           //Lista de Espera (Passageiros)
    // construtores
    public VooComercial(){
        super();
        this.listaEspera = new ArrayList<Passageiro>();
    }
    
    public VooComercial(String codigo, String entidadeResponsavel, ArrayList<Passageiro> listaPassageiros, ArrayList<Carga> listaCarga, String destino, Estado estado, GregorianCalendar horaPartida, ArrayList<Passageiro> listaEspera){
        super(codigo,entidadeResponsavel,listaPassageiros,listaCarga,destino,estado,horaPartida);
        if (listaEspera == null) this.listaEspera = new ArrayList<Passageiro>();
        else {
            if (this.listaEspera == null) this.listaEspera = new ArrayList<Passageiro>();
            for ( Passageiro p : listaEspera ){
                this.listaEspera.add(p.clone());
            }
        }
    }
    
    public VooComercial(VooComercial obj){
        super(obj.getCodigo(), obj.getResponsavel(), obj.getPassageiros(), obj.getCarga(), obj.getDestino(), obj.getEstado(), obj.getHoraPartida());
        this.listaEspera = obj.getEspera();
    }
    
    public ArrayList<Passageiro> getEspera(){
        ArrayList<Passageiro> copialEspera = new ArrayList<Passageiro>();
        for(Passageiro p : listaEspera) copialEspera.add(p.clone());
        return copialEspera;
    }
    
    public void addListaEspera(Passageiro passageiro){
        listaEspera.add(passageiro.clone());
    }
    
    public void setListaEmbarque(ArrayList<Passageiro> listaE){
        for ( Passageiro p : listaE ){
            this.listaEspera.add(p.clone());
        }
    }
    
    public void setListaEspera(ArrayList<Passageiro> listaEspera){
        this.listaEspera.clear();
        for ( Passageiro p : listaEspera ){
            this.listaEspera.add(p.clone());
        }
    }
    
    public void remListaEspera(Passageiro passageiro){
        for(Passageiro p : listaEspera){
            if(p.equals(passageiro)) listaEspera.remove(p);
        }
    }
    
    public VooComercial clone(){
        return new VooComercial(this);
    }
    

    
    public boolean equals(Object obj){
        if ( this == obj ) return true;
        if ( this == null) return false;
        if ( this.getClass() != obj.getClass() ) return false;
        VooComercial v = (VooComercial) obj;
        return ( (this.getCodigo().equals(v.getCodigo()) ) &&  ( this.getResponsavel().equals(v.getResponsavel()) ) && ( this.getPassageiros().equals(v.getPassageiros()) ) 
            && (this.getCarga().equals(v.getCarga())) && (this.getDestino().equals(v.getDestino())) && (this.getEstado().equals(v.getEstado()))
            && (this.getHoraPartida().equals(v.getHoraPartida())));
    }
    
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        s.append(", Lista de Espera: "); s.append(listaEspera);
        return s.toString();
    }
    
    public void listaEmbarque(){
        int nIncluir, tamanho;
        Random gerador = new Random();
        Iterator<Passageiro> it = getPassageiros().iterator();
        
        nIncluir = gerador.nextInt(5);
        tamanho = getPassageiros().size() - nIncluir;
        
        while(it.hasNext() && tamanho > 0){
            tamanho--;
            getEstadoC().addLEmbarque(it.next());
        }
        
        it = listaEspera.iterator();
        while(it.hasNext() && nIncluir > 0){
            nIncluir--;
            getEstadoC().addLEmbarque(it.next());
        }
        
    }
}
