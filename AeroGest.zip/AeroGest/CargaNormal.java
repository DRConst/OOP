import java.util.GregorianCalendar;
import java.io.Serializable;

/**
 * Classe responsavel pelas cargas gerais;
 */
public class CargaNormal extends Carga implements Serializable{
    
    /**
     * Construtor por omissao.
     */   
    public CargaNormal(){
        super();
    }
    
    /**
     * Construtor de CargaNormal que recebe o codigo, peso, descricao e volume.
     */
    public CargaNormal(String codigo, double peso, String descricao, double volume){
        super(codigo,peso,descricao,volume);
    }
    
    /**
     * Construtor de CargaNormal com outra CargaNormal.
     */
    public CargaNormal(CargaNormal obj){
        super(obj.getCodigo(), obj.getPeso(), obj.getDescricao(), obj.getVolume());
    }
    
    /**
     * Faz uma copia de CargaNormal
     */
    public CargaNormal clone(){
        return new CargaNormal(this);
    }
    
    /**
     * Verifica se um Objecto e igual a CargaNormal.
     */
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (this == null)   return false;
        if (this.getClass() != obj.getClass()) return false;
        CargaNormal c = (CargaNormal) obj;
        return ( (getCodigo().equals(c.getCodigo())) && (getPeso() == c.getPeso()) 
            && (getDescricao().equals(c.getDescricao())) && (getTempoCarregamento().equals(c.getTempoCarregamento())) 
            && (getVolume() == c.getVolume()));
    }
    
    /**
     * Imprime objecto
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        return s.toString();
    }
}
