import java.util.Comparator;
import java.util.GregorianCalendar;

/**
 * Classe responsavel pela comparacao de voos (data e codigo)
 */
class CompHora implements Comparator {
    public int compare(Object v1, Object v2){
        Voo voo1 = (Voo) v1;
        Voo voo2 = (Voo) v2;
        GregorianCalendar p1 = voo1.getHoraPartida();
        GregorianCalendar p2 = voo2.getHoraPartida();
        int hora11 = p1.get(GregorianCalendar.HOUR_OF_DAY);
        int hora22 = p2.get(GregorianCalendar.HOUR_OF_DAY);
        
        int min11 = p1.get(GregorianCalendar.MINUTE);
        int min22 = p2.get(GregorianCalendar.MINUTE);
        
        int seg11 = p1.get(GregorianCalendar.SECOND);
        int seg22 = p2.get(GregorianCalendar.SECOND);
        
        if ( (hora11 == hora22) && (min11 == min22) && (seg11 == seg22) ){
            if (voo1.getCodigo().compareToIgnoreCase(voo2.getCodigo()) < 0)
                return -1;
            else return 1;
        }else{
            if (((GregorianCalendar) voo1.getHoraPartida()).before(((GregorianCalendar) voo2.getHoraPartida())))
                return -1;
            else
                return 1;
        }
    }
}
