import java.util.ArrayList;
import java.io.Serializable;
import java.util.GregorianCalendar;

/**
 * Classe associada aos voos do tipo Governamental;
 */
public class VooGovernamental extends Voo implements Serializable
{
    private int         nMembrosGoverno;       //Numero de Membros do Governo
    private int         nJornalistas;          //Numero de Jornalistas
    private int         nConvidados;           //Numero de Convidados
    private String      origem;                //Origem (Ministerio, Governo)
    
    /**
     * Construtores;
     */
    public VooGovernamental(){
        super();
        nMembrosGoverno = 0;
        nJornalistas    = 0;
        nConvidados     = 0;
        origem          = "";
    }
    
    public VooGovernamental(String c, String er, ArrayList<Passageiro> lp, ArrayList<Carga> lc, String d, Estado e, int nGov, int nJorn, int nConv, String orig, GregorianCalendar hp){
        super(c,er,lp,lc,d,e, hp);
        nMembrosGoverno = nGov;
        nJornalistas    = nJorn;
        nConvidados     = nConv;
        origem          = orig;
    }
    
    public VooGovernamental(VooGovernamental obj){
        super(obj.getCodigo(), obj.getResponsavel(), obj.getPassageiros(), obj.getCarga(), obj.getDestino(), obj.getEstado(), obj.getHoraPartida());
        nMembrosGoverno = obj.getNMembGoverno();
        nJornalistas    = obj.getNJornalistas();
        nConvidados     = obj.getNConvidados();
        origem          = obj.getOrigem();
    }
    
    /**
     * Retorna o numero de membros do governo presentes no voo;
     */
    public int      getNMembGoverno()   {return nMembrosGoverno;}
    
    /**
     * Retorna o numero de jornalistas presentes no voo;
     */
    public int      getNJornalistas()   {return nJornalistas;}
    
    /**
     * Retorna o numero de convidados presentes no voo;
     */
    public int      getNConvidados()    {return nConvidados;}
    
    /**
     * Retorna a origem governamental dos membros do governo (ministerio ou presidencia);
     */
    public String   getOrigem()         {return origem;}
    
    /**
     * Define o numero de membro do governo presentes no voo;
     */
    public void setNGov(int novoNMGoverno){ nMembrosGoverno = novoNMGoverno; }
    
    /**
     * Define o numero de jornalistas presentes no voo;
     */
    public void setNJorn(int novoNJornalistas){ nJornalistas = novoNJornalistas; }
    
    /**
     * Define o numero de convidados presentes no voo;
     */
    public void setNConv(int novoNConvidados){ nConvidados = novoNConvidados; }
    
    /**
     * Define a origem dos membros do governo presentes no voo;
     */
    public void setOrig(String novaOrigem){ origem = novaOrigem; }
    
    /**
     * Metodo clone();
     */
    public VooGovernamental clone(){
        return new VooGovernamental(this);
    }
    
    /**
     * Metodo equals();
     */
    public boolean equals(Object obj){
        if(this == obj) return true;
        if(this == null) return false;
        if(this.getClass() != obj.getClass()) return false;
        VooGovernamental v = (VooGovernamental) obj;
        return ((getCodigo().equals(v.getCodigo())) && (getResponsavel().equals(v.getResponsavel()))
            && (getPassageiros().equals(v.getPassageiros())) && (getCarga().equals(v.getCarga()))
            && (getDestino().equals(v.getDestino())) && (getEstado().equals(v.getEstado()))
            && (getNMembGoverno() == v.getNMembGoverno()) && (getNJornalistas() == v.getNJornalistas())
            && (getNConvidados() == v.getNConvidados()) && (getOrigem().equals(v.getOrigem())));
    }
    
    /**
     * Metodo toString();
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        s.append(", Numero de Membros do Governo: "); s.append(nMembrosGoverno);
        s.append(", Numero de Jornalistas: "); s.append(nJornalistas);
        s.append(", Numero de Convidados: "); s.append(nConvidados);
        s.append(", Origem: "); s.append(origem);
        return s.toString();
    }
}
