import java.util.GregorianCalendar;
import java.io.Serializable;

/**
 * Classe responsavel pela gestao das cargas dos voos;
 */
public abstract class Carga implements Serializable{

    private String              codigo;                     //codigo Carga
    private String              descricao;                  //descricaoricao da Carga
    private double               peso;                      //Peso Carga
    private GregorianCalendar   tempoCarregamento;          //Tempo de carregamento : SEGUNDOS ?GREGCalendar?
    private double               volume;                    //Volume da carga

    /**
     * Construtores;
     */
    public Carga(){
        this.codigo             = "";
        this.peso               = -1;
        this.descricao          = "";
        this.tempoCarregamento  = new GregorianCalendar(0,0,0,0,0,0);
        this.volume             = 0.0;
    }
    
    public Carga(String codigo, double peso, String descricao, double volume){
        this.codigo             = codigo;
        this.peso               = peso;
        this.descricao          = descricao;
        double tmpMin           = ( (Math.log((peso * volume) +1)) * 0.8 );
        int horas               = ( ( (int) tmpMin ) / 60 );
        int min                 = ( ( (int) tmpMin ) % 60 );
        int seg                 = (int) ( (tmpMin - ( min + ( horas * 60 ) ) ) * 60 );
        this.tempoCarregamento  = new GregorianCalendar(0,0,0, horas, min, seg);
        this.volume             = volume;
    }
    
    public Carga (Carga obj){
        this.codigo             = obj.getCodigo();
        this.peso               = obj.getPeso();
        this.descricao          = obj.getDescricao();
        this.tempoCarregamento  = obj.getTempoCarregamento();
        this.volume             = obj.getVolume();
    }
    
    /**
     * Retorna o codigo da carga
     */
    public String getCodigo(){ return codigo; }
    
    /**
     * Retorna o peso da carga
     */
    public double getPeso(){ return peso;}
    
    /**
     * Retorna a descricao da carga
     */
    public String getDescricao(){ return descricao;}
    
    /**
     * Retorna o tempo de Carregamento da carga
     */
    public GregorianCalendar getTempoCarregamento(){ return (GregorianCalendar) tempoCarregamento.clone(); }
    
    /**
     * Retorna o Volume da carga
     */
    public double getVolume(){ return volume; }
    
    /**
     * Altera o volume da Carga
     */
    public void setVolume(double v){ 
        volume              = v; 
        tempoCarregamento   = calctempoCarregamento();
    }
    
    /**
     * Altera o Codigo da Carga
     */
    public void setcodigo(String c){ codigo = c; }
    
    /**
     * Altera o Peso da Carga
     */
    public void setPeso(double p){ 
        peso                = p;
        tempoCarregamento   = calctempoCarregamento();
    }
    
    /**
     * Altera a Descricao da Carga
     */
    public void setDescricao(String d){ descricao = d;}
    
    /**
     * Altera o tempo de carregamento
     */
    public void setTempoCarregamento(GregorianCalendar t){ tempoCarregamento  = (GregorianCalendar) t.clone();}
    
    /**
     * Verifica se um dado objecto e igual a Carga
     */
    public abstract boolean equals(Object obj);
    
    /**
     * Converte uma carga para String
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append("Codigo da carga: "); s.append(codigo);
        s.append(", Peso: "); s.append(peso);
        s.append(", Volume: "); s.append(volume);
        s.append(", Discricao: "); s.append(descricao);
        s.append(", Tempo de Carregamento: "); s.append(tempoCarregamento);
        return s.toString();
    }
    
    /**
     * Faz a copia da carga
     */
    public abstract Carga clone();
    
    
    /**
     * Calcula o tempo de carregamento da carga
     */
    public GregorianCalendar calctempoCarregamento(){
        double tmpMin   = ( (Math.log((peso * volume) +1)) * 0.8 );
        int horas       = ( ( (int) tmpMin ) / 60 );
        int min         = ( ( (int) tmpMin ) % 60 );
        int seg         = (int) ( (tmpMin - ( min + ( horas * 60 ) ) ) * 60 ) ;
        return new GregorianCalendar(0,0,0, horas, min, seg);
    }
}
