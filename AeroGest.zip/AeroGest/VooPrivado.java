import java.util.ArrayList;
import java.io.Serializable;
import java.util.GregorianCalendar;

/**
 * Classe associada aos voos do tipo privado;
 */
public class VooPrivado extends Voo implements Serializable
{
    /**
     * Construtores;
     */
    public VooPrivado(){
        super();
    }
    
    public VooPrivado(String codigo, String entResp, ArrayList<Passageiro> lPass, ArrayList<Carga> lCarga, String destino, Estado estado, GregorianCalendar horaPartida){
        super(codigo, entResp, lPass, lCarga, destino, estado, horaPartida);
    }
    
    public VooPrivado(VooPrivado obj){
        super(obj.getCodigo(),obj.getResponsavel(),obj.getPassageiros(),obj.getCarga(),obj.getDestino(),obj.getEstado(),obj.getHoraPartida());
    }
    
    /**
     * Metodo equals();
     */
    public boolean equals(Object obj){
        if(this == obj) return true;
        if(this == null) return false;
        if(this.getClass() != obj.getClass()) return false;
        VooPrivado v = (VooPrivado) obj;
        return ((getCodigo().equals(v.getCodigo())) && (getResponsavel().equals(v.getResponsavel()))
            && (getPassageiros().equals(v.getPassageiros())) && (getCarga().equals(v.getCarga()))
            && (getDestino().equals(v.getDestino())) && (getEstado().equals(v.getEstado()))
            && (getHoraPartida().equals(v.getHoraPartida())));
    }
    
    /**
     * Metodo clone();
     */
    public VooPrivado clone(){
        return new VooPrivado(this);
    }
    
    /**
     * Metodo toString();
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        return s.toString();
    }
}
