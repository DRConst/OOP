import java.io.Serializable;
/**
 * Classe responsavel pelos passageiros e todas as suas caracteristicas.
 */
public class Passageiro implements Serializable
{
    private String  code;              //Codigo Passageiro
    private String  name;              //Nome
    private String  nacionalidad;      //Nacionalidade
    private String  contact;           //Contacto

    /**
     * Construtor por omissao 
     */
    public Passageiro(){
        this.code          = "";
        this.name          = "";
        this.nacionalidad  = "";
        this.contact       = "";
    }
    
    /**
     * Construtor de uma Passageiro com um determinado codigo, nome, nacionalidade e contacto.
     */
    public Passageiro(String codigo, String nome, String nacionalidade, String contacto){
        this.code            = codigo;
        this.name            = nome;
        this.nacionalidad    = nacionalidade;
        this.contact         = contacto;
    }
    
    /**
     * Construtor de Passageiro atravez de outro passageiro.
     */
    public Passageiro(Passageiro obj){
        this.code           = obj.getCodigo();
        this.name           = obj.getNome();
        this.nacionalidad   = obj.getNacionalidade();
        this.contact        = obj.getContacto();
    }
    
    /**
     * Retorna o Codigo do passageiro.
     */
    public String getCodigo(){ return code; }
    
    /**
     * Retorna o Nome do passageiro.
     */
    public String getNome(){ return name; }
    
    /**
     * Retorna o Codigo do passageiro.
     */
    public String getNacionalidade(){ return nacionalidad; }
    
    /**
     * Retorna o Contacto do passageiro.
     */
    public String getContacto() { return contact; }
    
    
    /**
     * Altera o Codigo do passageiro.
     */
    public void setCod(String novoCodigo){ code = novoCodigo; }
    
    /**
     * Altera o Nome do passageiro.
     */
    public void setNome(String novoNome){ name = novoNome; }
    
    /**
     * Altera a Nacionalidade do passageiro.
     */
    public void setNac(String novaNacionalidade){ nacionalidad = novaNacionalidade; }
    
    /**
     * Altera o Contacto do passageiro.
     */
    public void setCont(String novoContacto){ contact = novoContacto; }
    
    
    /**
     * Faz a copia do passageiro.
     */
    public Passageiro clone(){
        return new Passageiro(this);
    }
    
    /**
     * Converte um Passageiro para String.
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append("Codigo do passageiro: " + code);
        s.append("Nome do passageiro: " + name);
        s.append("Nacionalidade do passageiro: " + nacionalidad);
        s.append("Contacto do passageiro: " + contact);
        return s.toString();
    }
    
    /**
     * Verifica se um dado objecto e igual ao Passageiro.
     */
    public boolean equals(Passageiro obj){
        if (obj == this) return true;
        if ( obj == null ) return false;
        if ( obj.getClass() != this.getClass() ) return false;
        Passageiro p = (Passageiro) obj;
        return ( code.equals(p.getCodigo()) && name.equals(p.getNome()) && nacionalidad.equals(p.getNacionalidade()) && contact.equals(p.getContacto()) );
    }
}
