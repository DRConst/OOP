/**
 * Classe responsavel pela enumeracao dos estados.
 */
public enum Estados {
    ESPECIFICADO{
        public String toString(){
            return "Especificado";
        }
    },
    PREPARACAO1{
        public String toString(){
            return "Preparacao 1";
        }
    },
    PREPARACAO2{
        public String toString(){
            return "Preparacao 2";
        }
    },
    ATRASO{
        public String toString(){
            return "Atraso";
        }
    },
    PRONTO{
        public String toString(){
            return "Pronto";
        }
    },
    CANCELADO{
        public String toString(){
            return "Cancelado";
        }
    },
    NOAR{
        public String toString(){
            return "No ar";
        }
    };
}
