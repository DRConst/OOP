import java.io.Serializable;
/**
 * Classe responsavel pela Aeronave (aviao de combate aos incendios) e as suas caracteristicas.
 */
public class AeronaveAviaoIncendios extends Aeronave implements Serializable {

    /**
     * Construtor da Aeronave Aviao Incendios
     */
    public AeronaveAviaoIncendios(){
        super();
    }
    
    /**
     * Construtor da aeronave aviao incendios mas recebe uma matricula, designacao, numero maximo de passageiros,
     * capacidade maxima de carga e velocidade maxima
     */
    public AeronaveAviaoIncendios(String matricula, String designacao, int maxPassageiros, int capacidadeMax, int velocidadeMax){
        super(matricula, designacao, maxPassageiros, capacidadeMax, velocidadeMax);
    } 
    
    /**
     * Construtor da aeronave aviao incendios de um objecto
     */
    public AeronaveAviaoIncendios(AeronaveAviaoIncendios obj){
        super(obj);
    }
    
    /**
     * Compara a Aeronave Aviao Incendios com um objecto
     */
    public boolean equals(Object obj){
        if ( obj == this ) return true;
        if ( obj == null ) return false;
        if ( obj.getClass() != this.getClass() ) return false;
        Aeronave a = (AeronaveAviaoIncendios) obj;
        return ( ( this.getMat().equals(a.getMat()) ) && ( this.getDes().equals(a.getDes()) ) 
            && ( this.getMPassag() == a.getMPassag() ) && ( this.getMCarga() == a.getMCarga() ) 
            && ( this.getMVel() == a.getMVel() ));
    }
    
    /**
     * Faz a copia de uma aeronave aviao incendios
     */
    public AeronaveAviaoIncendios clone(){
        return new AeronaveAviaoIncendios(this);
    }
    
    /**
     * Passa a Aeronave Aviao Incendios para String
     */
    public String toString(){
        return super.toString();
    }
}
