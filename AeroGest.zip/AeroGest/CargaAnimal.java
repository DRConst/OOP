import java.util.GregorianCalendar;
import java.io.Serializable;

/**
 * Classe responsavel pela cargas do tipo animal;
 */
public class CargaAnimal extends Carga implements Serializable {

    /**
     * Construtor CargaAnimal por omissao
     */
    public CargaAnimal(){
        super();
    }
    
    /**
     * Construtor CargaAnimal com os parametros Codigo, Peso, Descricao e Volume
     */
    public CargaAnimal(String codigo, double peso, String descricao, double volume){
        super(codigo,peso,descricao,volume);
    }
    
    /**
     * Construtor CargAnimal de uma dada CargaAnimal
     */
    public CargaAnimal(CargaAnimal obj){
        super(obj.getCodigo(), obj.getPeso(), obj.getDescricao(), obj.getVolume());
    }
    
    /**
     * Faz copia da CargaAnimal
     */
    public CargaAnimal clone(){
        return new CargaAnimal(this);
    }
    
    /**
     * Testa se um objecto � igual a CargaAniaml 
     */
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (this == null)   return false;
        if (this.getClass() != obj.getClass()) return false;
        CargaAnimal c = (CargaAnimal) obj;
        return ( (getCodigo().equals(c.getCodigo())) && (getPeso() == c.getPeso()) 
            && (getDescricao().equals(c.getDescricao())) && (getTempoCarregamento().equals(c.getTempoCarregamento())) 
            && (getVolume() == c.getVolume()));
    }
    
    /**
     * Passa CargaAnimal para String
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        return s.toString();
    }
}
