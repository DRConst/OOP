import java.util.GregorianCalendar;
import java.io.Serializable;

/**
 * Classe responsavel pelas cargas do tipo alimentar;
 */
public class CargaAlimentar extends Carga implements Serializable
{
    private GregorianCalendar prazoValidade;             //Prazo de Validade
    
    /**
     * Construtor por omissao.
     */
    public CargaAlimentar(){
        super();
        this.prazoValidade = new GregorianCalendar();
    }
    
    /**
     * Construtor de CargaAlimentar que recebe o codigo, peso, descricao, Volume e Prazo de Validade
     */
    public CargaAlimentar(String codigo, double peso, String descricao, double volume, GregorianCalendar prazoValidade){
        super(codigo,peso,descricao,volume);
        this.prazoValidade = (GregorianCalendar) prazoValidade.clone();
    }
    
    /**
     * Construtor de CargaAlimentar com outra CargaAlimentar.
     */
    public CargaAlimentar(CargaAlimentar obj){
        super(obj.getCodigo(), obj.getPeso(), obj.getDescricao(), obj.getVolume());
        this.prazoValidade = obj.getPrazoValidade();
    }
    
    /**
     * Retorna o prazo de Validade de uma CargaAlimantar
     */
    public GregorianCalendar getPrazoValidade(){return prazoValidade;}
    
    /**
     * Altera o Prazo de Validade de uma CargaAlimentar
     */
    public void setPrazoValidade(GregorianCalendar prazoValidade) { this.prazoValidade = prazoValidade; }
    
    /**
     * Faz copia de um objecto CargaAlimentar
     */
    public CargaAlimentar clone(){
        return new CargaAlimentar(this);
    }
    
    /**
     * Verifica se um dado Objecto e igual a CargaAlimentar
     */
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (this == null)   return false;
        if (this.getClass() != obj.getClass()) return false;
        CargaAlimentar c = (CargaAlimentar) obj;
        return ( (getCodigo().equals(c.getCodigo())) && (getPeso() == c.getPeso()) 
            && (getDescricao().equals(c.getDescricao())) && (getTempoCarregamento().equals(c.getTempoCarregamento())) 
            && (prazoValidade.equals(c.getPrazoValidade())) && (getVolume() == c.getVolume()));
    }
    
    
    /**
     * Converte a CargaAlimentar em String
     */
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(super.toString());
        s.append(", prazoValidade: "); s.append(prazoValidade);
        return s.toString();
    }
}
