package fitness;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * MarathonRunning, Implementação da classe abstracta Activity
 * @author Grupo 28
 */
public class MarathonRunning extends Activity implements Serializable
{
	private LinkedList<Integer> timePerKm;	// Seconds
    
    /**
     * Construtor vazio de MarathonRunning
     */
    public MarathonRunning()
    {
        super();
        
        timePerKm = new LinkedList<Integer>();
    }
    
	/**
     * Construtor com parâmetros da classe MarathonRunning
     * @param name nome da actividade
     * @param duration duração da activitidade, em segundos.
	 * @param timeStamp data da actividade
	 * @param timePerKm tempo por quilómetro
     */
    public MarathonRunning( String name, Long duration, GregorianCalendar timeStamp, LinkedList<Integer> timePerKm )
    {
        super( name, duration, timeStamp );
        
        this.timePerKm = timePerKm;
    }
    
	/**
     * Construtor de cópia da classe MarathonRunning
     * @param a
     */
    public MarathonRunning( MarathonRunning a )
    {
        super( a.getName(), a.getDuration(), a.getTimeStamp() );
        
        this.timePerKm = a.getTimePerKm();
		
    }
    
    // Gets
	/**
	 * Devolve a lista com os tempos por quilómetro
	 * @return LinkedList<Integer> tempos por quilómetro
	 */
    public LinkedList<Integer> getTimePerKm()
    {
        LinkedList<Integer> tpl = new LinkedList<Integer>();

        
        for( Integer time : timePerKm )
            tpl.add( time );

        return tpl;
    }

	/**
	 * Devolve o tamanho do circuito
	 * @return int tamanho do circuito, em quilómetros
	 */
    public int getCircuitLength()
    {
        return timePerKm.size();
    }
	    
    // Sets
	/**
	 * Altera a lista de tempos por quilómetro para a passada por argumento.
	 * @param timePerKm lista de tempos por quilómetro
	 */
    public void setTimePerLap( LinkedList<Integer> timePerKm )
    {
        this.timePerKm = new LinkedList<Integer>();
		
        for( Integer time : timePerKm )
            this.timePerKm.add( time );
		
    }
	
	
    // Get MET, specific to MarathonRunning, by MET standard, source:
		// http://onlinelibrary.wiley.com/doi/10.1002/clc.4960130809/pdf
	/**
	 * Devolve o indice Metabolic Equivalent Task, específico para MarathonRunning
	 * @return float indice MET
	 */
    public float getMET()
    {
        return (float)14.6;
    }
	
	/**
	 * Corre a simulação do evento, e devolve o sucesso da operação, específico para MarathonRunning
	 * @param ev Evento para o qual se está a correr a simulação
	 * @param ul Lista dos utilizadores inscritos neste evento
	 * @return boolean sucesso da simulação do evento
	 */
    public boolean runEvent( Event ev, LinkedList<User> ul )
    {
		HashMap<String, Object> evResults = new HashMap<String, Object>();
		
        HashMap<User, LinkedList<Float> > timePerKm = new HashMap< User, LinkedList<Float> >();
		ValueComparatorMarathonRunning km1 =  new ValueComparatorMarathonRunning(timePerKm);
		TreeMap<User, LinkedList<Float> > timePerKmSorted = new TreeMap<User, LinkedList<Float> >(km1);
        
		int circLen = (Integer)ev.getEventArgs().get("circuitLength");
		int weather = ev.getWeather();
		
		Random rand = new Random( ev.hashCode() );
        

		for( User u : ul ) {
			
			float fatigue = (float)100.0;
			float bmi = u.getBMI();
			float avg = u.avgActivityUser( ev.getType().getSimpleName() );
			
			
			timePerKm.put( u, new LinkedList<Float>() );
			
			// Iterating over Kms
			for(int i = 0; i < circLen; i++ ) {

				avg += avg * ( 1 - ( fatigue / 100 ) );
				fatigue = getPerformanceIdx( fatigue, bmi, weather, getMET(), rand );
				
				if( fatigue <= 0 )
					avg = -1;
				
				timePerKm.get( u ).add( avg );
			}
			
		}
		
		timePerKmSorted.putAll( timePerKm );
		
		evResults.put( "timePerKmSorted", timePerKmSorted);
		evResults.put( "timePerKm", timePerKm);
		evResults.put( "runDate", new GregorianCalendar() );

		ev.setEventResults( evResults );
		
		UX.askGeneric( printEventResults( ev.getEventResults() ) );
		
        return true;
    }

	/**
	 * Pede e devolve os argumentos particulares da actividade do evento, específico para MarathonRunning, tamanho do circuito em quilómetros
	 * @return HashMap<String, Object> HashMap com os argumentos particulares da actividade do evento
	 */
    public HashMap<String, Object> getActivityEventArgs()
    {
        HashMap<String, Object> hm = new HashMap<String, Object>();
        int circLenKm;

        String circLenKmS;


        do {
            circLenKmS = UX.askGeneric("Insert the length of the circuit you ran on[kilometers]: ");
        }while( !UX.isNumeric( circLenKmS, true ) || ( circLenKm = Integer.parseInt(circLenKmS) ) <= 0 );

        hm.put( "circuitLength", circLenKm);

        return hm;
    }

	/**
	 * Devolve String com a informação dos argumentos do evento, da actividade, específico para MarathonRunning, tamanho do circuito em quilómetros
	 * @param eventArgs HashMap com os argumentos do evento, da actividade.
	 * @return String informação dos argumentos do evento, da actividade.
	 */	
    public String printEventArgs( HashMap<String, Object> eventArgs )
    {
        String s;
		int circuitLength = (Integer)eventArgs.get("circuitLength");

        s = "\n\tCircuit Length: "+ circuitLength + "Km\n";

        return s;
    }
	
	/**
	 * Devolve String com a informação compilada dos resultados da simulação do evento, específico para MarathonRunning
	 * @param eventResults HashMap com os resultados da simulação do evento.
	 * @return String Informação compilada dos resultados do evento.
	 */		
	public String printEventResults( HashMap<String, Object> eventResults )
	{
		StringBuilder sb = new StringBuilder();
		TreeMap<User, LinkedList<Float> > timePerKmSorted;
		HashMap<User, LinkedList<Float> > timePerKm;
		Iterator<User> iTimePerKm;
		int i = 0;
		String op = "";
		LinkedList<Float> lTest;
		GregorianCalendar runDate;
		
		if( eventResults == null )
			return "";
		
		runDate = (GregorianCalendar)eventResults.get( "runDate" );
		
		timePerKm = (HashMap)eventResults.get("timePerKm");
		timePerKmSorted = (TreeMap)eventResults.get("timePerKmSorted");
		
		iTimePerKm = timePerKmSorted.keySet().iterator();
		
		do {
			op = UX.askGeneric( "Choose a display option[0-Full, 1-Brief]:");
		}while( !(UX.isNumeric( op, true ) ) || ( Integer.parseInt( op ) != 0 && Integer.parseInt( op ) != 1 ) );
		
		sb.append("Event completed on: ");
		sb.append( runDate.get(Calendar.DAY_OF_MONTH) );
		sb.append("/");
		sb.append( (runDate.get(Calendar.MONTH) + 1) );
		sb.append("/");		
		sb.append( runDate.get(Calendar.YEAR) );
		sb.append("\n");
		
		while( iTimePerKm.hasNext() ) {
			User u = iTimePerKm.next();
			float sumTime = 0;
			String sAux = "";
			
			sb.append( (i+1) + UX.getOrdinal( (i+1) ) +" Place : "+ u.getName() +" - " );
			
			//
			lTest = timePerKm.get(u);
			
			for( int j = 0; j < lTest.size(); j++ ) {
				float fTime = lTest.get(j);
				String timeS = UX.timeCompetition( fTime );
				
				sumTime += fTime;
				
				if( fTime == -1 ) {
					sumTime = -1;
					timeS = "DnF";
				}
					
				sAux += "\t"+ (j+1) +"#: "+ timeS +"\n";
			}
			
			if( sumTime == -1 )
				sb.append( "DnF\n" );
			else
				sb.append( UX.timeCompetition( sumTime ) +"\n" );
			
			if( Integer.parseInt(op) == 0 )
				sb.append( sAux );
			
			sb.append( "\n" );
			i++;
			
		}
		
		return sb.toString();
	}

	/**
	 * Devolve o quantificador da actividade no formato especificado na variável boolStrNum, específico para MarathonRunning, média de tempo por quilómetro
	 * @param boolStrNum variável boolean que sinaliza à função o formato no qual deverá devolver a informação
	 * @return Object quantificador no formato especificado
	 */    
    public Object quantifier( boolean boolStrNum ) // Variavel quantificadora para events
    {
        float avg;
		long sumTime = 0;


		for( int nTime : timePerKm )
				sumTime += nTime;

		avg = ( (float)sumTime / (float)timePerKm.size() );
		avg = Math.round(avg * 100.0) / (float)100.0;

		if( boolStrNum )
				return UX.parseTime( Math.round(avg) ) ;
			else
				return avg;
    }
	
	/**
	 * Devolve nova instância de MarathonRunning, pedindo os dados necessários, específico para MarathonRunning, tamanho do circuito em quilómetros, e tempos por quilómetros
	 * @return Activity subclasse Activity
	 */    
    public MarathonRunning initialize()
    {
        String day, month, year;
        boolean ret = false;

        String name;
        long duration = 0;
        GregorianCalendar timeStamp = new GregorianCalendar();

        int circLenKm;
        int nTime;
		LinkedList<Integer> timePerKm = new LinkedList<Integer>();

        String timeS;
        String circLenKmS;
        
        
        do {
            name = UX.askGeneric("Insert the activity's name ( length > 0 ): ");
        }while( name.length() <= 0 );
        
		/*
        do {
            durationS = UX.askGeneric("Insert the activity's duration( in seconds > 0): ");
        }while( !( UX.isNumeric( durationS, true ) ) || ( ( duration = Integer.parseInt(durationS) ) <= 0 ) );
        */
		
        do {
            day = UX.askGeneric("Insert the day this activity ocurred[1,31]: ");
            month = UX.askGeneric("Insert the month this activity ocurred[1,12]: ");
            year = UX.askGeneric("Insert the year this activity ocurred[1900, 2100]: ");
            
            ret = UX.isDateValid( day, month, year, timeStamp );
            
            if( !ret )
                UX.askGeneric("Wrong Date Format");
            
        }while( !ret );
        
		do {
            circLenKmS = UX.askGeneric("Insert the length of the circuit you ran on[kilometers]: ");
        }while( !( UX.isNumeric( circLenKmS, true ) ) || ( ( circLenKm = Integer.parseInt(circLenKmS) ) <= 0 ) );
		
        for( int i = 0; i < circLenKm; i++ ) {

            do {
                timeS = UX.askGeneric("Insert your time for Km #"+ (i + 1) +", (24h60m60s): ");
            }while( ( nTime = timeToSeconds(timeS) ) <= 0 );

            duration += nTime;

            timePerKm.add( nTime );
        }
        
        return ( new MarathonRunning( name, duration, timeStamp, timePerKm ) );
    }
    
	/**
	 * Devolve a compilação da informação da actividade MarathonRunning
	 * @return String compilação da informação da actividade.
	 */
    public String toString()
    {
        String s = super.toString(); 
        
        s += getMET() + " MET \n";
        s += "\tAverage: " + (String)this.quantifier(true);
		
		s += "\n\tCircuit Length: "+ timePerKm.size();
		
		s += "Km, Times per Km: ";
		
		for( int i = 0; i < timePerKm.size(); i++ ) {
			s += "\n\t#"+ (i+1) +" - "+ UX.parseTime( timePerKm.get(i) );
		}
        
        return s;
    }
 
	/**
	 * Faz a comparação do Objecto supostamente do tipo MarathonRunning com a actual.
	 * @param o Objecto supostamente do tipo MarathonRunning a ser comparado com a actividade actual.
	 * @return boolean sucesso da comparação
	 */ 
    public boolean equals( Object o )
    {
        return ( 
            ( o == this ) || (
                ( o != null ) &&
                ( o.getClass() == this.getClass() ) &&
                ( super.equals(o) && ((MarathonRunning)o).getTimePerKm().equals( this.timePerKm ) ) &&
                ( ((MarathonRunning)o).getMET() == this.getMET() )
             )
        );
    }
    
	/**
	 * Devolve nova instância com os valores desta actividade
	 * @return Activity nova instância
	 */
    public MarathonRunning clone()
    {   
        return new MarathonRunning( this );
    }
}

/**
 * Classe comparadora a ser utilizada no runEvent de MarathonRunning, para ordenar os resultados por ordem decrescente
 */
class ValueComparatorMarathonRunning implements Comparator<User>, Serializable {

    Map<User, LinkedList<Float> > base;
	
    public ValueComparatorMarathonRunning(Map<User, LinkedList<Float> > base) {
        this.base = base;
    }

    public int compare(User a, User b)
	{
		int sumA = 0;
		int sumB = 0;
		
		for( float n :  base.get(a) ) {
			sumA += n;
			
			if( n == -1) {
				sumA = -1;
				break;
			}
		}
		
		for( float n :  base.get(b) ) {
			sumB += n;
			
			if( n == -1) {
				sumB = -1;
				break;
			}
		}
		
		if( sumA == -1 )
			return 1;
		
		if( sumB == -1 )
			return -1;
		
        if ( sumA <= sumB ) {
            return -1;
        } else {
            return 1;
        }
    }
}