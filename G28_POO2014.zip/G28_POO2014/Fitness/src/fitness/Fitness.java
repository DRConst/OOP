package fitness;    

/**
 * Fitness, classe que contém o método main
 * @author Grupo 28
 */
public class Fitness
{
	/**
	 * Função main, responsável por inicializar uma instância da classe Menu
	 * e executar o método run dessa mesma classe
	 * @param args 
	 */
    public static void main(String[] args) 
    {
        Menu app = new Menu();
        
        app.run();
    }
}
