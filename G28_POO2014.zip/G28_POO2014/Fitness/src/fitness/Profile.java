package fitness;

import java.io.Serializable;

/**
 * Profile, classe mais alta na hierarquia das classes dos diferentes
 * tipos de utilizadores
 * @author Grupo 28
 */
public abstract class Profile implements Serializable
{
    private String user;
    private String pass;
    
	/**
	 * Construtor vazio da classe Profile
	 */
    public Profile()
    {
        this.user = "";
        this.pass = "";
    }
    
	/**
	 * Construtor com parâmetros da classe Profile
	 * @param userName nome de utilizador
	 * @param password palavra passe
	 */
    public Profile(String userName, String password)
    {
        user = userName;
        pass = password;
    }
    
	/**
	 * Construtor de cópia da classe Profile
	 * @param Profile
	 */
    public Profile(Profile p)
    {
        user = p.getUser();
        pass = p.getPass();
    }
    
	/**
	 * Devolve o nome de utilizador
	 * @return Devolve o nome de utilizador
	 */
    public String getUser() {return user;}
	
	/**
	 * Devolve palavra passe de utilizador
	 * @return Devolve palavra passe de utilizador
	 */
    public String getPass() {return pass;}
    
	/** 
	 * Método abstracto que será herdado pelas classe Admin e User
	 */
    public abstract void Menu();
    
	/**
	 * Transforma a representação interna da classe Profile  numa String
	 * @return string com a informação de uma instância de Profile
	 */
    public String toString()
    {
        StringBuilder sb = new StringBuilder ();
        
        sb.append (user);
        
        return sb.toString();
    }
    
	/**
	 * Compara este objecto com um outro passado por parâmetro
	 * @param o do tipo objecto
	 * @return false se o fôr null, se os objectos a serem comparados forem de classes distintas ou
	 * se alguma variável de instância fôr diferente entres os dois objectos em questão, true caso contrário
	 */
    public boolean equals(Object o)
    {
        if(this == o) {return true;}
        
        if ((o == null || (this.getClass() != o.getClass())))
        return false;
        
        else 
        {
            Profile p = (Profile) o;
            return (user.equals(p.getUser()) &&
                    pass.equals(p.getPass()));        
        }
    }
    
	/**
	 * Cria e devolve uma cópia da classe Profile
	 * @return clone da instância
	 */
    public abstract Profile clone();
}
