package fitness;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * Swimming, Implementação da classe abstracta Activity
 * @author Grupo 28
 */
public class Swimming extends Activity implements Serializable
{
	private int poolLength;					// meters
	private LinkedList<Integer> timePerLap;
    
	
    /**
     * Construtor vazio de Swimming
     */
    public Swimming()
    {
        super();
        
        this.poolLength = 0;
		this.timePerLap = new LinkedList<Integer>();
    }
    
	/**
     * Construtor com parâmetros da classe Swimming
     * @param name nome da actividade
     * @param duration duração da activitidade, em segundos.
	 * @param timeStamp data da actividade
	 * @param poolLength comprimento da piscina
	 * @param timePerLap Lista com os tempos por piscina/volta
     */
    public Swimming( String name, long duration, GregorianCalendar timeStamp, int poolLength, LinkedList<Integer> timePerLap )
    {
        super( name, duration, timeStamp );
        
        this.poolLength = poolLength;
		this.timePerLap = timePerLap;
    }
    
	/**
     * Construtor de cópia da classe Swimming
     * @param a
     */
    public Swimming( Swimming a )
    {
        super( a.getName(), a.getDuration(), a.getTimeStamp() );
        
        this.poolLength = a.getPoolLength();
		this.timePerLap = a.getSpeedPerLap();
    }
    
    // Gets
	/**
	 * Devolve o tamanho da piscina
	 * @return int tamanho da piscina
	 */
    public int getPoolLength()
    {
        return this.poolLength;
    }

	/**
	 * Devolve os tempos por piscina/volta
	 * @return LinkedList<Integer> tempos por piscina/volta
	 */
    public LinkedList<Integer> getSpeedPerLap()
    {
        return this.timePerLap;
    }
    
    // Sets
	/**
	 * Altera o comprimento da piscina para o especificado
	 * @param poolLength novo comprimento da piscina
	 */
    public void setPoolLength( int poolLength )
    {
        this.poolLength = poolLength;
    }

	/**
	 * Altera os tempos por piscina/volta para os especificados
	 * @param timePerLap novos tempos por piscina/volta
	 */
	public void setLaps( LinkedList<Integer> timePerLap )
    {
        this.timePerLap = timePerLap;
    }
    
    // Get MET, specific to Swimming, by MET standard, source:
		// http://onlinelibrary.wiley.com/doi/10.1002/clc.4960130809/pdf
	/**
	 * Devolve o indice Metabolic Equivalent Task, específico para Swiming
	 * @return float indice MET
	 */
    public float getMET()
    {
        return (float)9.02;
    }
	
	/**
	 * Corre a simulação do evento, e devolve o sucesso da operação, específico para Swimming
	 * @param ev Evento para o qual se está a correr a simulação
	 * @param ul Lista dos utilizadores inscritos neste evento
	 * @return boolean sucesso da simulação do evento
	 */
    public boolean runEvent( Event ev, LinkedList<User> ul )
    {
		HashMap<String, Object> evResults = new HashMap<String, Object>();
		
        HashMap<User, LinkedList<Float> > timePerLap = new HashMap< User, LinkedList<Float> >();
		ValueComparatorSwimming swm =  new ValueComparatorSwimming(timePerLap);
		TreeMap<User, LinkedList<Float> > timePerLapSorted = new TreeMap<User, LinkedList<Float> >(swm);
        
		int poolLength = (Integer)ev.getEventArgs().get("poolLength");
		int nLaps = (Integer)ev.getEventArgs().get("nLaps");
		int weather = ev.getWeather();
		
		Random rand = new Random( ev.hashCode() );
        

		for( User u : ul ) {
			
			float fatigue = (float)100.0;
			float bmi = u.getBMI();
			float avg = u.avgActivityUser( ev.getType().getSimpleName() );
			
			
			timePerLap.put( u, new LinkedList<Float>() );
			
			for(int i = 0; i < nLaps; i++ ) {

				avg += avg * ( 1 - ( fatigue / 100 ) );
				fatigue = getPerformanceIdx( fatigue, bmi, weather, getMET(), rand );
				
				if( fatigue <= 0 )
					avg = -1;
				
				timePerLap.get( u ).add( avg );
			}
			
		}
		
		timePerLapSorted.putAll( timePerLap );
		
		evResults.put( "timePerLapSorted", timePerLapSorted);
		evResults.put( "timePerLap", timePerLap);
		evResults.put( "runDate", new GregorianCalendar() );
		evResults.put( "poolLen", poolLength);
		
		ev.setEventResults( evResults );
		
		UX.askGeneric( printEventResults( ev.getEventResults() ) );
		
        return true;
    }
	
	/**
	 * Pede e devolve os argumentos particulares da actividade do evento, específico para Swimming, tamanho da piscina, e número de piscinas/voltas
	 * @return HashMap<String, Object> HashMap com os argumentos particulares da actividade do evento
	 */
	public HashMap<String, Object> getActivityEventArgs()
	{
		HashMap<String, Object> hm = new HashMap<String, Object>();
		
		String nLapsS;
		String evPoolLenS;
		int nLaps;
		int evPoolLen;
		

		do {
			nLapsS = UX.askGeneric("Insert this event's number of laps: ");
		}while( !( UX.isNumeric( nLapsS, true ) ) || ( ( nLaps = Integer.parseInt(nLapsS) ) <= 0 ) );
		
		do {
			evPoolLenS = UX.askGeneric("Insert this event's pool length[meters]: ");
		}while( !( UX.isNumeric( evPoolLenS, true ) ) || ( ( evPoolLen = Integer.parseInt(evPoolLenS) ) <= 0 ) );
		
		hm.put( "poolLength", evPoolLen );
		hm.put( "nLaps", nLaps );
		
		return hm;
	}
    
	/**
	 * Devolve o quantificador da actividade no formato especificado na variável boolStrNum, específico para Swimming, média de tempo por volta
	 * @param boolStrNum variável boolean que sinaliza à função o formato no qual deverá devolver a informação
	 * @return Object quantificador no formato especificado
	 */
    public Object quantifier( boolean boolStrNum ) // Variavel quantificadora para events
    {
        float avg;
		float sumTime = 0;
		
		
		for( Integer time : timePerLap )
				sumTime += time;

		avg = ( sumTime / (float)timePerLap.size() );
		avg = Math.round(avg * 100.0) / (float)100.0;

		if( boolStrNum )
				return UX.parseTime(Math.round(avg));
			else
				return avg;
    }

	/**
	 * Devolve String com a informação dos argumentos do evento, da actividade, específico para Swimming, tamanho da piscina e número de piscinas/voltas
	 * @param eventArgs HashMap com os argumentos do evento, da actividade.
	 * @return String informação dos argumentos do evento, da actividade.
	 */	
	public String printEventArgs( HashMap<String, Object> eventArgs )
	{
		String s;
		
		s = "\n\tPool Length: "+ parseDistance( (Integer)eventArgs.get("poolLength") );
		s += "\n\tNumber of Laps: "+ (Integer)eventArgs.get("nLaps");
		
		return s;
	}

	/**
	 * Devolve String com a informação compilada dos resultados da simulação do evento, específico para Swimming
	 * @param eventResults HashMap com os resultados da simulação do evento.
	 * @return String Informação compilada dos resultados do evento.
	 */	
	public String printEventResults( HashMap<String, Object> eventResults )
	{
		StringBuilder sb = new StringBuilder();
		TreeMap<User, LinkedList<Float> > timePerLapSorted;
		HashMap<User, LinkedList<Float> > timePerLap;
		Iterator<User> iTimePerKm;
		int i = 0;
		String op = "";
		LinkedList<Float> lTest;
		GregorianCalendar runDate;
		int poolLen = 0;
		
		if( eventResults == null )
			return "";
		
		runDate = (GregorianCalendar)eventResults.get( "runDate" );
		
		timePerLap = (HashMap)eventResults.get("timePerLap");
		timePerLapSorted = (TreeMap)eventResults.get("timePerLapSorted");
		poolLen = (Integer)eventResults.get("poolLen");
		
		iTimePerKm = timePerLapSorted.keySet().iterator();
		
		do {
			op = UX.askGeneric( "Choose a display option[0-Full, 1-Brief]:");
		}while( !(UX.isNumeric( op, true ) ) || ( Integer.parseInt( op ) != 0 && Integer.parseInt( op ) != 1 ) );
		
		sb.append("Event completed on: ");
		sb.append( runDate.get(Calendar.DAY_OF_MONTH) );
		sb.append("/");
		sb.append( (runDate.get(Calendar.MONTH) + 1) );
		sb.append("/");		
		sb.append( runDate.get(Calendar.YEAR) );
		sb.append("\n");
		
		while( iTimePerKm.hasNext() ) {
			User u = iTimePerKm.next();
			float sumTime = 0;
			String sAux = "";
			
			sb.append( (i+1) + UX.getOrdinal( (i+1) ) +" Place : "+ u.getName() +" - " );
			
			//
			lTest = timePerLap.get(u);
			
			for( int j = 0; j < lTest.size(); j++ ) {
				float fTime = lTest.get(j);
				String timeS = UX.timeCompetition( fTime );
				float speed = ( ( poolLen / (float)1000 ) /
						( fTime / (float)3600 ) );
				
				timeS += " - " + ( Math.round( speed * 100.0) / (float)100.0 ) +" Km/h ";
				
				sumTime += fTime;
				
				if( fTime == -1 ) {
					sumTime = -1;
					timeS = "DnF";
				}
					
				sAux += "\t"+ (j+1) +"#: "+ timeS +"\n";
			}
			
			if( sumTime == -1 )
				sb.append( "DnF\n" );
			else
				sb.append( UX.timeCompetition( sumTime ) +"\n" );
			
			if( Integer.parseInt(op) == 0 )
				sb.append( sAux );
			
			sb.append( "\n" );
			i++;
			
		}
		
		return sb.toString();
	}

	/**
	 * Faz a conversão de metros para quilómetros, se possível, e adiciona o indicador m/km
	 * @param distance distância em metros a ser convertida
	 * @return String distância em quilómetros ou metros, com o indicador m/km
	 */
    public String parseDistance( int distance )
    {
        String s = "";
        
        if( (distance / 1000) > 0 )
            s = (float)( distance / (float)1000 ) +"Km";
        else
            s = distance +"m";
            
        return s;
    }
    
	/**
	 * Devolve nova instância de Swimming, pedindo os dados necessários, específico para Swimming, comprimento da piscina, número de piscinas/voltas, assim como os seus respectivos tempos
	 * @return Activity subclasse Activity
	 */
    public Swimming initialize()
    {
        String day, month, year;
        boolean ret;

        String name;
        long duration = 0;
        GregorianCalendar timeStamp = new GregorianCalendar();

        int poolLen;
        int nTime;
		int nLaps;
		LinkedList<Integer> timePerLap = new LinkedList<Integer>();

        String timeS;
        String poolLenS;
		String nLapsS;
        
        
        do {
            name = UX.askGeneric("Insert the activity's name ( length > 0 ): ");
        }while( name.length() <= 0 );
		
        do {
            day = UX.askGeneric("Insert the day this activity ocurred[1,31]: ");
            month = UX.askGeneric("Insert the month this activity ocurred[1,12]: ");
            year = UX.askGeneric("Insert the year this activity ocurred[1900, 2100]: ");
            
            ret = UX.isDateValid( day, month, year, timeStamp );
            
            if( !ret )
                UX.askGeneric("Wrong Date Format");
            
        }while( !ret );
        
		do {
            poolLenS = UX.askGeneric("Insert the length of the pool you ran on[meters]: ");
        }while( !( UX.isNumeric( poolLenS, true ) ) || ( ( poolLen = Integer.parseInt(poolLenS) ) <= 0 ) );
		
		do {
            nLapsS = UX.askGeneric("Insert the number of laps you did on the pool: ");
        }while( !( UX.isNumeric( nLapsS, true ) ) || ( ( nLaps = Integer.parseInt(nLapsS) ) <= 0 ) );
		
        for( int i = 0; i < nLaps; i++ ) {

            do {
                timeS = UX.askGeneric("Insert your time for Lap #"+ (i + 1) +", (24h60m60s): ");
            }while( ( nTime = timeToSeconds(timeS) ) <= 0 );

            duration += nTime;
			
			timePerLap.add( nTime );
        }
        
        return ( new Swimming( name, duration, timeStamp, poolLen, timePerLap ) );
    }
    
    /**
	 * Devolve a compilação da informação da actividade Swimming
	 * @return String compilação da informação da actividade.
	 */
    public String toString()
    {
        String s = super.toString(); 
        
        s += getMET() + " MET \n";
		s += "\t Pool Length: "+ parseDistance(poolLength) + " - Number of Laps "+ timePerLap.size() + "\n";
		s += "\t Total Distance Swam: "+ parseDistance( poolLength * timePerLap.size() ) +"\n";
        s += "\t Average Time Per Lap: " + (String)this.quantifier(true);
        
        return s;
    }
    
	/**
	 * Faz a comparação do Objecto supostamente do tipo Swimming com a actual.
	 * @param o Objecto supostamente do tipo Swimming a ser comparado com a actividade actual.
	 * @return boolean sucesso da comparação
	 */
    public boolean equals( Object o )
    {
        return ( 
            ( o == this ) || (
                ( o != null ) &&
                ( o.getClass() == this.getClass() ) &&
				( super.equals(o) && ((Swimming)o).getPoolLength() == this.poolLength ) &&
				( super.equals(o) && ((Swimming)o).getSpeedPerLap().equals ( this.timePerLap ) ) &&
                ( ((Swimming)o).getMET() == this.getMET() )
             )
        );
    }
    
	/**
	 * Devolve nova instância com os valores desta actividade
	 * @return Activity nova instância
	 */
    public Swimming clone()
    {   
        return new Swimming( this );
    }
}

/**
 * Classe comparadora a ser utilizada no runEvent de Swimming, para ordenar os resultados por ordem decrescente
 */
class ValueComparatorSwimming implements Comparator<User>, Serializable {

    Map<User, LinkedList<Float> > base;
	
    public ValueComparatorSwimming(Map<User, LinkedList<Float> > base) {
        this.base = base;
    }

    public int compare(User a, User b)
	{
		int sumA = 0;
		int sumB = 0;
		
		for( float n :  base.get(a) ) {
			sumA += n;
			
			if( n == -1) {
				sumA = -1;
				break;
			}
		}
		
		for( float n :  base.get(b) ) {
			sumB += n;
			
			if( n == -1) {
				sumB = -1;
				break;
			}
		}
		
		if( sumA == -1 )
			return 1;
		
		if( sumB == -1 )
			return -1;
		
        if ( sumA <= sumB ) {
            return -1;
        } else {
            return 1;
        }
    }
}