package fitness;    

import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Activity, representa a classe abstracta a ser implementada pela subActividades
 * @author Grupo 28
 */
public abstract class Activity implements Serializable
{
    private String name;    // Activity's name
    private long duration;  // Activity's duration
    private GregorianCalendar timeStamp;    // Activity's TimeStamp

	
	/**
     * Construtor vazio de Activity
     */
    public Activity()
    {
        this.name = "";
        this.duration = 0;
        this.timeStamp = new GregorianCalendar();
    }

	/**
     * Construtor com parâmetros da classe Activity
     * @param name nome da actividade
     * @param duration duração da activitidade, em segundos.
	 * @param timeArg data da actividade
     */
    public Activity( String name, long duration, GregorianCalendar timeArg )
    {
        this.name = name;
        this.duration = duration;
        this.timeStamp = new GregorianCalendar();

        this.timeStamp.setTimeInMillis( timeArg.getTimeInMillis() );
    }

	/**
     * Construtor de cópia da classe Activity
     * @param a
     */
    public Activity( Activity a )
    {
        this.name = a.getName();
        this.duration = a.getDuration();
        this.timeStamp = new GregorianCalendar();

        this.timeStamp.setTimeInMillis( a.getTimeStamp().getTimeInMillis() );
    }

    // Gets
	/**
	 * Devolve o nome da actividade
	 * @return String nome da actividade
	 */
    public String getName()
    {
        return this.name;
    }

	/**
	 * Devolve a duração da actividade
	 * @return long duração da actividade
	 */
    public long getDuration()
    {
        return this.duration;
    }

	/**
	 * Devolve a data da actividade
	 * @return GregorianCalendar data da actividade
	 */
    public GregorianCalendar getTimeStamp()
    {
        GregorianCalendar ret = new GregorianCalendar();

        ret.setTimeInMillis( timeStamp.getTimeInMillis() );

        return ret;
    }

    // Sets
	/**
	 * Altera a duração da actividade para a especificada
	 * @param dur nova duração da actividade
	 */
    public void setDuration( long dur )
    {
        this.duration = dur;
    }

	/**
	 * Altera a data da actividade para a especificada
	 * @param timeArg nova data da actividade
	 */
    public void setTimeStamp( GregorianCalendar timeArg )
    {
        this.timeStamp.setTimeInMillis( timeArg.getTimeInMillis() );
    }

	/**
	 * Devolve o indice Metabolic Equivalent Task 
	 * @return float indice MET
	 */
    public abstract float getMET();

	/**
	 * Devolve nova instância de uma subclasse Activity, pedindo os dados necessários
	 * @return Activity subclasse Activity
	 */
    public abstract Activity initialize();
    
	/**
	 * Devolve o quantificador da actividade no formato especificado na variável boolStrNum
	 * @param boolStrNum variável boolean que sinaliza à função o formato no qual deverá devolver a informação
	 * @return Object quantificador no formato especificado
	 */
    public abstract Object quantifier( boolean boolStrNum );
	
	/**
	 * Pede e devolve os argumentos particulares da actividade do evento
	 * @return HashMap<String, Object> HashMap com os argumentos particulares da actividade do evento
	 */
	public abstract HashMap<String, Object> getActivityEventArgs();
	
	/**
	 * Corre a simulação do evento, e devolve o sucesso da operação
	 * @param ev Evento para o qual se está a correr a simulação
	 * @param ul Lista dos utilizadores inscritos neste evento
	 * @return boolean sucesso da simulação do evento
	 */
	public abstract boolean runEvent( Event ev, LinkedList<User> ul );
	
	/**
	 * Devolve String com a informação dos argumentos do evento, da actividade.
	 * @param eventArgs HashMap com os argumentos do evento, da actividade.
	 * @return String informação dos argumentos do evento, da actividade.
	 */
	public abstract String printEventArgs( HashMap<String, Object> eventArgs);
	
	/**
	 * Devolve String com a informação compilada dos resultados da simulação do evento.
	 * @param eventResults HashMap com os resultados da simulação do evento.
	 * @return String Informação compilada dos resultados do evento.
	 */
	public abstract String printEventResults( HashMap<String, Object> eventResults );

	/**
	 * Converte uma stirng no formato "24h60m60s" para segundos.
	 * @param String no formato "24h60m60s"
	 * @return int resultado da conversão
	 */
	public int timeToSeconds( String s )
	{
		String auxS = "";
		int auxN = 0;

		int count = 0;
		LinkedList<Pattern> pAux = new LinkedList<Pattern>();
		Matcher matcher;

		pAux.add( Pattern.compile("\\d+h") );
		pAux.add( Pattern.compile("\\d+m") );
		pAux.add( Pattern.compile("\\d+s") );

		for( int i = 0; i < 3; i++ ) {

			matcher = pAux.get(i).matcher(s);

			if( matcher.find() ) {

				auxS = matcher.group();
				auxN = Integer.parseInt( auxS.substring(0, auxS.length() - 1 ) ); 

				if( i == 0)
					count += auxN * 3600;
				else
					count += ( i == 1) ? auxN * 60 : auxN ;
			}
		}
		
		return count;
	}
	
	/**
	 * Devolve o indice de performance para as variáveis passadas do utilizador e do evento.
	 * @param fatigue float com o valor percentual da fatiga do utilizador
	 * @param bmi float com o indice bodyMassIndex do utilizador
	 * @param weather Inteiro representativo do estado do tempo, 0 - Sol, 1 - Chuva
	 * @param met indice MET particular para o tipo de actividade do evento
	 * @param rand Objecto Random inicializado com a seed do hashCode do evento.
	 * @return float indice de performance
	 */
	float getPerformanceIdx( float fatigue, float bmi, int weather, float met, Random rand )
	{
		float fatigueDec;// calculate the decrement from the BMI, quadratic function
		float weatherFactor;
		
		float a = (float)( .44 * Math.pow( bmi, 2) );
		float b = (float)( -19.3 * bmi );
		float c = (float)( 216.9 );

		fatigueDec = (float)( a + b + c );

		// FatigueDecrement calculated by the following expression, where x=bmi:
		// (.44x^2 - 19.3x + 216.9)

		if( weather == 0 )
			weatherFactor = (float)1.0;
		else
			weatherFactor = (float)1.1;

		fatigueDec *= ( (rand.nextFloat() * 0.5) + 1 );
		
		fatigue -= fatigueDec * ( met / 30 ) * weatherFactor;

		return ( fatigue );
	}
	
	/**
	 * Devolve a compilação da informação da actividade
	 * @return String compilação da informação da actividade.
	 */
    public String toString()
    {
        String s;
        
        s = timeStamp.get( Calendar.DAY_OF_MONTH ) + 
            "/" + ( timeStamp.get( Calendar.MONTH ) + 1 ) + 
            "/" + timeStamp.get( Calendar.YEAR );

        s += " - " + this.getName() + 
                " - " + 
                UX.parseTime( duration ) + " - ";

        return s;
    }

	/**
	 * Faz a comparação do Objecto supostamente do tipo Activity com a actual.
	 * @param o Objecto supostamente do tipo Activity a ser comparado com a actividade actual.
	 * @return boolean sucesso da comparação
	 */
    public boolean equals( Object o )
    {
        return ( 
            ( o == this ) || (
                ( o != null ) &&
                ( o.getClass() == this.getClass() ) &&
                ( ((Activity)o).getName().equals ( this.name ) ) &&
                ( ((Activity)o).getDuration() == this.duration ) &&
                ( ((Activity)o).getTimeStamp().getTimeInMillis() == this.timeStamp.getTimeInMillis() )
            )
        );
    }

	/**
	 * Devolve nova instância com os valores desta actividade
	 * @return Activity nova instância
	 */
    public abstract Activity clone();
}
