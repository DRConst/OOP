package fitness;    

import java.io.Serializable;

import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.GregorianCalendar;

/**
 * UX, classe de interacção com o utilizador
 * @author Grupo 28
 */
public class UX implements Serializable
{
    /**
     * Menu inicial que lista as opções de navegação existentes
     * e invoca a função getIntOpt entre 1 e 5
     * @return getIntOpt(1,5) inteiro entre 1 e 5 que corresponde à escolha do utilizador em relação ao menu
     */
    public static int initMenu()
    {
        System.out.println("Welcome to Bunny Fitness Manager!");
        System.out.println("\t1 - Login;\n"
            + "\t2 - Create new user;\n"
            + "\t3 - Delete user;\n"
            + "\t4 - List users;\n"
            + "\t5 - Exit.");
        
        return getIntOpt(1,5);
    }
    
    /**
     * Menu de admin que lista as opções de navegação existentes
     * e invoca a função getIntOpt entre 1 e 6
     * @return getIntOpt(1,6) inteiro entre 1 e 6 que corresponde à escolha do utilizador em relação ao menu
     */
    public static int adminMenu()
    {
        pageClear();
        
        System.out.println("\nLogged as Admin.\nPlease select and option:\n");
        System.out.println("\t1 - Create an event;\n"
                + "\t2 - Delete an event;\n"
                + "\t3 - Run an event;\n"
                + "\t4 - View unfinished events;\n"
				+ "\t5 - View completed events;\n"
                + "\t6 - Logout.\n");
        
        return getIntOpt(1,6);
    }
    
    /**
     * Menu de user que lista as opções de navegação existentes
     * e invoca a função getIntOpt entre 1 e 14
     * @return getIntOpt(1,12) inteiro entre 1 e 14 que corresponde à escolha do utilizador em relação ao menu
     */
    public static int userMenu()
    {
        pageClear();
        
        System.out.println("\nLogged as User.\nPlease select and option:\n");
        System.out.println("\t1  - View registered activities;\n"
                + "\t2  - Register yourself in an activity;\n"
                + "\t3  - Remove yourself from an activity;\n"
                + "\t4  - View statistics;\n"
                + "\t5  - View friends;\n"
                + "\t6  - Add friends;\n"
				+ "\t7  - Remove friend from my list;\n"
                + "\t8  - Join an event;\n"
                + "\t9 - List events you're signed up for;\n"
				+ "\t10 - List your finished events;\n"
                + "\t11 - Leave an event;\n"
                + "\t12 - Edit your profile;\n"
                + "\t13 - View your profile;\n"
                + "\t14 - Logout.\n");
        
        return getIntOpt(1,14);
    }
    
    /**
     * Pedir uma string ao utilizador, que será um nome de utilizador
     * @return scanner.nextLine() que corresponde ao nome de utilizador
     */
    public static String pickUsername()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Insert username: \n");
        
        return scanner.nextLine();
    }
    
    /**
     * Pedir uma string ao utilizador, que será uma palavra chave
     * @return scanner.nextLine() que corresponde a uma palavra chave
     */
    public static String pickPassword()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Insert password.\n");
        
        return scanner.nextLine();
    }
    
    /**
     * Pergunta que tipo de conta o utilizador deseja criar
     * @return getIntOpt(1,3) inteiro entre 1 e 3 que corresponde à escolha 
     * do utilizador em relação ao tipo de conta de utilizador
     */
    public static int askTypeUser()
    {
        pageClear();
        System.out.println("Do you wish to create a new Admin account?\n"
                + "\t1 - Yes;\n"
                + "\t2 - No;\n"
                + "\t3 - Cancel.\n");
        
        return getIntOpt(1,3);
    }
    
    /**
     * Imprimir informação relativa tanto a admins como a Users
     * @param p do tipo Profile
     */
    public static void printProfile (Profile p)
    {
        System.out.print(p.getClass().getSimpleName() + ": ");
        
        System.out.println(p.toString());
    }
    /**
     * Imprimir informação relativa a eventos
     * @param e do tipo Event 
     */
    public static void printEvent(Event e)
    {
        System.out.println(e.toString());
    }
    
    /**
     * Imprimir informação de User
     * @param u do tipo User
     */
    public static void printUser (User u)
    {
        System.out.println ("Your information: \n");
        System.out.println ("Name: " + u.getName() + "\n" +
                "Gender: " + u.getGender() + "\n" +
                "Height: " + u.getHeight() + " cm\n" +
                "Weight: " + u.getWeight() + " Kg\n" +
				"BMI: "+ u.getBMI() +"\n " +
                "Date of Birth: " + u.getDOB().get(Calendar.DAY_OF_MONTH)+ "-" +( u.getDOB().get(Calendar.MONTH) + 1 ) + "-" + u.getDOB().get(Calendar.YEAR) + "\n");
    }
    
    /**
     * Método genérico que recebe uma string que posteriormente será impressa no ecrã e recebe uma string do utilizador
     * @param str string contendo a pergunta que se pretende fazer ao utilizador
     * @return scanner.nextLine() que será a resposta do utilizador em relação à pergunta efectuada anteriormente
     */
    public static String askGeneric(String str)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println( str );
        
        return scanner.nextLine();
    }
    
    /**
     * Permite ao utilizador escolher o tipo de actividade
     * @param activityTypes arraylist com todas as actividades diferentes
     * @param boolStrIdx boolean
     * @return 
     */
    public static Object chooseActivityType( ArrayList<Activity> activityTypes, boolean boolStrIdx )
    {
        String ret = "";
        int op;
        
        if( activityTypes.isEmpty() ) {
            System.out.println("No Activities available for insertion.");
            
            return boolStrIdx ? "" : -1;
        }
        
            
        if( activityTypes.size() == 1 ) {
            System.out.println( "Only 1 type of Activity available, now choosing "+ activityTypes.get( 0).getClass().getSimpleName() +"...");
            
            return boolStrIdx ? activityTypes.get( 0).getClass().getSimpleName() : 1;
        }
    
        System.out.println("Choose a type of Activity:\n");
        
        for( op = 0; op < activityTypes.size(); op++ ) {
                System.out.println( (op + 1) +" - "+ activityTypes.get(op).getClass().getSimpleName() );
        }
        
        System.out.println("0 - Cancel");

        op = getIntOpt( 0, op );
        
        if( op == 0 )
            return boolStrIdx ? "" : -1;
        else
            return boolStrIdx ? activityTypes.get( op - 1).getClass().getSimpleName() : (op - 1);
    }
    
    /**
     * Permite ao utilizador escolher o tipo de actividade
     * @param typedActivities linkedList com actividades
     * @return op opção escolhida pelo utilizador
     */
    public static int chooseActivity( LinkedList<Activity> typedActivities )
    {
        int op = 0;
        
            
        if( ( typedActivities == null ) || ( typedActivities.isEmpty() ) ) {
            
            System.out.println("No Activities available to choose from.");
            
            return 0;
        }
        else if( typedActivities.size() == 1 ) {
            System.out.println("Only 1 Activity to choose from, now choosing "+ typedActivities.get( 0 ).getName() );
            
            
            return 1;
        }
        
        System.out.println("Choose an Activity: ");
        for( op = 0; op < typedActivities.size(); op++ ) {
                System.out.println( (op + 1) +" - "+ typedActivities.get(op).getName() );
        }
        System.out.println("0 - Cancel");
        
        op = getIntOpt( 0, op );
        
        return op;
    }
    
    /**
     * Imprime as actividades de um User
     * @param userActivities listas de actividades de cada User
     * @param full boolean
     * @return count número de actividades existentes
     */
    public static int printUserActivities( HashMap<String, LinkedList<Activity>> userActivities, boolean full)
    {
        LinkedList<LinkedList<Activity> > temp;
        int count = 0;
        
        
        for( LinkedList<Activity> l : userActivities.values() ) {
            
            if( !( l.isEmpty() ) ) {
                for( Activity a : l ) {
                    if( full )
                        System.out.println( a.toString() );
                    else
                        System.out.println( a.getName() );
                    
                    count++;
                    
                    System.out.println("--------------------");
                }
            }
        
        }
        
        return count;
    }
    
    /**
     * Verifica se uma string é um número, inteiro ou float
     * @param s string a ser verificada
     * @param booleanIntFloat true se se pretender testar se é inteiro, false caso se pretenda testar se é float
     * @exception NumberFormatException caso a string a ser testada não seja inteira/float de acordo com booleanIntFloat
     * @return true caso booleanIntFloat seja true e s fôr inteiro ou caso booleanIntFloat seja false e s fôr float e 
     * false caso a excepção seja lançada
     */
    public static boolean isNumeric(String s, boolean booleanIntFloat )
    {

        try { 
            
            if( booleanIntFloat )
                Integer.parseInt(s);
            else
                Float.parseFloat(s);
                
        }
        catch(NumberFormatException e) { return false; }

        return true;
    }
    
    /**
     * Verifica se a data recebido por parâmetro é válida
     * @param day dia
     * @param month mês
     * @param year ano
     * @param timeStamp do tipo gregorianCalendar
     * @return true caso seja válida, false caso contrário
     */
    public static boolean isDateValid( String day, String month, String year, GregorianCalendar timeStamp )
    {
        int nYear, nMonth, nDay;
        GregorianCalendar tester;
        
        if( !isNumeric( day, true ) || !isNumeric( month, true ) || !isNumeric( year, true ) )
            return false;
        
        nYear = Integer.parseInt(year);
        nMonth = Integer.parseInt(month);
        nDay = Integer.parseInt(day);
        
		
        if( nYear < 1900 || nYear > 2100 )
            return false;
        
        if( nMonth < 1 || nMonth > 12 )
            return false;
        
        tester = new GregorianCalendar( nYear, nMonth-1, 1);
        
        if( nDay < 1 || nDay > tester.getActualMaximum(Calendar.DAY_OF_MONTH) )
            return false;
        
        timeStamp.set( nYear, nMonth-1, nDay );
        
        return true;
    }
	
	/**
	 * Verifica que tipo de número cardinal é o inteiro passado por parâmetro e devolve o sufixo associado a 
	 * esse mesmo número
	 * @param n número cardinal
	 * @return s sufixo relativo ao número cardinal
	 */
	public static String getOrdinal( int n )
	{
		String s;
		
		switch( n ) {
			
			case 1:
				s = "st";
			break;
				
			case 2:
				s = "nd";
			break;
				
			case 3:
				s = "rd";
			break;
				
			default:
				s = "th";
		}
		
		return s;
	}
    
    /**
     * Pede um número que se encontre dentro do intervalo [min, max]
     * @param min limite inferior do intervalo
     * @param max limite superior do intervalo
     * @return input opção do utilizador
     */
    public static int getIntOpt(int min, int max)
    {
        Scanner scanner = new Scanner(System.in);
        boolean done = false;
        int input = max;
        
        System.out.println("Insert a number between " + min + " and " + max + ".\n");
        
        do
        {
            if (!scanner.hasNextInt())
            {
                System.out.println("Please insert an integer value.");
                scanner.nextLine();
            }
            else
            {
                input = scanner.nextInt();
                if (input < min || input > max)
                    System.out.println("The value must be between " + min + " and " + max + ".");
                else
                    done = true;            
            }                
        }while(!done);
        scanner.nextLine();
        return input;
    }
    
    /**
     * Pedir um inteiro ao utilizador
     * @exception InputMismatchException lançada caso o utilizador não tenha introduzido um inteiro válido
     * @return i do tipo inteiro
     */
    public static int getInt() {
    Scanner scanner = new Scanner(System.in);
     boolean ok = false;
     int i = 0;
     while(!ok) {
         try {
             i = scanner.nextInt();
             ok = true;
         }
         catch(InputMismatchException e)
             { System.out.println("Invalid integer\n");
               System.out.print("Newvalue:\n");
               scanner.nextLine();
             }
     }

     return i;
  }

    /**
     * Pedir um float ao utilizador dentro de um intervalo [min, max]
     * @throws IllegalArgumentException caso não seja recebido um float
     * @return input do tipo float
     */
    public static float getFloat (float min, float max) throws IllegalArgumentException
    {
        Scanner scanner = new Scanner(System.in);
        boolean done = false;
        float input = max;
        
        System.out.println("Please insert a number between " + min + " and " + max + ".\n");
        
        do
        {
            if (!scanner.hasNextFloat())
            {
                System.out.println("Please insert a float value.");
                scanner.nextLine();
            }
            else
            {
                input = scanner.nextFloat();
                if (input < min || input > max)
                    System.out.println("The value must be between " + min + " and " + max + ".");
                else
                    done = true;            
            }                
        }while(!done);
        scanner.nextLine();
        return input;
    }
    
    /**
     * Mostrar tempos do evento no formato HH:MM:SS.MS
     * @param time do tipo double
     * @return string com a forma de "HH:MM:SS.MS"
     */
    public static String timeCompetition(float time) {
        StringBuilder string = new StringBuilder();
        int h = 0, m = 0, s = 0, ms = 0;
		
        while(time > 0) {
            if (time >= 3600) {
               h += 1;
               time -= 3600;
           }
           else if (time >= 60) {
               m += 1;
               time -= 60;
           }
           else if (time >= 1) {
               s += 1;
               time -=1;
           }
           else {
               ms = (int)(time*1000);
               if(ms < 10) {
                   ms *= 10;
               }
               if(ms < 100) {
                   ms *= 10;
                }
               time -= time;
           }
        }
        if (h < 10) {
            string.append("0");
        }
        string.append(h + ":");
        if (m < 10) {
            string.append("0");
        }
        string.append(m + ":");
        if (s < 10) {
            string.append("0");
        }
        string.append(s + ".");
        string.append(ms);
		
        return string.toString();
    }
    
    /**
     * Mostrar tempos na forma HHhr:MMmin:SSsec
     * @param time do tipo double
     * @return string com a forma de "HHhr:MMmin:SSsec"
     */
    public static String parseTime( long time )
    {
        String s = "";
        long hours = 0;
        long minutes = 0;
        long seconds = time;

        minutes = seconds / 60;

        seconds %= 60;

        hours = (minutes / 60) % 60;

        minutes %= 60;

        if( hours > 0 )
            s = hours + "hr";

        if( minutes > 0 ) {
            if( hours > 0 )
                s += ":";
            s += minutes +"min";
        }

        if( seconds > 0 ) {
            if( (hours > 0) || (minutes > 0) )
                s += ":";
            s += seconds +"sec";
        }

        return s;
    }
    
    /**
     * Imprimir "\n" de modo a que o terminal fique limpo
     */
    public static void pageClear()
    {
        for (int i=0;i<50;i++)
            System.out.println ("\n");
        System.out.println ("\n (\\  /)\n ( .  .)\nC(\") (\")\n\n");
    }
    
}