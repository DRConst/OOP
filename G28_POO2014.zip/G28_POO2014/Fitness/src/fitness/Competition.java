package fitness;    

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * Competition, possui um Map de eventos, sendo que a cada evento está associada uma lista de utilizadores
 * e um Set de eventos passados
 * @author Grupo 28
 */
public class Competition implements Serializable
{
    private static HashMap<Event, LinkedList<User>> events = new HashMap<Event, LinkedList<User>>();
    
	/**
	 * Devolve Map de eventos
	 * @return Map de eventos
	 */
    public HashMap<Event, LinkedList<User>> getEvents()
    {
        return events;
    }
    
	/**
	 * Coloca a variável de instância events
	 * com o valor da variável passada por parâmetro
	 * @param eve Map de eventos - Lista de utilizadores do evento
	 */
    public void setEvents(HashMap<Event, LinkedList<User>> eve)
    {
        events = eve;
    }
    
	/**
	 * Devolve evento cujo nome é o que é passado por parâmetro
	 * @param eventName nome de evento
	 * @return evento cujo nome é o que é passado por parâmetro
	 */
    public Event getEvent( String eventName )
    {
        Event ev = null;
        LinkedList<Event> l = new LinkedList<Event>( events.keySet() );
        boolean found = false;
        
        for( int i = 0; i < l.size() && !found; i++ ) {
            
            if( l.get(i).getName().equals(eventName) ) {
                found = true;
                ev = l.get(i);
            }
        }
        
        return ev;
    }
	
	/**
	 * Devolve List com os utilizadores do evento
	 * @return List com os utilizadores do evento
	 */
	public LinkedList<User> getUsers( Event ev )
	{
		return events.get( ev );
	}
    
	/**
	 * Adiciona o evento passado por parâmetro
	 * @param e objecto da classe Event
	 */
    public void addEvent(Event e )
    {
        
        events.put(e, new LinkedList<User>() );
		
    }
    
	/**
	 * Lista eventos, completados(caso completed fôr true), ou não completados(caso completed fôr false)
	 * @param completed true para mostrar eventos completados, false caso contrário
	 * @return número de eventos mostrados
	 */
    public int listEvents( boolean completed )
    {
        int i;
		LinkedList<Event> eventList = new LinkedList<Event>( events.keySet() );
		int count = 0;
		
		
		for( i = 0; i < eventList.size(); i++ ) {
			
			boolean state = completed ? eventList.get(i).getEventResults() != null :
					eventList.get(i).getEventResults() == null;
			
			if( state ) {
				UX.printEvent( eventList.get(i) );
				count++;
			}
			
		}
                
        return count;
    }
    
	/**
	 * Apaga evento passado por parâmetro
	 * @param ev objecto da classe Event
	 */
    public void deleteEvent( Event ev )
    {
		
		for( User u : events.get( ev ) )
			u.removeFromEvent( ev );
		
		events.remove( ev );
		
    }
    
	/**
	 * Adiciona utilizador do evento
	 * @param ev objecto da classe Event
	 * @param u objecto da classe User
	 */
    public void addUser(Event ev, User u)
    {
        events.get(ev).add(u);
    }
    
	/**
	 * Remove utilizador do evento
	 * @param ev objecto da classe Event
	 * @param u objecto da classe User
	 */
    public void removeUser(Event ev, User u)
    {
        events.get( ev ).remove( u );
    }
	
}