package fitness;    

import java.io.Serializable;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

/**
 * Admin, contém informação sobre administradores e o seu menu com os respectivos métodos
 * @author Grupo 28
 */
public class Admin extends Profile implements Serializable
{
    Competition comp = new Competition();
    
	/**
     * Construtor vazio da classe Admin
     */
    public Admin()
    {
        super();
    }

	/**
     * Construtor com parâmetros da classe Admin
     * @param userName nome de utilizador
     * @param password palavra passe de utilizador
     */
    public Admin(String userName, String password)
    {
        super(userName, password);
    }
    
    /**
     * Construtor de cópia da classe Admin
     * @param a
     */
    public Admin(Admin a)
    {
        super(a);
    }
    
	/**
	 * Menu de Admin, que usa o método adminMenu da classe UX
	 */
    public void Menu()
    {
        boolean running = true;

        do
        {   
			UX.pageClear();
            switch (UX.adminMenu())
            {
                case 1: // Create an Event
					
					if( createEvent() )
						UX.askGeneric("Event Successfully Created");
					else
						UX.askGeneric("Event adition canceled");
					
                    break;
                    
                case 2: // Delete an Event

					if( deleteEventAdmin() )
						UX.askGeneric("Event successfully Deleted");
					else
						UX.askGeneric("Event deletion canceled");
						
                    break;
                    
                case 3: // Run an Event
                    
                    if( runEventAdmin() )
                            UX.askGeneric("Event successfully Finished");
                    else
                            UX.askGeneric("Event running canceled");
                                        
                    break;
                    
                case 4: // View Events Not Yet Completed
                    		
					if( comp.listEvents(false) != 0 )
						UX.askGeneric("");
					else
						UX.askGeneric("No events to list");
                    
                    break;
					
				case 5: // View Completed Events
					
					if( comp.listEvents(true) != 0 )
						UX.askGeneric("");
					else
						UX.askGeneric("No events to list");					
					
					break;
					
                case 6: // Logout
                    
                    running = false;
                    
                    break;
            }
        }while(running);
    }
    
	
	/////***************************/////
    /////     CASE 1 - Criar Evento
    /////
	/**
	 * Cria novo evento
	 * @return true em caso de sucesso, falso caso contrário
	 */
	public boolean createEvent()
	{
		Event event;
		String strEventName, strEventType;
		String weatherS, mpS;
		String day, month, year;
		int weather, maxParticipants;
		double distance;
		int op;
		
		boolean ret;
		
		GregorianCalendar calen = new GregorianCalendar();
		GregorianCalendar actual = new GregorianCalendar();
		
		HashMap<String, Object> eventArgs = new HashMap<String, Object>();
		
		
		op = (Integer)UX.chooseActivityType( Menu.getActivityTypes(), false );
		
		if( op == -1 )
			return false;
			
		
		do {
			strEventName = UX.askGeneric("Insert the event name: ");
		}while( strEventName.length() <= 0 );
		
		if( comp.getEvent(strEventName ) != null ) {
			UX.askGeneric("There is already an event with that name.");
			return false;
		}
		

		do {
			weatherS = UX.askGeneric("Choose weather option: \n\t0 - sunny\n\t1 - rainy");
		}while( !(UX.isNumeric( weatherS, true ) ) || ( Integer.parseInt( weatherS ) != 0 && Integer.parseInt( weatherS ) != 1 ) );
	   
		weather = Integer.parseInt(weatherS);
		
		do {
			mpS = UX.askGeneric("Insert the maximum number of participants: ");
		}while( !(UX.isNumeric( mpS, true ) ) || ( Integer.parseInt(mpS) <= 0 ) );
		
		maxParticipants = Integer.parseInt( mpS );
		

		// Getting this Event's specific arguments.
		eventArgs = Menu.getActivityTypes().get(op).getActivityEventArgs();
		
		
		do {
			day = UX.askGeneric("Insert the day for the last sign up date[0,31]: ");
			month = UX.askGeneric("Insert the month for the last sign up date[1,12]: ");
			year = UX.askGeneric("Insert the year for the last sign up date[1900, 2100]: ");

			ret = UX.isDateValid( day, month, year, calen );

			if( !ret )
				UX.askGeneric("Wrong Date Format");
			
			if( actual.after(calen) )
				UX.askGeneric("You can't create an event in the past");

		}while( !ret || actual.after(calen) );
		
		event = new Event(strEventName, Menu.getActivityTypes().get(op).getClass(), weather, maxParticipants, eventArgs, null, calen);
		comp.addEvent(event);
		
		return true;
	}
	
	/////***************************/////
    /////     CASE 2 - Apagar Evento
    /////
	/**
	 * Apaga eventos
	 * @return true em caso de sucesso, false caso contrário
	 */
	public boolean deleteEventAdmin()
	{
		int count;
		String strEventName;
		Event ev;
		String op;
		
		
		count = comp.listEvents(false);
		
		if( count == 0 ) {
			UX.askGeneric("No events to be deleted");
			return false;
		}
			
		strEventName = UX.askGeneric("Insert the name of the event you wish to delete: ");
		ev = comp.getEvent( strEventName );
		
		if( ev == null ) {
			UX.askGeneric("No event found, deletion canceled");
			return false;
		}

		if( ev.getEventResults() != null ) {
			UX.askGeneric("The selected event is already finished");
			return false;
		}
		
		do {
			op = UX.askGeneric("Confirm deletion for event "+ strEventName +", [ 0-Cancel, 1-Proceed]: ");
		}while( !(UX.isNumeric( op, true ) ) || ( Integer.parseInt( op ) != 0 && Integer.parseInt( op ) != 1 ) );
		
		if( Integer.parseInt( op ) == 0 )
			return false;
		
		comp.deleteEvent( ev );
			
		return true;
	}

	/////***************************/////
    /////     CASE 3 - Correr Evento
    /////
	/**
	 * Simula um evento
	 * @return true em caso de sucesso, false caso contrário
	 */
	public boolean runEventAdmin()
	{
		Event ev;
		String strEventName;
		Activity a;
		ArrayList<Activity> activityTypes = Menu.getActivityTypes();
		int i = 0;
		
		comp.listEvents(false);
		
		strEventName = UX.askGeneric("Insert the name of the event you wish to run: ");
		
		if( ( ev = comp.getEvent( strEventName ) ) == null ) {
			UX.askGeneric("Event not found");
			return false;
		}

		if( ev.getEventResults() != null ) {
			UX.askGeneric("The selected event is already finished");
			return false;
		}
		
		if( comp.getUsers( ev ).size() == 0 ) {
			UX.askGeneric("Cannot run event since there are no users signed up for it.");
			return false;
		}
			
		for( i = 0; i < activityTypes.size(); i++ )
			if( ev.getType().isInstance( activityTypes.get(i) ) )
				return activityTypes.get( i ).runEvent( ev, comp.getUsers( ev ) );
		
		return false;
	}
	
	/**
	 * Transforma a representação interna da classe Admin numa String
	 * @return string com a informação de uma instância de Admin
	 */
    public String toString()
    {
        return super.toString();
    }
    
	/**
	 * Compara este objecto com um outro passado por parâmetro
	 * @param o do tipo objecto
	 * @return false se o fôr null, se os objectos a serem comparados forem de classes distintas ou
	 * se alguma variável de instância fôr diferente entres os dois objectos em questão, true caso contrário
	 */
    public boolean equals(Object o)
    {
        if(this == o) {return true;}
        if((this == null) || (this.getClass() != o.getClass())) 
        {
            return false;
        }
        else 
        {
            Admin a = (Admin) o;
            return (super.equals(a));
        }
    }
    
	/**
	 * Cria e devolve uma cópia da classe Admin
	 * @return clone da instância
	 */
    public Admin clone() {return new Admin(this);}
}
