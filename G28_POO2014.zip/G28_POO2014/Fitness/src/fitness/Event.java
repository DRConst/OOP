package fitness;     

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;

/**
 * Event, classe que cria eventos
 * @author Grupo 28
 */
public class Event implements Serializable{
    private String name;
    private Class< ? extends Activity> type;
    private int weather; // 0 - sol, 1 - chuva
    private int maxParticipants;
    private GregorianCalendar signUpDate;
	private HashMap<String, Object> eventArgs;
	private HashMap<String, Object> eventResults;
    
	/**
	 * Construtor vazio da classe Event
	 */
    public Event() {
        name = "";
        type = null;
        weather = 1;
        maxParticipants = 20;
        eventArgs = new HashMap<String,Object>();
		eventResults = null;
        signUpDate = new GregorianCalendar();
    }
    
    /**
     * Construtor com parâmetros da classe Events
     * @param name nome do evento
     * @param type tipo do evento
     * @param weather estado do evento
     * @param maxParticipants limite máximo de inscrições
	 * @param eventArgs Map com os argumentos de inicialização
	 * @param eventResults Map com os resultados do evento
     * @param signUpDate data limite de inscrições
     */
    public Event(String name, Class< ? extends Activity> type, int weather, int maxParticipants, HashMap<String,Object> eventArgs, HashMap<String, Object> eventResults, GregorianCalendar signUpDate) {
        this.name = name;
        this.type = type;
        this.weather = weather;
        this.maxParticipants = maxParticipants;
        this.eventArgs = eventArgs;
		this.eventResults = eventResults;
        this.signUpDate = signUpDate;
    }
    
    /**
     * Construtor de cópia da classe Event
     * @param event
     */
    public Event(Event event) {
        this.name = event.getName();
        this.type = event.getType();
        this.weather = event.getWeather();
        this.maxParticipants = event.getMaxParticipants();
		this.eventArgs = event.getEventArgs();
		this.eventResults = event.getEventResults();
        this.signUpDate = event.getSignUpDate();
    }
    
    /**
     * Devolve o nome do evento
     * @return Devolve o nome do evento
     */
    public String getName() {
        return this.name;
    }
    
    /**
     * Devolve o tipo do evento
     * @return Devolve o tipo do evento
     */
    public Class< ? extends Activity> getType() {
        return this.type;
    }
    
    /**
     * Devolve o estado do tempo, Sol - 0 / Chuva - 1
     * @return Devolve o estado do tempo, Sol - 0 / Chuva - 1
     */
    public int getWeather() {
        return this.weather;
    }
    
	/**
	 * Devolve Map com os argumentos do evento
	 * @return eventArgs Map com os argumentos do evento
	 */
    public HashMap<String,Object> getEventArgs() {
        return this.eventArgs;
    }
    
	/**
	 * Devolve Map com os resultados do evento
	 * @return eventArgs Map com os resultados do evento
	 */
    public HashMap<String, Object> getEventResults() {
		return this.eventResults;
	}
	
    /**
     * Devolve o número máximo de participantes
     * @return Devolve o número máximo de participantes
     */
    public int getMaxParticipants() {
        return this.maxParticipants;
    }
    
    /**
     * Devolve a data limite de inscrição
     * @return Devolve a data limite de inscrição
     */
    public GregorianCalendar getSignUpDate() {
        return this.signUpDate;
    }
    
    /**
     * Coloca a variável de instância name
     * com o valor da variável passada por
     * parâmetro
     * @param name nome do evento
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Coloca a variável de instância type
     * com o valor da variável passada por
     * parâmetro
     * @param type classe do tipo de evento
     */
    public void setType(Class< ? extends Activity> type) {
        this.type = type;
    }
    
    /**
     * Coloca a variável de instância weather
     * com o valor da variável passada por
     * parâmetro
     * @param weather condições metereológicas para o dia do evento
     */
    public void setWeather(int weather) {
        this.weather = weather;
    }
    
	/**
	 * Coloca a variável de instância eventArgs
	 * com o valor da variável passada por parâmetro
	 * @param eventArgs Map com os argumentos do evento
	 */
    public void setEventArgs( HashMap<String,Object> eventArgs) {
        this.eventArgs = eventArgs;
    }
    
	/**
	 * Coloca a variável de instância eventResults
	 * com o valor da variável passada por parâmetro
	 * @param eventResults Map com os resultados do evento
	 */
	public void setEventResults( HashMap<String, Object> eventResults ) {
		this.eventResults = eventResults;
	}
	
    /**
     * Coloca a variável de instância maxParticipants
     * com o valor da variável passada por
     * parâmetro
     * @param maxParticipants limite de utilizadores máximo para o evento
     */
    public void setMaxParticipants(int maxParticipants) {
        this.maxParticipants = maxParticipants;
    }
    
    /**
     * Coloca a variável de instância signUpDate
     * com o valor da variável passada por
     * parâmetro
     * @param signUpDate data limite de inscrição
     */
    public void setSignUpDate(GregorianCalendar signUpDate) {
        this.signUpDate = signUpDate;
    }
	
	/**
	 * Compara este objecto com um outro passado por parâmetro
	 * @param o do tipo objecto
	 * @return false se o fôr null, se os objectos a serem comparados forem de classes distintas ou
	 * se alguma variável de instância fôr diferente entres os dois objectos em questão, true caso contrário
	 */
    public boolean equals(Object o) {
        if(o==this) {
            return true;
        }
        if(o==null || o.getClass()!=this.getClass()) {
            return false;
        }
        Event event = (Event) o;
        return(this.name.equals(event.getName()) && 
			this.type.getSimpleName().equals( event.getType().getSimpleName() ) &&
            this.weather == event.getWeather() && this.maxParticipants == event.getMaxParticipants() && 
            this.eventArgs == event.getEventArgs() && this.eventResults == event.getEventResults() &&
			this.signUpDate.getTimeInMillis() == event.getSignUpDate().getTimeInMillis() &&
			this.eventArgs.equals(event.getEventArgs()) &&
			this.eventResults.equals(event.getEventResults()) );
    }
    
	/**
	 * Cria e devolve uma cópia da classe Event
	 * @return clone da instância
	 */
    public Event clone() {
        return new Event(this);
    }
    
	/**
	 * Transforma a representação interna da classe Event numa String
	 * @return string com a informação de uma instância de Event
	 */
    public String toString() {
        StringBuilder s = new StringBuilder();
		int i;
		boolean found = false;
		ArrayList<Activity> activityTypes = Menu.getActivityTypes();
		
        s.append("\nEvent Name: " + this.name);
        s.append("\n\tEvent Type: " + this.type.getSimpleName());
        if(this.weather == 1) {
            s.append("\n\tWeather: Rainy");
        } else {
            s.append("\n\tWeather: Sunny");
        }
        s.append("\n\tMax Participants: " + this.maxParticipants);
		
		for( i = 0; i < activityTypes.size() && !found; i++ ) {
			if( type.isInstance( activityTypes.get(i) ) ) {
				s.append( activityTypes.get(i).printEventArgs( eventArgs ) );
				s.append( activityTypes.get(i).printEventResults( eventResults ) );
				found = true;
			}
		}
		
        s.append("\n\tSign Up Limit Date: " + this.signUpDate.get(Calendar.DAY_OF_MONTH) + "/" + ( this.signUpDate.get(Calendar.MONTH) + 1 ) + "/" +
            this.signUpDate.get(Calendar.YEAR));
		
        return s.toString();
    }
}