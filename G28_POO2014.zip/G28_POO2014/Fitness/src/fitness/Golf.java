package fitness;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * Golf, Implementação da classe abstracta Activity
 * @author Grupo 28
 */
public class Golf extends Activity implements Serializable
{
    private LinkedList<Integer> strokesPerHole;
    
	/**
     * Construtor vazio de Golf
     */
    public Golf()
    {
        super();
        
        strokesPerHole = new LinkedList<Integer>();
    }
    
	/**
     * Construtor com parâmetros da classe Golf
     * @param name nome da actividade
     * @param duration duração da activitidade, em segundos.
	 * @param timeStamp data da actividade
	 * @param strokesPerHole tacadas por buraco
     */
    public Golf( String name, long duration, GregorianCalendar timeStamp, LinkedList<Integer> strokesPerHole )
    {
        super( name, duration, timeStamp );
        
        this.strokesPerHole = strokesPerHole;
    }
    
	/**
     * Construtor de cópia da classe Golf
     * @param a
     */
    public Golf( Golf a )
    {
        super( a.getName(), a.getDuration(), a.getTimeStamp() );
        
        this.strokesPerHole = a.getStrokesPerHole();
    }
    
    // Gets
	/**
	 * Devolve a lista com as tacadas por buraco
	 * @return LinkedList<Integer> tacadas por buraco
	 */
    public LinkedList<Integer> getStrokesPerHole()
    {
            LinkedList<Integer> sph = new LinkedList<Integer>();

            for( int strokes : strokesPerHole )
                    sph.add( strokes );

            return sph;
    }
	    
    // Sets
	/**
	 * Altera a lista de tacadas por buraco pela passada como argumento
	 * @return LinkedList<Integer> tacadas por buraco
	 */
    public void setStrokesPerHole( LinkedList<Integer> sph )
    {
        strokesPerHole = new LinkedList<Integer>();
			
        for( int strokes : sph )
                strokesPerHole.add( strokes );
		
    }
    
    
    // Get MET, specific to Golf, by MET standard, source:
		// http://onlinelibrary.wiley.com/doi/10.1002/clc.4960130809/pdf
	/**
	 * Devolve o indice Metabolic Equivalent Task, específico para Golf
	 * @return float indice MET
	 */
    public float getMET()
    {
        return (float)4.03;
    }
	
	/**
	 * Corre a simulação do evento, e devolve o sucesso da operação, específico para Golf
	 * @param ev Evento para o qual se está a correr a simulação
	 * @param ul Lista dos utilizadores inscritos neste evento
	 * @return boolean sucesso da simulação do evento
	 */
    public boolean runEvent( Event ev, LinkedList<User> ul )
    {
		boolean ret = false;
		int nHoles = (Integer)ev.getEventArgs().get("nHoles");
		int weather = ev.getWeather();
		Random rand = new Random( ev.hashCode() );
		HashMap< User, LinkedList<Integer> > scoreBoard = new HashMap< User, LinkedList<Integer> >();
		
		ValueComparatorGolf at1 =  new ValueComparatorGolf( scoreBoard );
		TreeMap< User, LinkedList<Integer> > scoreBoardSorted = new TreeMap< User, LinkedList<Integer> >(at1);
		HashMap<String, Object> evResults = new HashMap<String, Object>();
		
		// Running Simulation for All Users
		for( User u : ul ) {
			float avg = u.avgActivityUser( ev.getType().getSimpleName() );
			float fatigue = 100;
			float bmi = u.getBMI();

			scoreBoard.put( u, new LinkedList<Integer>() );
			for( int i = 0; i < nHoles; i++ ) {
				
				avg += avg * ( 1 - ( fatigue / 100 ) );
				fatigue = getPerformanceIdx( fatigue, bmi, weather, getMET(), rand );

				// Register avg for hole i
				scoreBoard.get( u ).add( (int)Math.ceil(avg) );
			}
		}
		
		scoreBoardSorted.putAll( scoreBoard ); 
		
		evResults.put( "scoreBoardSorted", scoreBoardSorted);
		evResults.put( "scoreBoard", scoreBoard);
		evResults.put( "runDate", new GregorianCalendar() );
		
		ev.setEventResults( evResults );
		
		UX.askGeneric( printEventResults( ev.getEventResults() ) );
		
		return true;
    }

	/**
	 * Pede e devolve os argumentos particulares da actividade do evento, específico para Golf, número de buracos a serem jogados
	 * @return HashMap<String, Object> HashMap com os argumentos particulares da actividade do evento
	 */
    public HashMap<String, Object> getActivityEventArgs()
    {
            HashMap<String, Object> hm = new HashMap<String, Object>();

            int nHoles;
            String nHolesS;


            do {
                    nHolesS = UX.askGeneric("Insert the number of holes to be played: ");
            }while( !UX.isNumeric( nHolesS, true ) || ( nHoles = Integer.parseInt(nHolesS) ) <= 0 );

            hm.put( "nHoles", nHoles );

            return hm;
    }
    
	/**
	 * Devolve o quantificador da actividade no formato especificado na variável boolStrNum, específico para Golf, média de tacadas por buraco
	 * @param boolStrNum variável boolean que sinaliza à função o formato no qual deverá devolver a informação
	 * @return Object quantificador no formato especificado
	 */
    public Object quantifier( boolean boolStrNum ) // Variavel quantificadora para events
    {
        int sumStrokes = 0;
        float avg;


        for( int strokes : strokesPerHole )
                sumStrokes += strokes;

        avg = ( (float)sumStrokes / (float)strokesPerHole.size() ); 
        avg = Math.round(avg * 100.0) / (float)100.0;
		String s = (avg + " Strokes per Hole");
		
		if( boolStrNum )
            return ( avg +" Strokes per Hole") ;
        else
            return avg;
    }
	
	/**
	 * Devolve String com a informação dos argumentos do evento, da actividade, específico para Golf, número de tacadas por buraco
	 * @param eventArgs HashMap com os argumentos do evento, da actividade.
	 * @return String informação dos argumentos do evento, da actividade.
	 */	
    public String printEventArgs( HashMap<String, Object> eventArgs )
    {
        String s;
        int nHoles = (Integer)eventArgs.get("nHoles");

        s = "\n\tHoles to Play: "+ nHoles;

        return s;
    }
	
	/**
	 * Devolve String com a informação compilada dos resultados da simulação do evento, específico para Golf
	 * @param eventResults HashMap com os resultados da simulação do evento.
	 * @return String Informação compilada dos resultados do evento.
	 */	
	public String printEventResults( HashMap<String, Object> eventResults )
	{
		StringBuilder sb = new StringBuilder();
		TreeMap<User, LinkedList<Integer> > scoreBoardSorted;
		HashMap<User, LinkedList<Integer> > scoreBoard;
		Iterator<User> iScoreBoard;
		int i;
		String op = "";
		LinkedList<Integer> lTest;
		GregorianCalendar runDate;
		
		if( eventResults == null )
			return "";
		
		runDate = (GregorianCalendar)eventResults.get( "runDate" );
		
		scoreBoardSorted = (TreeMap)eventResults.get( "scoreBoardSorted" );
		scoreBoard = (HashMap)eventResults.get( "scoreBoard" );
		
		iScoreBoard = scoreBoardSorted.keySet().iterator();
		i = 0;
		
		do {
			op = UX.askGeneric( "Choose a display option[0-Full, 1-Brief]:");
		}while( !(UX.isNumeric( op, true ) ) || ( Integer.parseInt( op ) != 0 && Integer.parseInt( op ) != 1 ) );
		
		sb.append("Event completed on: ");
		sb.append( runDate.get(Calendar.DAY_OF_MONTH) );
		sb.append("/");
		sb.append( (runDate.get(Calendar.MONTH) + 1) );
		sb.append("/");		
		sb.append( runDate.get(Calendar.YEAR) );
		sb.append("\n");
		
		while( iScoreBoard.hasNext() ) {
			User u = iScoreBoard.next();
			int sumStrokes = 0;
			String sAux = "";
			
			sb.append( (i+1) + UX.getOrdinal( (i+1) ) +" Place : "+ u.getName() +" - " );
			
			//
			lTest = scoreBoard.get(u);
			
			for( int j = 0; j < lTest.size(); j++ ) {
				sumStrokes += lTest.get(j);
				sAux += "\t"+ (j+1) +"#: "+ lTest.get(j) +" Strokes\n";
			}
			
			sb.append( sumStrokes + " Strokes\n" );
			
			if( Integer.parseInt(op) == 0 )
				sb.append( sAux );
			
			sb.append( "\n" );
			i++;
			
		}
		
		return sb.toString();
	}
    
	/**
	 * Devolve nova instância de Golf, pedindo os dados necessários, específico para Golf, número de buracos jogados, e para cada buraco o número de tacadas
	 * @return Activity subclasse Activity
	 */
    public Golf initialize()
    {
        String day, month, year;
        boolean ret = false;

        String name = "";
        long duration = 0;
        GregorianCalendar timeStamp = new GregorianCalendar();

        LinkedList<Integer> sph = new LinkedList<Integer>();
        int nHoles;
        int nStroke;

        String durationS;

        String nHolesS;
        String nStrokesS;
        
        
        do {
            name = UX.askGeneric("Insert the activity's name ( length > 0 ): ");
        }while( name.length() <= 0 );
        
		/*
        do {
            durationS = UX.askGeneric("Insert the activity's duration( in seconds > 0): ");
        }while( !( UX.isNumeric( durationS, true ) ) || ( ( duration = Integer.parseInt(durationS) ) <= 0 ) );
        */
		
        do {
			durationS = UX.askGeneric("Insert the activity's duration( 24h60m60s ): ");
        }while( ( duration = timeToSeconds( durationS ) ) <= 0 );
		
        do {
            day = UX.askGeneric("Insert the day this activity ocurred[1,31]: ");
            month = UX.askGeneric("Insert the month this activity ocurred[1,12]: ");
            year = UX.askGeneric("Insert the year this activity ocurred[1900, 2100]: ");
            
            ret = UX.isDateValid( day, month, year, timeStamp );
            
            if( !ret )
                UX.askGeneric("Wrong Date Format");
            
        }while( !ret );
        
	do {
            nHolesS = UX.askGeneric("Insert the number of holes you played: ");
        }while( !( UX.isNumeric( nHolesS, true ) ) || ( ( nHoles = Integer.parseInt(nHolesS) ) <= 0 ) );
		
        for( int i = 0; i < nHoles; i++ ) {

            do {
                nStrokesS = UX.askGeneric("Insert the number of strokes you needed for hole #"+ (i + 1) +": ");
            }while( !( UX.isNumeric( nStrokesS, true ) ) || ( ( nStroke = Integer.parseInt(nStrokesS) ) <= 0 ) );

            sph.add( nStroke );
        }

        return ( new Golf( name, duration, timeStamp, sph ) );
    }
    
	/**
	 * Devolve a compilação da informação da actividade Golf
	 * @return String compilação da informação da actividade.
	 */
    public String toString()
    {
        String s = super.toString(); 
        
        s += getMET() + " MET \n";
        s += "\t Average: " + (String)this.quantifier(true);
		
        s += "\n\tStrokes Per Hole: ";

        for( int i = 0; i < strokesPerHole.size(); i++ ) {
            
            s += "\n\t#"+ (i+1) +" - "+ strokesPerHole.get(i);
            
            if( strokesPerHole.get(i) > 1 )
                s += " Strokes";
            else
                s += " Stroke";
            
        }
        
        return s;
    }
    
	/**
	 * Faz a comparação do Objecto supostamente do tipo Golf com a actual.
	 * @param o Objecto supostamente do tipo Golf a ser comparado com a actividade actual.
	 * @return boolean sucesso da comparação
	 */
    public boolean equals( Object o )
    {
        return ( 
            ( o == this ) || (
                ( o != null ) &&
                ( o.getClass() == this.getClass() ) &&
                ( super.equals(o) && ((Golf)o).getStrokesPerHole().equals( this.strokesPerHole ) ) &&
                ( ((Golf)o).getMET() == this.getMET() )
             )
        );
    }
    
	/**
	 * Devolve nova instância com os valores desta actividade
	 * @return Activity nova instância
	 */
    public Golf clone()
    {   
        return new Golf( this );
    }
}

/**
 * Classe comparadora a ser utilizada no runEvent de Golf, para ordenar os resultados por ordem decrescente
 */
class ValueComparatorGolf implements Comparator<User>, Serializable {

    Map<User, LinkedList<Integer> > base;
    public ValueComparatorGolf(Map<User, LinkedList<Integer> > base) {
        this.base = base;
    }

    public int compare(User a, User b)
	{
		int sumA = 0;
		int sumB = 0;
		
		for( int n :  base.get(a) )
			sumA += n;
		
		for( int n :  base.get(b) )
			sumB += n;
		
        if ( sumA <= sumB ) {
            return -1;
        } else {
            return 1;
        }
    }
}