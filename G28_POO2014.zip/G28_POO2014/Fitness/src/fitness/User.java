package fitness;   

import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Set;
import java.util.LinkedList;
import java.util.ArrayList;

/**
 * User, contém informação sobre utilizadores e o seu menu com os respectivos métodos
 * @author Grupo 28
 */
public class User extends Profile implements Serializable
{
    Competition comp = new Competition();
	Friends fri = new Friends();
    
    private String name;
    private String gender;
    private float height;
    private float weight;
    private GregorianCalendar dob;
    private LinkedList<Event> userEvents;
    private LinkedList<User> friends;
    private HashMap<String, LinkedList<Activity> > activities;
    
	/**
     * Construtor vazio da classe User
     */
    public User()
    {
        super();
        name = "";
        gender = "";
        height = 0;
        weight = 0;
        dob = new GregorianCalendar();
        userEvents = new LinkedList<Event>();
        friends = new LinkedList<User>();
        activities = new HashMap<String, LinkedList<Activity> >();
    }
    
	/**
     * Construtor com parâmetros da classe User
     * @param userName nome de acesso de utilizador
     * @param password palavra passe de utilizador
	 * @param name nome do utilizador
	 * @param gender gênero do utilizador
	 * @param height altura do utilizador
	 * @param weight peso do utilizador
	 * @param dob data de nascimento
	 * @param userEvents eventos que o utilizador está inscrito
	 * @param friends lista de amigos do utilizador
	 * @param activities actividades em que o utilizador já participou
     */
    public User(String userName, String password, String name, String gender, float height, float weight, GregorianCalendar dob, LinkedList<Event> userEvents, LinkedList<User> friends, HashMap<String, LinkedList<Activity> > activities )
    {
        super (userName, password);
        this.name = name;
        this.gender = gender;
        this.height = height;
        this.weight = weight;
        this.dob = dob;
        this.userEvents = userEvents;
        this.friends = friends;
        
        // add Activities
		
		this.activities = activities;
        
    }
    
	/**
     * Construtor de cópia da classe User
     * @param u
     */
    public User(User u)
    {
        
        super(u);
        name = u.getName();
        gender = u.getGender();
        height = u.getHeight();
        weight = u.getWeight();
        dob = u.getDOB();
        userEvents = u.getUserEvents();
        friends = u.getFriends();
        activities = u.getActivities();
    }
    
	/**
     * Devolve o nome do User
     * @return Devolve o nome do User
     */
    public String getName() {return name;}
	
    /**
     * Devolve o gênero do User
     * @return Devolve o gênero do User
     */
    public String getGender() {return gender;}
	
    /**
     * Devolve o tamanho do User
     * @return Devolve o tamanho do User
     */
    public float getHeight() {return height;}
	
	/**
     * Devolve o peso do User
     * @return Devolve o peso do User
     */
    public float getWeight() {return weight;}
	
    /**
     * Devolve o índice de massa corporal do User
     * @return Devolve o índice de massa corporal do User
     */
	public float getBMI()
	{
		return ( weight / (float)Math.pow( (height / (float)100), 2 ) );
	}
	
    /**
     * Devolve a data de nascimento do User
     * @return Devolve a data de nascimento do User
     */
    public GregorianCalendar getDOB() {return dob;}
    
	/**
     * Devolve a lista de eventos do User
     * @return Devolve a lista de eventos do User
     */
    public LinkedList<Event> getUserEvents(){return userEvents;}
	
	/**
     * Devolve a lista de amigos do User
     * @return Devolve a lista de amigos do User
     */
    public LinkedList<User> getFriends(){return friends;}
    
	/**
     * Devolve a lista de actividades do User
     * @return Devolve a lista de actividades do User
     */
    public HashMap<String, LinkedList<Activity> > getActivities()
    {
        HashMap<String, LinkedList<Activity> > hm = new HashMap<String, LinkedList<Activity> >();
        Set<String> keySet = activities.keySet();
        LinkedList<Activity> tempSet;
        
        keySet = this.activities.keySet();
        
        for( String key : keySet ) {
        
            tempSet = this.activities.get( key );
            
            hm.put( key, new LinkedList<Activity>() );
            
            if( tempSet != null ) {
                
                for( Activity a : tempSet )
                    hm.get( key ).add( a.clone() );
                
            }
            
        }
        
        return hm;
    }
    
	/**
	 * Menu de User, que usa o método userMenu da classe UX
	 */
    public void Menu()
    {
        boolean running = true;
        int opt, max;
        String strEventName;

		if(!getNotify())
			UX.askGeneric("No notifications");
        
        do
        {
			UX.pageClear();
            switch (UX.userMenu())
            {
                case 1: // View Registered Activities
                    
                    if( UX.printUserActivities( activities, true ) == 0 )
                        UX.askGeneric("No Activities To Be Displayed");
                    else
                        UX.askGeneric("");
                    
                    break;
				
                case 2: // Register Yourself in an Activity
					
                    if( addActivity() )
                        UX.askGeneric("New Activity Sucessfully Added.");
                    else
                        UX.askGeneric("Activity Insertion Canceled.");
						
                    break;
					
                case 3: // Remove yourself from an Activity
                    
                    if( deleteActivity() )
                        UX.askGeneric("Activity Sucessfully Deleted.");
                    else
                        UX.askGeneric("Activity Deletion Canceled.");
				
                    break;
					
                case 4: // View Statistics
  
					if(getRecords()==0) 
						UX.askGeneric("You have no activities");
					
                    break;
					
                case 5: // View Friends
					
                    if( viewFriends() != 0 )
						UX.askGeneric("");
					else
						UX.askGeneric("No Friends to List");
						
                    break;
				
                case 6: // Add Friends
					
                    if( addFriend() )
						UX.askGeneric("Friend request sent");
					else
						UX.askGeneric("Friend request canceled");
					
                    break;
					
				case 7: // Remove friend from my list
					
					if(removeMyFriend())
						UX.askGeneric("Friend removed");
					else
						UX.askGeneric("Friend not found");
					
					break;
					
                case 8: // Join an Event
				
                    if( joinEvent() )
                        UX.askGeneric("Succesfully joined Event");
                    else
                        UX.askGeneric("Event registration canceled");
                    
                    break;
					
                case 9: // List Events You are Signed Up For
                    
                    if( listEventsUser( false ) != 0 )
                        UX.askGeneric("");
                    else
                        UX.askGeneric("You aren't signed up to any events");
				
                    break;
					
				case 10: // List Your Finished Events
                    
                    if( listEventsUser( true ) != 0 )
                        UX.askGeneric("");
                    else
                        UX.askGeneric("You haven't finished any events");
				
                    break;
					
                case 11: // Leave an Event
				
                    if( leaveEvent() )
                        UX.askGeneric("Successfully abandoned Event");
                    else
                        UX.askGeneric("Event leaving canceled");
                    
                    break;
                
                case 12: // Edit Your Profile

                    editUser();
		
                    UX.askGeneric("User Edited");
                    
                    break;
                
                case 13: // View Your Profile
                    
                    UX.printUser(this);
					
					UX.askGeneric("");
					
                    break;
                
                case 14: // Logout
                    
                    running = false;
					
                    break;
				
            }
        }while(running);
    }
    
    /////***************************/////
    /////     CASE 2 - Adicionar Actividade ao Utilizador
    /////
	/**
	 * Adiciona actividade ao utilizador
	 * @return true em caso de sucesso, false caso contrário
	 */
    public boolean addActivity()
    {
        Activity a = null;
        String activityType;
        LinkedList typedActivities;
        ArrayList<Activity> activityTypes = Menu.getActivityTypes();
		boolean found = false;
        
        
        activityType = (String)UX.chooseActivityType( activityTypes, true);
        
		if( activityType.length() == 0 )
			return false;
			
        
        for( int i = 0; i < activityTypes.size() && !found; i++ ) {
			
			Activity temp = activityTypes.get(i);
        
			if( found = temp.getClass().getSimpleName().equals( activityType ) )
                a = temp.initialize();
		}
		
        if( a != null ) {
            
            activities.get( activityType ).add( a );
            
            
            return true;
        }
        
        return false;
    }
	
	
	/////***************************/////
    /////     CASE 3 - Remover Actividade de Utilizador
    /////
	/** 
	 * Remove uma actividade ao utilizador
	 * @return true caso a remoção seja bem sucedida, false caso contrário
	 */
	public boolean deleteActivity( )
    {
        int op = 0;
        String activityType = "";
        String s = "";
        ArrayList<Activity> activityTypes = Menu.getActivityTypes();
        boolean ret = false;
        
        activityType = (String)UX.chooseActivityType( activityTypes, true);
        
        if( activityType.length() == 0 )
            return false;

        op = UX.chooseActivity( activities.get( activityType ) );
        
        if( op == 0 )
            return false;
        
        op--;
		
		UX.askGeneric("If selected Activity is the last of it's type, "
					+ "removing it will also unregister yourself from all Events of that type.");
		
        do {
            s = UX.askGeneric("Confirm Deletion for "+ activities.get( activityType ).get( op ).getName() +", [0-Cancel; 1-Proceed]" );
        }while( !(UX.isNumeric( s, true ) ) || ( Integer.parseInt( s ) != 0 && Integer.parseInt( s ) != 1 ) );
        
        if( Integer.parseInt( s ) == 0 )
            return false;
		
		for(Event ev : userEvents)
		{
			if(ev.getType().isInstance(activities.get( activityType ).get( op )) 
					&& ev.getEventResults()==null )
			{
				if(activities.get(activityType).size()==1)
				{
					comp.removeUser(ev, this);
					userEvents.remove(ev);
				}
			}
		}
		activities.get( activityType ).remove( op );
        
        return true;
    }
	
	/////***************************/////
    /////     CASE 4 - Visualizar estatísticas
    /////
	/** 
	 * Lista de records do utilizador
	 * @return globalCount
	 */
    public int getRecords()
    {
        int count = 0, globalCount = 0;
		int i;
        float temp = 0;
		float kCal = 0;
        Activity a, actTemp;
		LinkedList<String> list = new LinkedList<String>( activities.keySet() );
		String str;
		
        
		for( i = 0; i < list.size(); i++)
        {
			actTemp = Menu.getActivityTypes().get(i);
			str = actTemp.getClass().getSimpleName();
			temp = avgActivityUser( str );
			kCal = 0;
			
			for( count = 0; count < activities.get(str).size(); count++ )
            { 
                a = activities.get(str).get(count);
				kCal += calculateCalories( a );
                if(temp<=(float)a.quantifier(false))
                {
                    temp = (float)a.quantifier(false);
                    actTemp = a;
                }
            }
			
			if(count!=0)
			{
				UX.askGeneric("Best result in " + str + ": " + actTemp.quantifier(true)
						+ "\nTotal Calories Spent: "+ Math.ceil(kCal) +"KCal" );
			}
				
			globalCount += count;
        }
        
        return globalCount;
    }
    
    /////***************************/////
    /////     CASE 5 - Visualizar amigos
    /////
	/**
	 * Lista os amigos do utilizador
	 * @return count número de amigos do utilizador
	 */
    public int viewFriends()
    {
		int count = 0;
		
        for(User u : friends)
        {
            UX.printProfile(u);
			if(u.getRecords()==0)
				UX.askGeneric("No activities to show");
			count++;
        }
		
		return count;
    }
    
    /////***************************/////
    /////     CASE 6 - Utilizador adiciona um amigo
    /////
	/**
	 * Adicionar amigo
	 * @return true em caso de sucesso, false caso contrário
	 */
    public boolean addFriend()
    {
        String strUser;
        boolean found = false;
        
        strUser = UX.askGeneric("Insert your friends username: ");
        
        if( getUser().equals( strUser ) ) {
            UX.askGeneric("You can't add yourself as a friend.");
            return false;
        }
        
		for (Profile p : Menu.getProfiles(true) )
		{
			if(p.getUser().equals(strUser))
			{
				found = true;
				for(User u : friends)
				{
					if (u.getUser().equals(strUser))
					{
						UX.askGeneric("Friend already added!");
						return false;
					}
				}
				if(!fri.addFriend(this, (User)p))
				{
					UX.askGeneric("Request already sent!");
					return false;
				}
			}
		}
		if(!found) 
		{
			UX.askGeneric("Username not found!");
			return false;
		}
		
		return true;
    }
    
	/////***************************/////
    /////     CASE 7 - Utilizador remove um amigo da sua lista de amigos
    /////
	/**
	 * Remover amigo
	 * @return true em caso de sucesso, false caso contrário
	 */
	public boolean removeMyFriend()
	{
		String strUserName;
		
		strUserName = UX.askGeneric("Insert the username of the friend you wish to remove:");
		
		for(User us : friends)
		{
			if(us.getUser().equals(strUserName))
			{
				us.removeFriend(this);
				friends.remove(us);
				return true;
			}
		}
		return false;
	}
	
    /////***************************/////
    /////     CASE 8 - Utilizador regista-se num evento
    /////
	/**
	 * Inscrever num evento
	 * @return true em caso de sucesso, false caso contrário
	 */
    public boolean joinEvent()
    {
        int max;
        String strEventName;
        Event ev;
        
        max = comp.listEvents(false);
		
        if (max == 0)
        {
            UX.askGeneric("There are no events");
            return false;
        }

        strEventName = UX.askGeneric("Insert the name of the event you wish to join, enter to cancel: ");
        
        if( strEventName.length() == 0 ){return false;}
        
        ev = comp.getEvent( strEventName );
		
        for(Event even : userEvents)
        {
            if(strEventName.equals(even.getName()))
            {
                UX.askGeneric("You are already signed up for that event");
                return false;
            }
        }
        String activityType;

        if( ev == null ) {
            UX.askGeneric("No event with such name");
            return false;
        }
		
		if( ev.getEventResults() != null ) {
			UX.askGeneric("The Event selected is already finished");
			return false;
		}

        activityType = ev.getType().getSimpleName();

        if( activities.get( activityType ).isEmpty() ) {
            UX.askGeneric("You have no Activities for that Event");
            return false;
        }

        if( comp.getEvents().get( ev ).size() >= ev.getMaxParticipants() ) {
            UX.askGeneric("All available slots filled for the selected event");
            return false;
        }

        comp.addUser(ev, this);
        userEvents.add(ev);
		
        return true;
    }
    
    /////***************************/////
    /////     CASE 9 & 10- Utilizador visualiza os eventos
    /////	  CASE 9 - Utilizador visualiza os seus eventos que ainda não foram concluidos
    /////	  CASE 10 - Utilizador visualiza os seus eventos já concluídos
	/**
	 * @param completed se false utilizador visualiza eventos que ainda não foram concluídos, se true utilizador
	 * visualiza eventor já concluídos
	 * @return count número de eventos
	 */
    public int listEventsUser( boolean completed )
    {
		int count = 0;


		for (Event ev : userEvents)
		{
			boolean state = completed ? ev.getEventResults() != null :
				ev.getEventResults() == null;
			
			if( state ) {
				UX.printEvent(ev);
				count++;
			}
			
		}
		
		return count;
    }
    
    /////***************************/////
    /////     CASE 11 - Utilizador sai de um evento
    /////
	/**
	 * Desistir de um evento
	 * @return true caso a remoção seja bem sucedida, false caso contrário
	 */
    public boolean leaveEvent()
    {
        String strEventName;
        Event ev;

        listEventsUser(false);
        
        if( userEvents.size() == 0 ) {
                UX.askGeneric("You aren't signed up for any Event");
                return false;
        }

        strEventName = UX.askGeneric("Insert the name of the event you wish to leave, enter to cancel: ");

        if( strEventName.length() == 0 ) {
                return false;
        }

        ev = comp.getEvent( strEventName );

        if( ev == null ) {
                UX.askGeneric("No event with that name.");
                return false;
        }
        
        if(ev.getEventResults() != null)
        {
            UX.askGeneric("You can't abandon a finished event.");
                return false;
        }

        comp.removeUser( ev, this );
        userEvents.remove( ev );

        return true;
    }
    
    /////***************************/////
    /////     CASE 12 - Utilizador muda os seus dados
    /////
	/**
	 * Permite o User editar os seus dados pessoais
	 */
    public void editUser()
    {
        String fHeight, fWeight;
        String day, month, year;
        boolean ret;
        
        do {
            name = UX.askGeneric("Insert your name: ");
        }while( name.length() <= 0 );

        do {
            gender = UX.askGeneric("Insert your gender[m/f]: ");
        }while( !gender.equals("m") && !gender.equals("f") );

        do {
            fHeight = UX.askGeneric("Insert your height[cm, 100-250]: ");
        }while( !UX.isNumeric(fHeight, false) || Float.parseFloat(fHeight) < 100 || Float.parseFloat(fHeight) > 250  );
        height = Float.parseFloat(fHeight);

        do {
            fWeight = UX.askGeneric("Insert your weight[kg, 30-300]: ");
        }while( !UX.isNumeric(fWeight, false) || Float.parseFloat(fWeight) < 30 || Float.parseFloat(fWeight) > 300  );
        weight = Float.parseFloat(fWeight);

        do {
            day = UX.askGeneric("Insert your day of birth: ");
            month = UX.askGeneric("Insert your month of birth: ");
            year = UX.askGeneric("Insert your year of birth: ");

            ret = UX.isDateValid( day, month, year, dob );

            if( !ret )
                UX.askGeneric("Wrong Date Format");

        }while( !ret );
    }

	/**
	 * Notifica utilizador que tem pedidos de amizade pendentes
	 * @return true caso haja notificações, false caso contrário
	 */
	public boolean getNotify()
	{
		String answer;
		boolean noti = false;
		LinkedList<User> maybeFriends;
		
		maybeFriends = fri.getNotificationsForUser(this);
		
		if(maybeFriends == null)
			return noti;
		
		for (User us : maybeFriends)
		{
			noti = true;
			do
			{
				answer = UX.askGeneric(us.getName() + " has added you as a friend, do you accept Y/N: ");
			}while(!answer.equals("y") && !answer.equals("Y") && !answer.equals("n") && !answer.equals("N"));
			if(answer.equals("y") || answer.equals("Y"))
			{
				friends.add(us);
				us.getFriends().add(this);
				
				fri.removeUserFromNoti(this, us);
			}
			else
			{
				fri.removeUserFromNoti(this, us);
			}
		}
		
		return noti;
	}
    
	/**
	 * Calcula as calorias gastas numa actividade, passada por parâmetro
	 * @param a do tipo Activity
	 * @return ret calorias gastas
	 */
    public float calculateCalories( Activity a )
    {
        float ret = 0;
        float met = a.getMET();
        
        ret = ( met * weight ) * ( a.getDuration() / (float)3600 ) ;
        
        return ret;
    }
    
	/**
	 * Calcula a média do utilizador numa dada actividade
	 * @param activityType nome da actividade
	 * @return avg média do utilizador numa dada actividade
	 */
	public float avgActivityUser( String activityType )
	{
		float avg = 0;
		int i;
		
		for( i = 0; i < activities.get(activityType).size(); i++ ) {
			avg += (float)activities.get(activityType).get(i).quantifier(false);
			
		}
		
		if( i != 0)
			avg = avg / (float)i;
		
		return avg;
	}
    
    /**
	 * Remove o evento da lista de eventos do User
	 * @param e do tipo Event
	 */
    public void removeFromEvent(Event e)
    {
        userEvents.remove(e);
    }
	
	/**
	 * Remove o um amigo da lista de amigos
	 * @param e do tipo Event
	 */
	public void removeFriend(User us)
	{
		friends.remove(us);
	}
       
	/**
	 * Transforma a representação interna da classe User numa String
	 * @return string com a informação de uma instância de User
	 */
    public String toString()
    {
        return super.toString();
    }
    
	/**
	 * Compara este objecto com um outro passado por parâmetro
	 * @param o do tipo objecto
	 * @return false se o fôr null, se os objectos a serem comparados forem de classes distintas ou
	 * se alguma variável de instância fôr diferente entres os dois objectos em questão, true caso contrário
	 */
    public boolean equals(Object o)
    {
        if(this == o) {return true;}
        if((this == null || (this.getClass() != o.getClass())))
        {
            return false;
        }
        else
        {
            User u = (User) o;
            return (super.equals(u) &&
                    this.name.equals(u.getName()) &&
                    this.gender.equals(u.getGender()) &&
                    this.height == u.getHeight() &&
                    this.weight == u.getWeight () &&
                    this.dob.getTimeInMillis() == u.getDOB().getTimeInMillis() &&
					this.userEvents.equals(u.getUserEvents()) &&
					this.friends.equals(u.getFriends()) &&
					this.activities.equals(u.getActivities()));
        }
    }
    
	/**
	 * Cria e devolve uma cópia da classe User
	 * @return clone da instância
	 */
    public User clone() {return new User(this);}
}
