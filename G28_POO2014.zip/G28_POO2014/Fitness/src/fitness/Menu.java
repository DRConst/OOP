package fitness;    

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.util.LinkedList;
import java.util.GregorianCalendar;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Menu, classe que contém o menu principal, e métodos gerais, como save, load
 * @author Grupo 28
 */
public class Menu
{
    private boolean running = true;
    Competition comp = new Competition();
	Friends friends = new Friends();
    
    private static LinkedList<Profile> profiles = new LinkedList<Profile>();
    //Iteração em LinkedList é O(n), adição e remoção de elementos é O(1) Itereção em ArrayList é O(n), adição e remoção é O(n) (pior caso)
    
    private static ArrayList<Activity> activityTypes = new ArrayList<Activity>();
    
    /**
     * Complementa o método initMenu da classe UX
     */
    public void run ()
    {
        load();
        
        activityTypes.add( new Swimming() );
		activityTypes.add( new Golf() );
		activityTypes.add( new MarathonRunning() );
        
        do
        {
            running = true;
            
            UX.pageClear();
            switch (UX.initMenu())
            {
                case 1:
                
                    if( logIn() )
                        UX.askGeneric("Logged Off");
                    else
                        UX.askGeneric("Login Canceled");
                
                    break;
                case 2:
                    
                    if( createUser() )
                        UX.askGeneric("User sucessfully created");
                    else
                        UX.askGeneric("User creation canceled");
                    
                    break;
                case 3:
                    
                    if( deleteUser() )
                        UX.askGeneric("User sucessfully deleted");
                    else
                        UX.askGeneric("User deletion canceled");
                    
                    break;
                case 4:
                    
                    if( listUsers() == 0 )
                        UX.askGeneric("No users found");
                    else
                        UX.askGeneric("");
                    
                    break;
                    
                case 5:
                    save();
                    running = false;
                    UX.askGeneric("\nBye! Bye!");
                    break;
            }
        }while(running);
    }

    /**
     * Efectuar login de User ou Admin
     * @exception IllegalArgumentException caso não exista nenhuma conta de utilizador com dado nome
     * @return true caso o login seja efectuado com sucesso, false caso contrário
     */
    public boolean logIn() 
    {
        String strUser, strPass;
        int idx = 0;
        Profile p;
        
        
        if( profiles.size() == 0 ) {
            UX.askGeneric("No users created.");
            return false;
        }
        
        strUser = UX.pickUsername();
        
        idx = findUser(strUser);
        try
        {
            if(idx==-1){throw new IllegalArgumentException();}
            
            p = profiles.get(idx);
            strPass = UX.pickPassword();
            try
                {
                    if (p.getPass().equals(strPass))
                    {
                        p.Menu();
                    }
                    else {throw new IllegalArgumentException();}
                }
                catch (IllegalArgumentException e)
                {
                    UX.askGeneric("Wrong password for " + p.getUser() + ".\n");
                    return false;
                }
        }
        catch(IllegalArgumentException e)
        {
            UX.askGeneric("User not found!\n");
            return false;
        }
        
        return true;
    }
    
    /**
     * Criar novo User ou Admin
     * @exception IllegalArgumentException caso o nome de utilizador já esteja em uso
     * @return true caso seja criado com sucesso um novo User ou Admin, false caso contrário
     */
    public boolean createUser ()
    {
        String strUser, strPass, strName, strGender;
        String fHeight, fWeight;
        String day, month, year;
        boolean ret;
        int idx;
        int typeUser;
        GregorianCalendar calen = new GregorianCalendar();
        
        typeUser = UX.askTypeUser();
        
        if (typeUser==3) return false;
        
        strUser = UX.pickUsername();
            
        idx = findUser(strUser);
        
        try
        {
            if (idx!=-1){throw new IllegalArgumentException();}

            strPass = UX.pickPassword();
            if(typeUser==1)
            {
                Admin temp = new Admin (strUser, strPass);
                profiles.add (temp);
            }
            else
            {
                do {
                    strName = UX.askGeneric("Insert your name: ");
                }while( strName.length() <= 0 );
                
                do {
                    strGender = UX.askGeneric("Insert your gender[m/f]: ");
                }while( !strGender.equals("m") && !strGender.equals("f") );
                
                do {
                    fHeight = UX.askGeneric("Insert your height[cm, 100-250]: ");
                }while( !UX.isNumeric(fHeight, false) || Float.parseFloat(fHeight) < 100 || Float.parseFloat(fHeight) > 250  );
                
                do {
                    fWeight = UX.askGeneric("Insert your weight[kg, 30-300]: ");
                }while( !UX.isNumeric(fWeight, false) || Float.parseFloat(fWeight) < 30 || Float.parseFloat(fWeight) > 300  );
                
                do {
                    day = UX.askGeneric("Insert your day of birth: ");
                    month = UX.askGeneric("Insert your month of birth: ");
                    year = UX.askGeneric("Insert your year of birth: ");

                    ret = UX.isDateValid( day, month, year, calen );
                    
                    if( !ret )
                        UX.askGeneric("Wrong Date Format");

                }while( !ret );
                
                HashMap<String, LinkedList<Activity> > activities = new HashMap<String, LinkedList<Activity> >();
                
                for(Activity a : activityTypes ) {
                    activities.put( a.getClass().getSimpleName(), new LinkedList<Activity>() );
                } 

                User temp = new User (strUser, strPass, strName, strGender, Float.parseFloat(fHeight), Float.parseFloat(fWeight), calen, new LinkedList<Event>(), new LinkedList<User>(), activities );
                profiles.add (temp);
                
            }
        }
        catch (IllegalArgumentException e)
        {
            UX.askGeneric("That username already exists!\n");
            return false;
        }
        
        return true;
    }
    
    /**
     * Eliminar uma conta de utilizador, tanto do tipo User como do tipo Admin
     * @exception IllegalArgumentException caso a palavra passe do utilizador a ser removido esteja errada, ou
     * caso não exista uma conta utilizador com esse nome
     * @return true em caso de sucesso, false caso contrário
     */
    public boolean deleteUser()
    {
        String strUser, strPass;
        int idx = 0;
        Profile p;
        
        
        if( profiles.size() == 0 ) {
            UX.askGeneric("No users available to delete.");
            return false;
        }
        
        strUser = UX.pickUsername();
        
        idx = findUser(strUser);
        try
        {
            if(idx==-1){throw new IllegalArgumentException();}
            
            p = profiles.get(idx);
            strPass = UX.pickPassword();
            try
                {
                    if (p.getPass().equals(strPass))
                    {
						if(p instanceof User)
						{
							User us = (User)p;
							for(Event ev : us.getUserEvents())
							{
								if(ev.getEventResults()==null)
								{
									comp.removeUser(ev, us);
								}
							}
							
							for(User fr : us.getFriends())
							{
								fr.removeFriend(us);
							}
							
							for(User kUs : friends.getNotification().keySet())
							{
								friends.getNotification().get(kUs).remove(us);
							}
						}                        
						profiles.remove(idx);
                    }
                    else {throw new IllegalArgumentException();}
                }
                catch (IllegalArgumentException e)
                {
                    UX.askGeneric("Wrong password for " + p.getUser() + ".\n");
                    return false;
                }
        }
        catch(IllegalArgumentException e)
        {
            UX.askGeneric("User not found!\n");
            return false;
        }
        
        return true;
    }
    
    /**
     * Listar todas as contas de utilizadores
     * @return count soma de todas as contas
     */
    public int listUsers()
    {
        int count = 0;
        
        for (Profile p : profiles)
        {
            if (p instanceof Admin) {
                UX.printProfile(p);
                count++;
            }
        }
        for (Profile p : profiles)
        {
            if (p instanceof User) {
                UX.printProfile(p);
                count++;
            }
        }
        
        return count;
    }
    
    /**
     * Procura de um utilizador, sendo o seu nome passado por parâmetro
     * @param str nome de utilizador
     * @return i posição onde foi encontrado, -1 caso nao exista um utilizador com esse nome
     */
    public int findUser(String str)
    {
        for (int i=0; i<profiles.size(); i++)
        {
            if(profiles.get(i).getUser().equals(str))
            {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Devolve o arrayList de actividades 
     * @return devolve o arrayList de Activity
     */
    public static ArrayList<Activity> getActivityTypes()
    {
        return activityTypes;
    }
    
    /** 
     * Caso booleanUserAdmin seja true devolve uma linkedList de User, caso seja false devolve uma linkedList de Admin
     * @param booleanUserAdmin true caso se pretenda receber uma linkedList de User, false caso se pretenda receber uma 
     * linkedList de Admin
     * @return list arrayList de Profile
     */
    public static LinkedList<Profile> getProfiles( boolean booleanUserAdmin )
    {
        LinkedList<Profile> list = new LinkedList<Profile>();
        
        for( Profile p : profiles ) {
            
            if( booleanUserAdmin ) {
                if( p instanceof User )
                    list.add( p );
            }
            else {
                if( p instanceof Admin )
                    list.add( p );
            }
                
        }
        
        return list;
    }
    
    
    /////////////////////////////////////
    ///////   LOADS   ///////////////////
    /////////////////////////////////////
    /**
     * Método que efectua o carregamento dos dados para a estrutura
     * @exception IOException caso haja algum erro na leitura
     * @exception ClassNotFoundException caso haja algum erro na leitura
     */
	public void load()
    {
		try
		{
			loadFitness("fitness.txt");
		}
		catch(IOException | ClassNotFoundException e)
		{
			System.err.println("Error loading" + e);
		}
    }
    
    /**
     * Método que carrega dados para a estrutura que contém toda a informação
     * @param local nome do ficheiro
     * @throws IOException caso haja algum erro na leitura
     * @throws ClassNotFoundException caso haja algum erro na leitura
     */
    public void loadFitness(String local) throws IOException, ClassNotFoundException
    {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(local));
		profiles = (LinkedList<Profile>)ois.readObject();
		comp.setEvents((HashMap<Event, LinkedList<User>>)ois.readObject());
        friends.setNotification((HashMap<User, LinkedList<User>>)ois.readObject());
    }
    
    /////////////////////////////////////
    ///////   SAVES   ///////////////////
    /////////////////////////////////////
    /**
     * Método que efectua a gravação dos dados para a estrutura
     * @exception IOException caso haja algum erro durante a gravação
     */
	public void save() 
    {
		try {saveFitness("fitness.txt");}
        catch (IOException e)
        {
            System.err.println ("Error saving!\nLog: " + e);
        }
    }
    
    /**
     * Método que grava dados da estrutura que contém toda a informção para um ficheiro de nome recebido como parâmetro
     * @param local nome de ficheiro
     * @throws IOException caso haja algum erro na escrita
     */
	public void saveFitness(String local) throws IOException
    {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(local));
		oos.writeObject(profiles);
		oos.writeObject(comp.getEvents());
        oos.writeObject(friends.getNotification());
        oos.close();
    }
}
