package fitness;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * Friends, classe de controlo de pedidos de amizade
 * @author Grupo 28
 */
public class Friends implements Serializable
{
	private static HashMap<User, LinkedList<User>> notification = new HashMap<User, LinkedList<User>>();

	/**
	 * Devolve o Map de notificações
	 * @return Map de notificações
	 */
	public HashMap<User, LinkedList<User>> getNotification()
	{
		return notification;
	}
	
	/**
	 * Coloca a variável de instância notification
	 * com o valor da variável passada por parâmetro
	 * @param notes Map de notificações
	 */
	public void setNotification(HashMap<User, LinkedList<User>> notes)
	{
		notification = notes;
	}
	
	/**
	 * Adiciona um novo pedido feito pelo utilizador "requester" para o utilizador "requested"
	 * @param requester utilizador que faz o pedido de amizade
	 * @param requested utilizador que recebe o pedido de amizade
	 * return true em caso de sucesso, false caso já exista um pedido realizado entre os mesmo requester/requested
	 */
	public boolean addFriend(User requester, User requested)
	{
		if(notification.containsKey(requested))
		{
			for(User us : notification.get(requested))
			{
				if(us.getName().equals(requester.getName()))
				{
					return false;
				}
			}
			notification.get(requested).add(requester);
			return true;
		}
		notification.put(requested, new LinkedList<User>());
		notification.get(requested).add(requester);
		return true;
	}
	
	/**
	 * Devolve o List de notificações do utilizador passado por parâmetro
	 * @param us utilizador que se pretende receber a lista de notificações
	 * @return List de notificações do utilizador passado por parâmetro
	 */
	public LinkedList<User> getNotificationsForUser(User us)
	{
		return notification.get(us);
	}
	
	/**
	 * Remove o utilizador "toBe" da lista de notificações do utilizador "friend"
	 * @param friend utilizador que se pretende apagar um utilizador "toBe" da sua lista de notificações
	 * @param toBe utilizador que será apagado da lista do utilizador "friend"
	 * @return true em caso de sucesso na remoção, false caso contrário
	 */
	public boolean removeUserFromNoti(User friend, User toBe)
	{
		return notification.get(friend).remove(toBe);
	}
    
	/**
	 * Transforma a representação interna da classe Friends numa String
	 * @return string com a informação de uma instância de Friends
	 */
    public String toString() {
        StringBuilder s = new StringBuilder();
        for(User u: notification.keySet()) {
			s.append("Name: ");
			s.append(u.getName());
			s.append("\nNotifications: ");
			for(User us: notification.get(u)) {
				s.append("\tName: ");
				s.append(us.getName());
			}
			s.append("\n");
        }
        return s.toString();
    }
    
	/**
	 * Compara este objecto com um outro passado por parâmetro
	 * @param o do tipo objecto
	 * @return false se o fôr null, se os objectos a serem comparados forem de classes distintas ou
	 * se alguma variável de instância fôr diferente entres os dois objectos em questão, true caso contrário
	 */
	@Override
    public boolean equals(Object o) {
        if(o == this) return true;
        
        if(o == null || this.getClass() != o.getClass()) return false;
        
        Friends fri = (Friends) o;
        
        return(this.notification.entrySet().equals(fri.getNotification().entrySet()));
    }
}